# Security report

This is the result of automated checks and developer-run tests. **It is not a penetration test** (SR-19 is not met) and no OWASP ZAP scan was run (AC-17 is partial).

## Automated checks run
| Check | Result |
|---|---|
| bandit (static analysis, 2,250 lines) | 0 findings after fixes (initially 6: 1 medium, 5 low) |
| pip-audit on pinned runtime and dev dependencies | No known vulnerabilities (initially 16, in Starlette and pytest) |
| npm audit, all dependencies | 0 vulnerabilities (initially 2 in the Vite dev tooling) |
| Authorisation sweep (`SWP01`) | 71 API routes found: 62 enforce the role matrix, 9 are deliberately public or session-only (allowlisted). 62 routes x 4 roles plus anonymous, 0 violations; the test fails if any new route has no declared authorisation |
| Static scan for dynamic SQL (`SQL01`) | No f-string, concatenation or format-built SQL anywhere in `app/` |
| Injection tests (`SQLI01`, `DSH03`) | SQL injection strings rejected or treated as plain text |
| Log-injection tests (`COL07`) | Control characters stripped; rules cannot contain code or regular expressions |
| CSV formula injection (`DSH04`, `RPT05`) | Cells starting with `=`, `+`, `-`, `@` are neutralised |
| Tamper tests (`AUD02`, `INT01`) | Audit log: database refuses UPDATE, DELETE, TRUNCATE (SQLite and PostgreSQL); hash chain detects a bypass. Stored events: modification detected |
| Security headers (`SEC01`) | CSP, X-Frame-Options DENY, nosniff, no-referrer on application responses |

## Problems found and fixed during development
1. **Vulnerable web framework:** Starlette 0.46.2 (via FastAPI 0.115) had 14 advisories. Upgraded FastAPI to 0.165.0 and Starlette to 1.10.0; all tests re-run.
2. **Audit chain race:** concurrent writers could break the hash chain. Proven with a test, fixed with a PostgreSQL transaction lock. Without the lock the test fails.
3. **Counter race:** two workers creating the same counter row collided. Replaced with atomic upserts.
4. **Webhook scheme:** the webhook call accepted any URL scheme. Now http and https only.
5. **Foreign keys SQLite ignored:** deleting a source or asset with events would have failed on PostgreSQL. Fixed with `ON DELETE SET NULL`.
6. **Restore ID collision:** restoring users into a fresh database could overwrite another user. Users are matched by username.
7. **Misleading health status:** notification health reported "ok" with SMTP unconfigured. Now "degraded" with the reason.
8. **Asset risk double-counted criticality.** Removed.

## Controls in place
Argon2id password hashing; 12-character minimum; TOTP MFA (mandatory for Administrator and Analyst); lockout and rate limits on login and password reset; random 256-bit session tokens stored only as hashes; 8-hour and 15-minute idle limits; revocation on logout, disable and password reset; server-side role checks on every route; no default credentials (first-run setup); append-only hash-chained audit log; parameterised queries only; strict input validation; output escaping by the UI framework; CSP and related headers; per-source revocable ingestion tokens; encrypted configuration backups (AES-256-GCM with scrypt); attachments limited by type and size and served as downloads; reset and lockout e-mails carry no raw log content.

## Known limitations (read before deploying)
- **No penetration test, no ZAP scan.** Commission one before real use.
- **TLS is the reverse proxy's job.** The proxy configuration was not run. The syslog UDP and TCP listener is plaintext and unauthenticated; the UI says so. Ingestion tokens travel in a header: use HTTPS.
- **Encryption at rest** for the database and archive files depends on your disk or database encryption. Only configuration backups are encrypted by the application.
- **Secrets** come from environment variables; there is no secret-store integration.
- **Password check** uses a 10-entry list of common passwords, not a breached-password database.
- **Rate limits are per process and in memory**; they cover login, password reset and ingestion only.
- **Session token** is kept in browser session storage (cleared when the tab closes). A cross-site scripting flaw would expose it; the CSP and output escaping reduce that risk. Cookies would need CSRF protection.
- **Detection quality is limited** (see `detection_evaluation.md`): recall 76% and a 7.5% false-positive share on synthetic scenarios, and the anomaly rule only looks at login hour.
- **Containers** are configured for non-root and read-only operation but were not built or run.
- **Event integrity** hashes the raw text only.
- **Incident access** is by role, not per incident: any analyst can edit any case.
