# Installation and configuration guide

CyberShield is a Python (FastAPI) backend and a React web UI. It stores data in PostgreSQL (recommended) or SQLite (development only).
Read `docs/RTM.md` before relying on it: it states what is verified and what is not.

## What was and was not tested
Tested in the development environment: Python 3.12, PostgreSQL 16 and SQLite, the full test suite on both databases, Alembic migrations on PostgreSQL, the built UI served by the API (Chromium).
**Not tested:** Docker, Docker Compose, the Caddy proxy and the CI workflow (no Docker in the build environment), real mail servers, Windows or Linux agents, Firefox, Edge, Safari, and any manual or screen-reader accessibility review (an automated WCAG scan was run: see `accessibility_report.md`).

## Requirements
Python 3.12, Node.js 22 (to build the UI), PostgreSQL 16 for production. Build the UI on a normal filesystem: npm needs symbolic links.

## Option A: quick start on one machine (SQLite, for evaluation)
```
cd backend
pip install -r requirements.txt
cd ../frontend && npm ci && npm run build && cd ../backend
uvicorn app.main:app --port 8000
```
Open http://127.0.0.1:8000. The first-run screen asks you to create the Administrator and shows the authenticator (TOTP) secret once. Add it to an authenticator app, then sign in with your password and a 6-digit code.
SQLite is for development: it handles one writer at a time and does not support parallel workers.

## Option B: PostgreSQL with migrations (recommended)
1. Create a database and a user with a strong password of your own.
2. Set the environment (see the table below), at minimum `DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST/DBNAME`.
3. `cd backend && alembic upgrade head` creates the schema, including the database-level block on changing the audit log.
4. `uvicorn app.main:app --host 127.0.0.1 --port 8000` and put a TLS reverse proxy in front (see `deploy/Caddyfile`).
5. To upgrade later: replace the code, run `alembic upgrade head`, restart.
Several API containers or processes can run against one database: queue and detection claims use row locks. The in-memory rate limiter is per process.

## Option C: Docker Compose (written, not tested here)
```
cp .env.example .env        # set POSTGRES_PASSWORD; there is no default password
docker compose up -d --build
```
Open https://localhost (or the name in `SITE_ADDRESS`). The database is on an internal network only; the app runs as a non-root user with a read-only filesystem; Caddy terminates TLS.

## First run and users
No default accounts exist. Create the Administrator on the first-run screen, then create the other roles under Administration, Users: Security Analyst, Manager, Auditor.
MFA is mandatory for Administrator and Analyst (their authenticator secret is shown once when the account is created) and optional for Manager and Auditor.
Administrative access should be restricted to a VPN or management network at your firewall.

## Configuration (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./cybershield.db` | Database. Use PostgreSQL in production. |
| `SESSION_HOURS` / `IDLE_MINUTES` | 8 / 15 | Maximum session length and idle timeout. |
| `MAX_FAILED_LOGINS` / `LOCK_MINUTES` | 5 / 15 | Account lockout. |
| `RATE_LIMIT_PER_MIN` / `INGEST_RATE_PER_MIN` | 20 / 600 | Login and password-reset limit per address; ingestion limit per source. |
| `INGEST_WORKER` | 1 | 1 runs the background worker (queue, detection, notifications, schedules, retention) inside the API process. Set 0 on API-only instances. |
| `CORRELATION_MINUTES` | 30 | Window for merging related detections into one alert. |
| `ESCALATION_MINUTES` | 15 | Unacknowledged Critical alerts are escalated to Managers after this long. |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `SMTP_STARTTLS` | empty / 587 / ... / 1 | E-mail. Leave `SMTP_HOST` empty to disable; messages are then recorded as not sent and system health shows degraded. |
| `WEBHOOK_URL` | empty | Receives Critical alerts as JSON (http or https only). |
| `PUBLIC_URL` | `http://localhost:5173` | Base address used in e-mailed links. |
| `ARCHIVE_DIR` | `./archive` | Where retention writes compressed archive files. Back this up if you need the archives. |
| `DASHBOARD_CACHE_SECONDS` | 5 | Shared cache for the two heaviest dashboard aggregates. 0 disables. |
| `SYSLOG_PORT`, `SYSLOG_HOST`, `SYSLOG_SOURCE` | 0 / 127.0.0.1 / empty | Optional syslog listener (UDP and TCP, plaintext). `SYSLOG_SOURCE` is the name of a registered syslog source. |
| `GEOIP_CSV` | empty | Optional file of `cidr,country,lat,lon` lines for the attack-source country view. No database is bundled. |
Pass secrets (`DATABASE_URL`, `SMTP_PASSWORD`) from your platform's secret mechanism, not from files in the repository.

## Connecting log sources
Administration, Log sources, Register source shows a token once. Send events as JSON arrays (up to 1,000 per request) to `POST /api/v1/events` with header `X-Source-Token`.
Fields: `timestamp` (ISO 8601), `hostname`, `event_type` (lowercase, for example `auth.failure`), `message`, optional `severity` (0-10), `src_ip`, `dst_ip`, `user`.
Detection rules expect these event types: `auth.failure`, `auth.success`, `net.fw` (message containing `SRC=... DPT=...`), `priv.sudo`, `web.request`. Syslog lines are mapped to them automatically.
Sample files can be imported by an administrator (`POST /api/v1/ingest/import`), and the simulator (`POST /api/v1/simulate`) creates events that are always labelled **simulated**.
**Data honesty:** every event is labelled live, imported or simulated, and the UI shows the split permanently. Nothing here is production intrusion detection: detection is rule-based and statistical.

## Backups and upgrades
Administration, Backup and restore creates an encrypted configuration backup (assets, rules, suppressions, sources, indicators, retention, optionally users). It does not back up events, alerts, incidents or the audit log: use PostgreSQL backups for those, and test a restore at least quarterly.

## Running the tests
```
cd backend && pip install -r requirements-dev.txt
python -m pytest -q                                  # SQLite
DATABASE_URL=postgresql+psycopg://... python -m pytest -q   # PostgreSQL (also runs the concurrency tests)
```

## Troubleshooting
| Symptom | Cause and fix |
|---|---|
| Health shows notification service degraded | `SMTP_HOST` is not set. Alerts still appear on screen. |
| A source shows `silent` | It has sent nothing for 10 minutes, or never sent anything. Check its token and network. |
| "MFA code required" and you have no code | The authenticator secret was shown once and you did not save it. In the `backend` folder run `python reset_mfa.py YOUR_USERNAME` (add `--password` to also choose a new password). It prints a new secret, unlocks the account and signs it out everywhere. For the packaged program run `CyberShield --reset-mfa YOUR_USERNAME`. The use is recorded in the audit log. |
| Login says "Account temporarily locked" | 5 failed attempts; wait 15 minutes. Administrators receive an e-mail if SMTP is configured. |
| `npm install` fails with symlink errors | Build on a filesystem that supports symbolic links. |
| Old `cybershield.db` after an upgrade | Use PostgreSQL with `alembic upgrade head`; SQLite development files are recreated, not migrated. |
