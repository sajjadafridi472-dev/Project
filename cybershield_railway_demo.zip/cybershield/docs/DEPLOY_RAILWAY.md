# Deploy CyberShield to Railway (demo)

This repository is configured for a single Railway web service built from `backend/Dockerfile`. The Docker build context must remain the repository root because the Dockerfile copies both `backend/` and `frontend/`. Railway's PostgreSQL service is separate.

## 1. Push the project to GitHub

Create a private or public GitHub repository, commit the project (do not commit `.env` or credentials), and push the default branch.

## 2. Create the Railway project

1. Create a Railway project and add a PostgreSQL database.
2. Add a service from the GitHub repository.
3. Keep the repository root as the service root directory. `railway.toml` selects `backend/Dockerfile`; do not set the root directory to `backend`, because the Docker build needs the root-level `frontend/` folder.
4. Add a Railway Volume to the app service at `/data/archive` so archived event files survive redeploys.
5. Generate a public domain only after setting the required variables below.

Railway does not run this repository's Docker Compose file directly; map the app and database to separate Railway services.

## 3. App service variables

Set these in the app service's Variables tab. Use Railway's reference-variable picker for the PostgreSQL URL rather than copying credentials. If the database service is named `Postgres`, the reference is normally `${{Postgres.DATABASE_URL}}` (select the actual service name in the UI).

```env
DATABASE_URL=${{Postgres.DATABASE_URL}}
SETUP_TOKEN=<generate-a-long-random-one-time-token>
PUBLIC_URL=https://${{RAILWAY_PUBLIC_DOMAIN}}
ARCHIVE_DIR=/data/archive
INGEST_WORKER=1
SESSION_HOURS=8
IDLE_MINUTES=15
RATE_LIMIT_PER_MIN=20
```

Generate a high-entropy setup token locally, for example with `python -c "import secrets; print(secrets.token_urlsafe(32))"`. Enter it in Railway Variables; do not commit it. The first-run page requires this token before creating the first Administrator. After successful setup, remove `SETUP_TOKEN` from Railway Variables and redeploy. The first-run endpoint is also permanently closed once an account exists.

Do not set `SYSLOG_PORT` for this Railway demo: Railway's normal web-service networking is not a general inbound UDP/TCP syslog listener. Use the authenticated HTTPS event-ingestion API or file import. Do not set SMTP variables unless a real mail provider is configured.

## 4. Deployment settings

- Keep one app replica for this demo. The queue worker and login rate limiter are process-local; scaling multiple replicas would run multiple workers and give each replica a separate in-memory rate limit.
- Keep PostgreSQL private; the app connects over Railway's private network.
- Railway health checks use `/api/v1/health`. The application must have completed startup and the worker must report healthy before the health check is expected to pass.
- Review deployment logs for Alembic migration success and Uvicorn startup.

## 5. First login

Open the generated Railway domain, create the first Administrator using the one-time setup token, and save the displayed TOTP authenticator secret immediately. Add it to an authenticator app. Then sign in with the password and six-digit authenticator code. Create demo analyst/manager/auditor accounts from Administration as needed.

## 6. Demo data and verification

Use the built-in simulator and confirm the UI labels its events as simulated. Verify event ingestion, queue processing, detection, alert creation, incident workflow, role restrictions, and audit verification. Do not present simulated data as live endpoint monitoring.

## Limitations

This is a demonstration deployment, not a hardened production SIEM. The repository documents missing endpoint agents, plaintext/no TLS syslog listener, detection-evaluation gaps, performance limitations, and the absence of an independent penetration test. The in-memory rate limiter is per process. Railway deployment and runtime must be tested after the repository is pushed and provisioned; a successful source build alone does not prove every integration works.
