# Architecture and design decisions

![Architecture](architecture.png)
Entity-relationship diagrams generated from the code: `er_diagram_core.png` (main entities) and `er_diagram_full.png` (all 29 tables). Regenerate with `python scripts/build_diagrams.py`.

## Data flow
Sources send events to a collector (REST with a source token, syslog listener, file import, or the simulator). Collectors only **write to a persistent queue table**; an event is accepted once that write commits.
A worker then normalises each event to the SRS schema (UTC time, severity 0-10, SHA-256 of the raw text), quarantines malformed input, counts duplicates, stores the event, and evaluates the rules. Detections about the same entity within 30 minutes are merged into one alert with a 0-100 score and a stored explanation.
New High or Critical alerts go to the notification outbox (e-mail, webhook, with retry) and to a WebSocket hub that updates open dashboards. Analysts triage alerts and create incidents; reports, retention and scheduled delivery run from the same worker.

## Code map (`backend/app/`)
| Concern | Files |
|---|---|
| Accounts, sessions, MFA, RBAC, audit | `main.py`, `security.py`, `rbac.py`, `audit.py`, `dbsetup.py` |
| Collection and normalisation | `ingest.py`, `routes_ingest.py`, `syslog_listener.py` |
| Detection, correlation, scoring | `detect.py`, `routes_detect.py` |
| Alerts, notifications, live feed | `routes_alerts.py`, `notify.py`, `hub.py` |
| Incidents and response | `routes_incidents.py`, `playbooks.py`, `respond.py` |
| Dashboard, assets, geo | `routes_dashboard.py`, `geo.py` |
| Reports and compliance | `report.py`, `routes_reports.py` |
| Retention, backup, health, threat intel | `retention.py`, `backup.py`, `routes_admin.py`, `maintenance.py`, `metrics.py` |
| Schema and migrations | `models.py`, `backend/migrations/` |
Frontend: `frontend/src/` (React, Vite, Recharts). Tests: `backend/tests/`. Scripts: `scripts/`.

## Decisions where the sources disagreed or were silent
| Topic | Decision |
|---|---|
| Who resolves alerts | The survey (70%) wanted administrators; SRS 7.8 gives triage to the Analyst only. **SRS followed.** |
| Who approves automated responses | FR-INC-06 says analyst approval; the SRS matrix says Manager. **Matrix followed;** analysts propose. |
| Alert to event and incident to alert links | SRS diagram shows one-to-one, the data dictionary says many. **Many-to-many tables.** |
| Navigation | SRS says top bar, brief says sidebar. **Sidebar.** |
| Theme | Dark by default, light available (both required). |
| MFA | Mandatory for Administrator and Analyst, optional for others. |
| Brute-force threshold | More than 10 failures in 5 minutes, configurable per rule. |
| Message queue and search store | Kafka and OpenSearch are replaced by a database-backed queue and database search (SRS 5.3.1 says the stack is a proposal). |
| Export of reports | SRS 7.8 shows Manager and Auditor as read-write and Analyst and Admin as read; previews are open to all, exports to Manager and Auditor. |
| Closed incidents | Final, so closed records cannot change. |
| Audit log and deleted users | Audit rows keep a username snapshot and a soft user reference so they survive user deletion. |

## Honest scope
Real-time monitoring of production systems is **not** claimed. The system can ingest live events from configured sources, but its demonstration data is simulated or imported and is labelled as such. Detection is rule-based plus one statistical rule; there is no machine learning.
