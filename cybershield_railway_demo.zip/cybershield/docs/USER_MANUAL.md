# User manual

CyberShield helps a small team watch security events, investigate alerts and manage incidents. Screenshots in `docs/screenshots/` use **demo data that is simulated or imported**, never real monitoring.

## Before you start
- **What it does:** collects events from sources you register, labels each as *live*, *imported* or *simulated*, applies rule-based and statistical detection, groups related detections into scored alerts, and supports incident handling and reporting.
- **What it does not do:** it does not use machine learning, does not detect everything, and does not block anything by itself. Its measured detection quality on the test scenarios is in `detection_evaluation.md`.
- **The bar at the top** of every page shows how many events are live, imported or simulated. If simulated data is present, a warning says so.
- Times are shown in UTC.

## Signing in (all roles)
1. Enter username and password (screenshot `01-login.png`). If your role requires it, a field for the 6-digit authenticator code appears (`02-login-mfa.png`).
2. After 5 wrong attempts the account locks for 15 minutes. After 15 minutes of inactivity you are signed out.
3. **Lost your authenticator secret?** It is shown only once. Whoever runs the server runs `python reset_mfa.py YOUR_USERNAME` on that computer (see `INSTALL.md`) to get a new one. An administrator can also delete and recreate another user's account.
4. "Forgot your password?" sends a single-use link valid for 30 minutes (needs e-mail to be configured).
5. You land on the page that suits your role: Analyst on Alerts, Manager on the Dashboard, Auditor on the audit log, Administrator on Administration.

## Roles
| Role | Can do |
|---|---|
| Security Analyst | Triage alerts, manage incidents, manage rules and suppressions, search events, view reports |
| Manager | View alerts and incidents, approve or reject block requests, export reports, schedule reports, see the audit log |
| Auditor | Read everything including users, sources, retention and the audit log; export reports |
| Administrator | Manage users, sources, assets, retention, backups and threat intelligence; view alerts and reports. **Cannot** triage alerts or manage incidents |
Pages you may not use are not shown in the menu. The server enforces this independently of the screen.

## Dashboard (`03-dashboard.png`)
Counts of open alerts by severity, the newest active alerts (updated live; a dot shows whether the live feed is connected, otherwise the page refreshes every 10 seconds), items needing attention, the most attacked assets and top attack sources, and charts of event and alert volume. Choose a period (hour, 24 hours, 7 days, 30 days) and select a bar to open the events from that interval. Select an asset or source address to see its events. Severity is shown by colour **and** a text label.

## Alerts (Analyst)
1. Open **Alerts**. The list is sorted by risk score. Select a row (`04-alert-detail.png`).
2. Read **Why this alert was raised**: the rule and its version, the numbers behind it, the score breakdown, asset owner and criticality, any threat-intelligence match, and the triggering events.
3. Choose **Start investigating**, **Mark resolved**, **Mark false positive** or **Reopen**, optionally with a note. If another analyst is already investigating, you are told who.
4. If it is real, choose **Create incident**. From the dashboard this is two clicks.
A single alert may combine several detections (for example a scan followed by a brute-force attempt from the same address); the title then starts with "Correlated".

## Incidents (`05-incident.png`)
The board shows incidents by state: New, Investigating, Contained, Resolved, False Positive, Closed. Select one to see its time measures, checklist, timeline, automated-response requests and attachments.
- **Move to** buttons show only the allowed next states. **Closed is final.** Reopen from Resolved or False Positive if needed.
- Assign an owner by typing an active analyst's username.
- Tick checklist items as you complete them. The checklist matches the incident type (brute force, phishing, ransomware, malware, other).
- **Request IP block** asks a Manager to approve. Nothing is blocked automatically: in this build, an approved request is recorded as "not executed" because no firewall is connected.
- Add notes, evidence links (http or https) and files (text, CSV, JSON, PDF, PNG, JPEG, up to 1 MB). Each file gets a SHA-256 fingerprint.

## Event search (`06-events.png`, `07-drilldown.png`)
Filter by text, asset, source address, user, event type, minimum severity, data origin and a UTC time range, then **Export CSV**. Text search is case-insensitive and treats `%` and `_` as ordinary characters.

## Assets (`09-assets.png`)
The inventory with owner, criticality (1-5) and a risk score. The score is the highest open alert score on the asset, plus 2 for each additional open alert; it is 0 when nothing is open. Administrators add, edit and remove assets.

## Detection rules
Lists the rules, what each detects and its definition. Analysts can switch a rule on or off; the change applies to the next batch of events. Creating, editing and testing rules, and suppressions (known-benign patterns that always expire), are available through the API (`/api/v1/rules`, `/api/v1/suppressions`) but not yet through screens.

## Reports (Manager, Auditor; others can preview) (`12-report-summary.png`, `13-compliance.png`)
- **Summary:** choose daily, weekly or monthly. Managers and Auditors can export PDF or CSV. The report states how many events are simulated and how MTTD and MTTR are calculated.
- **Compliance:** ISO/IEC 27001 and NIST CSF controls with live evidence from this system, or "Gap" where there is none. This is not certification.
- **Schedules:** receive a report by e-mail daily, weekly or monthly (needs e-mail to be configured).

## Administration
- **Users:** create, disable or delete accounts. The authenticator secret for a new Analyst or Administrator is shown once. You cannot delete or disable your own account.
- **Log sources:** register a source (token shown once), enable or disable it, and watch for `silent` status. UDP and TCP syslog sources are flagged as unencrypted.
- **Threat intelligence:** paste CSV lines or upload a STIX 2.1 bundle (`17-intel.png`).
- **Retention** (`14-retention.png`): how long data stays searchable and how long archives are kept. Events that an alert still refers to are kept as evidence. Incidents and the audit log are never deleted automatically.
- **Backup and restore** (`16-backup.png`): encrypted configuration backup with your passphrase. Without the passphrase a backup cannot be opened. Restore merges settings; it never changes events, alerts, incidents or the audit log.
- **System health** (`15-health.png`): each component's status. "Degraded" with "SMTP not configured" means e-mail alerts cannot be sent.
- **Audit log** (`10-admin-audit.png`): every security-relevant action. **Verify integrity** checks the hash chain; a broken chain means the log was altered outside the application.

## Tips
- Use keyboard navigation: the first Tab stop is "Skip to content"; table rows open with Enter.
- Switch between dark and light themes at the bottom of the menu.
- On a phone the menu moves to the top and tables scroll sideways (`11-mobile-manager.png`).
