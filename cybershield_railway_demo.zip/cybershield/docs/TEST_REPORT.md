# Test report

Generated from the JUnit results in `docs/evidence/` by `scripts/build_docs.py`. Command: `cd backend && python -m pytest -q`.
Run on SQLite: {'PASS': 89, 'SKIP': 2}. Run on PostgreSQL 16: {'PASS': 91}. The two skipped tests on SQLite are PostgreSQL-only (audit-chain concurrency and parallel-worker claim).

Kinds of test: unit (rule engine, scoring, parsers), integration (API plus database), system (queue to detection to alert to notification to incident to report, with real SMTP and webhook clients against local servers),
functional (every module), input validation, authentication and authorisation (including a sweep of every route against every role), error handling, and basic security (injection, headers, tamper evidence, static scan for dynamic SQL).

How to read the columns: **Key input** and **Expected** are extracted automatically from each test's source (first setup statement and first assertion) and are shortened; the full inputs and every assertion are in the named test.
**Actual result** is the pass or fail recorded in the JUnit file for that database. Measurements that are not pass/fail tests (detection quality, latency, throughput, concurrency load) are in `detection_evaluation.md`, `latency_report.md` and `performance_report.md`.

| Test ID | Requirement(s) | Description | Key input (first setup step) | Expected (first assertion) | SQLite | PostgreSQL |
|---|---|---|---|---|---|---|
| AUTH01 | FR-AUTH-02 | login valid and invalid | `-` | `client.post('/api/v1/auth/login', json={'username': 'root', 'password': 'wrong-password-1'}).status_code == 40...` | PASS | PASS |
| AUTH02 | FR-AUTH-03, SR-02 | mfa required and checked | `-` | `login(client, 'root').status_code == 401` | PASS | PASS |
| AUTH03 | FR-AUTH-05 | lockout after five failures | `u = make_user(client, admin, 'Security Analyst', 'ana')` | `login(client, 'ana', u['mfa_secret']).status_code == 423` | PASS | PASS |
| AUTH04 | FR-AUTH-06 | idle timeout | `with SessionLocal() as db:     for s in db.query(S):         s.last_seen = utcnow() - timedelta(minutes=16)   ...` | `client.get('/api/v1/auth/me', headers=admin['h']).status_code == 401` | PASS | PASS |
| AUTH05 | SR-04 | logout invalidates token | `-` | `client.post('/api/v1/auth/logout', headers=admin['h']).status_code == 200` | PASS | PASS |
| RBAC01 | AC-02, FR-AUTH-04, SR-03 | matrix enforced server side | `toks = {}` | `client.get('/api/v1/users').status_code == 401` | PASS | PASS |
| USR01 | FR-AUTH-01 | crud and disable | `u = make_user(client, admin, 'Auditor', 'aud')` | `client.patch(f'/api/v1/users/{u['id']}', headers=admin['h'], json={'status': 'disabled'}).json()['status'] == ...` | PASS | PASS |
| PWD01 | SR-01 | policy and argon2 | `base = {'username': 'bad', 'name': 'b', 'email': 'b@x.pk', 'role': 'Auditor'}` | `client.post('/api/v1/users', headers=admin['h'], json={**base, 'password': pw}).status_code == 422` | PASS | PASS |
| SQLI01 | SR-14, SR-15 | injection rejected | `-` | `client.post('/api/v1/auth/login', json={'username': "' OR '1'='1' --", 'password': 'x'}).status_code == 401` | PASS | PASS |
| SETUP01 | - | only once | `-` | `client.post('/api/v1/setup', json={'username': 'evil', 'name': 'e', 'email': 'e@x.pk', 'password': PW}).status...` | PASS | PASS |
| AUD01 | FR-ADM-04, FR-AUTH-08 | events logged | `login(client, 'root', pw='bad-password-123')` | `{'login.success', 'login.failed', 'logout', 'setup.admin_created'} <= acts` | PASS | PASS |
| AUD02 | AC-15, SR-12 | append only and tamper evident | `with SessionLocal() as db:     db.query(AuditLog).first().action = 'x'     with pytest.raises(PermissionError)...` | `client.get('/api/v1/audit/verify', headers=admin['h']).json()['intact'] is True` | PASS | PASS |
| COL01 | AC-03, FR-COL-01 | five source types normalised and searchable | `for name, typ in (('win-agent', 'agent'), ('lin-agent', 'agent'), ('fw-ids', 'ids'), ('app-api', 'api')):     ...` | `r.status_code == 202` | PASS | PASS |
| COL02 | FR-COL-02 | syslog parsing and severity | `a = ingest.parse_syslog('<38>Oct 19 09:15:02 web01 sshd[1]: Failed password for invalid user admin from 203.0....` | `(a['event_type'], a['username'], a['src_ip'], a['hostname'], a['severity']) == ('auth.failure', 'admin', '203....` | PASS | PASS |
| COL03 | FR-COL-05 | malformed quarantined and counted | `s = mk_source(client, admin, 'api1', 'api')` | `post(client, s['token'], bad + [ev()]).status_code == 202` | PASS | PASS |
| COL04 | AC-04, FR-COL-06, NFR-REL-02 | no event lost on crash | `s = mk_source(client, admin, 'api1', 'api')` | `post(client, s['token'], [ev(i) for i in range(N)]).status_code == 202` | PASS | PASS |
| COL05 | FR-COL-07, SR-05 | enable disable without restart | `a, b = (mk_source(client, admin, 'src-a', 'api'), mk_source(client, admin, 'src-b', 'api'))` | `a['token'] != b['token']` | PASS | PASS |
| COL06 | FR-COL-08, UC-02 | silent source flagged | `s = mk_source(client, admin, 'quiet', 'api')` | `st() == 'pending'` | PASS | PASS |
| COL07 | SR-21 | log injection sanitised | `s = mk_source(client, admin, 'api1', 'api')` | `'\n' not in m and '\x1b' not in m and ('\x00' not in m)` | PASS | PASS |
| COL08 | SR-03, SR-17 | auth limits and rbac | `s = mk_source(client, admin, 'api1', 'api')` | `client.post('/api/v1/events', json=[ev()]).status_code == 401` | PASS | PASS |
| COL09 | - | duplicates counted not stored | `s = mk_source(client, admin, 'api1', 'api')` | `(h['accepted'], h['duplicates']) == (2, 2)` | PASS | PASS |
| COL10 | - | origin labels simulated imported live | `s = mk_source(client, admin, 'api1', 'api')` | `len(get('live')) == 1 and len(get('simulated')) == 20 and (len(get('imported')) == 1)` | PASS | PASS |
| COL11 | FR-COL-02 | live syslog udp listener | `from app.syslog_listener import start` | `rows and rows[0]['data_origin'] == 'live' and (rows[0]['src_ip'] == '203.0.113.9')` | PASS | PASS |
| DET01 | FR-DET-01 | default rule library seeded | `with SessionLocal() as db:     assert db.query(Rule).count() == 6` | `db.query(Rule).count() == 6` | PASS | PASS |
| DET02 | FR-DET-02 | brute force threshold | `run(fails(10))` | `alerts() == []` | PASS | PASS |
| DET03 | FR-DET-03 | port scan | `run(scan(15))` | `alerts() == []` | PASS | PASS |
| DET04 | FR-ADM-05, FR-DET-04 | ioc ip domain hash and expiry | `h = 'a' * 64` | `r == {'imported': 4, 'rejected': 2}` | PASS | PASS |
| DET05 | FR-DET-05 | privilege escalation | `run([E(1, 'priv.sudo', user='mallory', message='sudo: mallory : COMMAND=/bin/bash'), E(2, 'priv.sudo', user='a...` | `[a[1] for a in alerts()] == ['username:mallory']` | PASS | PASS |
| DET06 | FR-DET-06 | anomalous login is explainable | `base = [E(i * 3600 * 24 + 10 * 3600 + i % 3 * 600, 'auth.success', user='bob', src_ip='192.0.2.5') for i in ra...` | `alerts() == []` | PASS | PASS |
| DET07 | AC-08, FR-ALR-05, FR-DET-07 | correlation across sources and dedup | `run(scan(20, start=0) + fails(14, ip='198.51.100.7', start=30, gap=5))` | `len(a) == 1 and len(a[0][5]['rules']) == 2 and (a[0][4] > 1)` | PASS | PASS |
| DET08 | FR-ALR-08, FR-DET-08 | score range severity and asset criticality | `with SessionLocal() as db:     db.add(Asset(hostname='crown-jewel', criticality=5, owner='CFO'))     db.commit...` | `s['username:a1'] > s['username:a2']` | PASS | PASS |
| DET09 | FR-DET-09, NFR-MNT-03, SR-13 | rule crud versions test toggle rbac | `an = make_user(client, admin, 'Security Analyst', 'ana')` | `r.status_code == 201` | PASS | PASS |
| DET10 | FR-DET-10 | suppression expires and is audited | `an = make_user(client, admin, 'Security Analyst', 'ana')` | `client.post('/api/v1/suppressions', headers=H, json={'reason': 'all', 'expires_in_days': 1}).status_code == 42...` | PASS | PASS |
| DET11 | - | alert api all roles read and references rule version | `run(fails(12))` | `len(lst) == 1 and lst[0]['rules'] == ['Brute-force login attempts']` | PASS | PASS |
| TRI01 | FR-06, UC-04 | triage workflow rbac and duplicate work | `s = staff(client, admin)` | `client.patch(url, headers=admin['h'], json={'status': 'Resolved'}).status_code == 403` | PASS | PASS |
| NOT01 | FR-ALR-03, FR-ALR-06 | email for high and critical only once per level | `staff(client, admin)` | `[o for o in outbox() if o[0] == 'email' and 'alert' in o[2]] == []` | PASS | PASS |
| NOT02 | FR-ALR-04, FR-ALR-06 | user threshold and critical webhook | `s = staff(client, admin)` | `client.patch('/api/v1/auth/me/notifications', headers=s['ana'], json={'notify_email': True, 'min_severity': 'L...` | PASS | PASS |
| NOT03 | AC-10 | real smtp and webhook delivery within 60s | `staff(client, admin)` | `time.time() - t0 < 60 and sent >= 5` | PASS | PASS |
| NOT04 | SRS 8.2 | retry backoff then failed and unconfigured | `run([E(1, 'priv.sudo', user='m', message='COMMAND=/bin/bash')])` | `{o[3] for o in outbox()} == {'unconfigured'}` | PASS | PASS |
| ESC01 | FR-ALR-07 | unacknowledged critical escalates once | `s = staff(client, admin)` | `a[2] == 'Critical'` | PASS | PASS |
| WS01 | FR-ALR-02, SR-03 | live push and ws auth | `signal.signal(signal.SIGALRM, lambda *a: (_ for _ in ()).throw(TimeoutError('ws hang')))` | `ws.receive_json() == {'type': 'hello'}` | PASS | PASS |
| POLL01 | SRS 5.4 | polling fallback | `run(fails(12))` | `len(client.get(f'/api/v1/alerts?updated_after={t}', headers=admin['h']).json()) == 1` | PASS | PASS |
| RST01 | FR-AUTH-07 | password reset by time limited link | `u = make_user(client, admin, 'Auditor', 'aud')` | `[m[1] for m in mails] == ['aud@x.pk']` | PASS | PASS |
| LOCK01 | FR-AUTH-05 | admin notified on lockout and body redaction | `u = make_user(client, admin, 'Security Analyst', 'ana')` | `[o[1] for o in outbox() if 'Account locked' in o[2]] == ['r@x.pk']` | PASS | PASS |
| INC01 | FR-INC-01, SRS 7.8, UC-04 | convert alerts and rbac | `s = staff(client, admin)` | `i['status'] == 'New' and i['owner'] == 'ana' and (i['incident_type'] == 'brute_force') and (i['severity'] in (...` | PASS | PASS |
| INC02 | - | false positive alert cannot be converted | `s = staff(client, admin)` | `client.post('/api/v1/incidents', headers=s['ana'], json={'alert_ids': [a]}).status_code == 409` | PASS | PASS |
| INC03 | AC-11, FR-INC-02, FR-INC-03 | state machine timeline and audit | `s = staff(client, admin)` | `client.patch(url, headers=s['ana'], json={'status': 'Investigating'}).status_code == 409` | PASS | PASS |
| INC04 | - | reopen and false positive paths | `s = staff(client, admin)` | `client.patch(url, headers=s['ana'], json={'status': 'Investigating'}).status_code == 200` | PASS | PASS |
| INC05 | - | resolve syncs alert status | `s = staff(client, admin)` | `[a['status'] for a in client.get(url, headers=s['ana']).json()['alerts']] == ['Resolved']` | PASS | PASS |
| INC06 | FR-INC-03 | owner assignment only analysts | `s = staff(client, admin)` | `client.patch(url, headers=s['ana'], json={'owner': 'bea'}).json()['owner'] == 'bea'` | PASS | PASS |
| INC07 | AC-11, FR-INC-07, FR-RPT-03 | metrics arithmetic and fp excluded | `s = staff(client, admin)` | `(d['time_to_detect_s'], d['time_to_acknowledge_s'], d['time_to_contain_s'], d['time_to_resolve_s']) == (60, 12...` | PASS | PASS |
| INC08 | FR-INC-04 | notes evidence attachments | `s = staff(client, admin)` | `client.post(u + '/notes', headers=s['ana'], json={'text': '<b>checked</b> logs'}).status_code == 201` | PASS | PASS |
| INC09 | FR-INC-05 | playbooks by type and ticking | `s = staff(client, admin)` | `len(d['playbook']) >= 5 and any(('block' in p['text'].lower() for p in d['playbook']))` | PASS | PASS |
| INC10 | FR-INC-06, SRS 7.8 | response requires manager approval | `s = staff(client, admin)` | `client.post(f'/api/v1/incidents/{i['id']}/responses', headers=s['ana'], json={'action': 'format_disk', 'target...` | PASS | PASS |
| INC11 | - | default executor is an honest dry run | `s = staff(client, admin)` | `out['status'] == 'not_executed' and 'no firewall connector' in out['result'].lower()` | PASS | PASS |
| INC12 | - | add alerts recomputes detection time | `s = staff(client, admin)` | `client.post(url + '/alerts', headers=s['ana'], json={'alert_ids': [early]}).status_code == 200` | PASS | PASS |
| DSH01 | FR-DSH-01, FR-DSH-06 | summary roles and counts | `s = staff(client, admin)` | `d['alerts_open_by_severity']['Critical'] == 1 and sum(d['alerts_open_by_severity'].values()) == 3 and (d['unac...` | PASS | PASS |
| DSH02 | FR-DSH-02, FR-DSH-07 | trends buckets and drilldown | `run3(recent(7, 10) + recent(5, 200, message='older'))` | `sum((x['events'] for x in h)) == 7` | PASS | PASS |
| DSH03 | FR-DSH-03, SR-15 | event filters and literal search | `run3(recent(5, 10) + recent(3, 20, hostname='db01', user='alice', src_ip='192.0.2.9', severity=6, message="50%...` | `len(g(hostname='db01')) == 3 and len(g(user='bob')) == 5 and (len(g(src_ip='192.0.2.9')) == 3) and (len(g(seve...` | PASS | PASS |
| DSH04 | FR-RPT-02 | csv export neutralises formulas | `run3(recent(1, 5, message='=HYPERLINK("http://evil")') + recent(1, 6, message='+1+1') + recent(1, 7, message='...` | `r.headers['content-type'].startswith('text/csv') and 'attachment' in r.headers['content-disposition']` | PASS | PASS |
| AST01 | FR-DSH-05, SR-13 | asset inventory crud risk and rbac | `s = staff(client, admin)` | `client.post('/api/v1/assets', headers=s['ana'], json=new).status_code == 403 and client.post('/api/v1/assets',...` | PASS | PASS |
| GEO01 | FR-DSH-04 | unconfigured is honest and configured works | `run3(fails(12) + scan(20, start=100))` | `d['available'] is False and d['sources'] == []` | PASS | PASS |
| SEC01 | SR-14 | security headers | `h = client.get('/api/v1/auth/me', headers=admin['h']).headers` | `h['x-content-type-options'] == 'nosniff' and h['x-frame-options'] == 'DENY' and ("default-src 'self'" in h['co...` | PASS | PASS |
| UI01 | - | built ui is served and api routes still win | `from pathlib import Path` | `r.status_code == 200 and 'CyberShield' in r.text and ("default-src 'self'" in r.headers['content-security-poli...` | PASS | PASS |
| PERF01 | NFR-PERF-03 | shared cache serves repeat calls without requerying | `from app import routes_dashboard as rd` | `client.get('/api/v1/dashboard/summary', headers=admin['h']).json()['events_total'] == a == 5` | PASS | PASS |
| RPT01 | AC-14, FR-RPT-01 | totals match database and formats agree | `s = staff(client, admin)` | `S['events']['total'] == ev and S['alerts']['total'] == al and (S['events']['origin.simulated'] == ev)` | PASS | PASS |
| RPT02 | FR-RPT-01 | period windows and validation | `s = staff(client, admin)` | `(t('daily'), t('weekly'), t('monthly')) == (3, 7, 7)` | PASS | PASS |
| RPT03 | SRS 7.8 | export needs write role | `s = staff(client, admin)` | `get(client, h, '/reports/summary').status_code == 200 and get(client, h, '/reports/summary', format='pdf').sta...` | PASS | PASS |
| RPT04 | FR-RPT-03 | incident metrics in report match incident api | `s = staff(client, admin)` | `r['created'] == 1 and r['resolved_in_period'] == 1 and (r['open_at_end'] == 0) and (r['MTTD_s'] == m['MTTD_s']...` | PASS | PASS |
| RPT05 | - | csv formula injection neutralised | `s = staff(client, admin)` | `'=1+1' in get(client, s['man'], '/reports/summary', period='daily').json()['sections']['top_attacked_assets']` | PASS | PASS |
| SCH01 | FR-RPT-05 | schedules rbac and delivery with attachment | `s = staff(client, admin)` | `get(client, s['ana'], '/reports/schedules').status_code == 403 and client.post('/api/v1/reports/schedules', he...` | PASS | PASS |
| RET01 | FR-ADM-01, SR-13 | policy config rbac and audit | `s = staff(client, admin)` | `(d['events']['hot_days'], d['events']['archive_days']) == (30, 365) and d['audit']['enforced_by_application'] ...` | PASS | PASS |
| RET02 | FR-ADM-01, SRS 6.5 | enforcement archives keeps evidence never touches audit | `ad = str(tmp_path / 'arch')` | `r['events_archived'] == 5 and r['alerts_archived'] == 0` | PASS | PASS |
| RET03 | - | incident alerts and open alerts and expired iocs | `s = staff(client, admin)` | `r['alerts_archived'] == 1 and r['iocs_expired'] == 1` | PASS | PASS |
| BAK01 | FR-ADM-03, SR-07, UC-09 | encrypted round trip into a fresh database | `ana = make_user(client, admin, 'Security Analyst', 'ana')` | `r.status_code == 200` | PASS | PASS |
| BAK02 | - | rbac no admin guard and users optional | `s = staff(client, admin)` | `client.post('/api/v1/admin/backup', headers=admin['h'], json={'passphrase': 'short'}).status_code == 422` | PASS | PASS |
| HLT01 | FR-ADM-02, SRS 5.5 | health components public probe and worker states | `s = staff(client, admin)` | `get(client, admin['h'], '/admin/health').json()['status'] == 'degraded'` | PASS | PASS |
| STX01 | FR-ADM-05 | stix bundle import feeds detection | `s = staff(client, admin)` | `r == {'imported': 4, 'rejected': 3}` | PASS | PASS |
| CMP01 | FR-RPT-04, SRS 7.10 | compliance view is evidence not certification | `s = staff(client, admin)` | `iso['A.8.13']['status'] == 'gap' and iso['A.8.15']['status'] == 'evidence available'` | PASS | PASS |
| MNT01 | - | worker housekeeping is throttled and safe | `monkeypatch.setattr(retention.settings, 'archive_dir', str(tmp_path / 'a'), raising=False) if False else None` | `db.get(IngestMetric, 'worker_heartbeat').value > 0` | PASS | PASS |
| INT01 | SR-11 | stored event modification is detected | `s = staff(client, admin)` | `g(admin['h']).json() == {'checked': 5, 'modified': 0, 'modified_event_ids': [], 'intact': True}` | PASS | PASS |
| SWP01 | AC-02, FR-AUTH-04, SR-03 | every route enforces the role matrix | `s = staff(client, admin)` | `unclassified == []` | PASS | PASS |
| SWP02 | - | session only routes reject anonymous | `for p in ('/api/v1/auth/me', '/api/v1/users'):     assert client.get(p).status_code == 401` | `client.post('/api/v1/auth/logout').status_code == 401 and client.patch('/api/v1/auth/me/notifications', json={...` | PASS | PASS |
| SQL01 | SR-15 | no dynamic sql anywhere in the application | `offenders = []` | `offenders == []` | PASS | PASS |
| AUDRACE01 | SR-12 | concurrent audit writers keep the chain intact | `errs = []` | `errs == []` | SKIP | PASS |
| SCA01 | NFR-REL-02, NFR-SCA-01 | two parallel workers never process the same queue item | `from app import ingest` | `errs == []` | SKIP | PASS |
| SETUP02 | SRS 7.9 | first run status flips after setup | `-` | `client.get('/api/v1/setup/status').json() == {'needed': True}` | PASS | PASS |
| RECOV01 | FR-AUTH-03, FR-AUTH-05 | lost authenticator secret can be reissued | `old = admin['secret']` | `login(client, 'root', old).status_code == 200` | PASS | PASS |
| RECOV02 | - | also clears a lockout | `for _ in range(5):     login(client, 'root', admin['secret'], pw='wrong-password-123')` | `login(client, 'root', admin['secret']).status_code == 423` | PASS | PASS |
| RECOV03 | - | optional password change follows the password policy | `with pytest.raises(ValueError):     reset_mfa.reset('root', 'short')` | `login(client, 'root', admin['secret']).status_code == 200` | PASS | PASS |
| RECOV04 | - | unknown user changes nothing | `with pytest.raises(LookupError):     reset_mfa.reset('nobody')` | `login(client, 'root', admin['secret']).status_code == 200` | PASS | PASS |
