# Performance measurement (NFR-PERF-03, NFR-PERF-04)

Measured on the build sandbox, not the SRS reference deployment (8 vCPU application node plus separate database node). Treat as indicative only.

## Server with 1 worker process(es)
Data: 200,000 events (24 h), 1,000 alerts, PostgreSQL on the same machine (1 CPU cores). Background queue worker disabled to isolate request handling.
| Measure | 1 user (baseline) | 50 concurrent users |
|---|---|---|
| Dashboard load (4 API calls, sequential) | p50 0.163 s, p95 0.227 s, max 0.227 s | p50 7.876 s, p95 11.054 s, max 17.070 s |
| 24 h search, 5 combined filters | p50 0.022 s, p95 0.038 s, max 0.038 s | p50 1.398 s, p95 3.675 s, max 6.647 s |
Degradation with 50 users vs 1 user: dashboard +4729% at p50, +4774% at p95; search +6300% at p50, +9608% at p95. Errors: 0. Wall time 60 s.
Targets: dashboard p95 <= 3 s (NFR-PERF-03): NOT MET at 50 users. Search p95 <= 5 s: MET. Degradation <= 10% (NFR-PERF-04): NOT MET.


---
### BEFORE the shared dashboard cache (stress test, no think time)
(the first section above)

### AFTER adding the shared dashboard cache: stress test, no think time

## Server with 1 worker process(es), think time 0 s
Data: 200,000 events (24 h), 1,000 alerts, PostgreSQL on the same machine (1 CPU cores). Background queue worker disabled to isolate request handling.
| Measure | 1 user (baseline) | 50 concurrent users |
|---|---|---|
| Dashboard load (4 API calls, sequential) | p50 0.040 s, p95 0.051 s, max 0.051 s | p50 2.727 s, p95 4.083 s, max 5.127 s |
| 24 h search, 5 combined filters | p50 0.022 s, p95 0.027 s, max 0.027 s | p50 0.616 s, p95 1.462 s, max 2.252 s |
Degradation with 50 users vs 1 user: dashboard +6793% at p50, +7935% at p95; search +2692% at p50, +5253% at p95. Errors: 0. Wall time 23 s.
Targets: dashboard p95 <= 3 s (NFR-PERF-03): NOT MET at 50 users. Search p95 <= 5 s: MET. Degradation <= 10% (NFR-PERF-04): NOT MET.


### AFTER the cache: realistic use, each user pauses about 10 s between page loads

## Server with 1 worker process(es), think time 10 s
Data: 200,000 events (24 h), 1,000 alerts, PostgreSQL on the same machine (1 CPU cores). Background queue worker disabled to isolate request handling.
| Measure | 1 user (baseline) | 50 concurrent users |
|---|---|---|
| Dashboard load (4 API calls, sequential) | p50 0.036 s, p95 0.044 s, max 0.044 s | p50 0.064 s, p95 2.921 s, max 3.501 s |
| 24 h search, 5 combined filters | p50 0.019 s, p95 0.021 s, max 0.021 s | p50 0.029 s, p95 0.607 s, max 1.080 s |
Degradation with 50 users vs 1 user: dashboard +79% at p50, +6542% at p95; search +58% at p50, +2731% at p95. Errors: 0. Wall time 79 s.
Targets: dashboard p95 <= 3 s (NFR-PERF-03): MET at 50 users. Search p95 <= 5 s: MET. Degradation <= 10% (NFR-PERF-04): NOT MET.

