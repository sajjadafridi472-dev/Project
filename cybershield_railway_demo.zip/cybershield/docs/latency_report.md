# Alert latency measurement (NFR-PERF-02 / AC-06)

Scope: one machine, SQLite, live worker, events posted over HTTP. Offered load about 203 events/s (5500 events, 500 attackers).
This is NOT the SRS reference deployment and NOT the 5,000 events/s load, so it does not verify NFR-PERF-02 at specification load.
It measures receipt of the triggering event to alert creation; the WebSocket push adds a local in-process hop that was not timed separately.

| Metric | Value |
|---|---|
| Alerts created / expected | 500 / 500 |
| p50 | 0.37 s |
| p95 | 0.71 s (target <= 10 s) |
| p99 | 0.72 s |
| max | 0.73 s |
| Result at this load | p95 within target |
