# Accessibility check (NFR-USA-02)

**Method:** automated scan with axe-core 4.14.1 using the WCAG 2.1 level A and AA rule sets, run by `scripts/a11y_audit.py` in headless Chromium against the running application.
**Scope:** 38 page-views: the sign-in page; Dashboard, Alerts (with a selected alert), Incidents (with a selected incident), Event search, Assets, Reports (Summary, Compliance, Schedules), Detection rules, and every Administration tab; in the dark and the light theme; as Analyst, Manager and Administrator.

## First scan: 2 violations
| Rule | Impact | Problem | Fix |
|---|---|---|---|
| color-contrast | serious | White text on the primary button blue measured 3.21:1 (AA needs 4.5:1) on 9 page-views | Darker primary button colour (white on `#2563eb` is above 5:1) |
| scrollable-region-focusable | serious | The scrollable event table in the alert detail could not be reached by keyboard | All 11 scrollable table containers are now focusable regions |

## After the fixes: 0 violations on all 38 page-views

## Also checked by script (`scripts/verify_ui.py`)
The first Tab stop on a fresh page is the "Skip to content" link.

## Built in by design (not separately audited)
Visible keyboard focus outline, labelled form fields, severity shown by colour and a text label, table rows that open with Enter, table captions, live-status text, no reliance on hover, reduced-motion respected.

## Limits: why NFR-USA-02 is "Partial", not "Met"
- Automated scanners find only part of all accessibility problems. This scan did **not** include a manual keyboard-only walkthrough, a screen-reader test (NVDA, VoiceOver), zoom and text-spacing checks, or a review by users with disabilities.
- The two charts have no text alternative beyond the surrounding headings and the data tables elsewhere; a data-table view of each chart would be a useful addition.
- Only Chromium was used.
