# Requirements Traceability Matrix

Source of truth: SRS v1.0 (19 Oct 2026). The SRS counts 101 requirements (58 FR, 22 NFR, 21 SR); this matrix lists 101. Status is stated honestly:
**Met** = implemented and covered by an automated test or a recorded measurement. **Met (API only)** = works through the API with tests but has no UI screen.
**Partial** = part of the requirement is built or verified. **Not met** = measured and below the target. **Not verified** = cannot be verified in the build environment.
**Not implemented** = not built. Test IDs refer to functions in `backend/tests/` (for example `AUTH01` is `test_AUTH01_...`); the build script rejects unknown IDs.

## Summary
| Group | Total | Met | Met (API only) | Partial | Not met | Not verified | Not implemented |
|---|---|---|---|---|---|---|---|
| Functional | 58 | 47 | 3 | 8 | 0 | 0 | 0 |
| Non-functional | 22 | 3 | 0 | 9 | 4 | 6 | 0 |
| Security | 21 | 8 | 0 | 9 | 1 | 1 | 2 |
| **All** | **101** | **58** | **3** | **26** | **5** | **7** | **2** |

## Requirements
| ID | Pri | Requirement | Status | Implemented in | Tests | Notes |
|---|---|---|---|---|---|---|
| FR-AUTH-01 | M | Admin creates, edits, disables, deletes users | **Met** | routes: users; UI Administration > Users | USR01 |  |
| FR-AUTH-02 | M | Username and password authentication | **Met** | main.login; security.py | AUTH01 |  |
| FR-AUTH-03 | M | TOTP MFA for privileged roles | **Met** | main.login; security.py; backend/reset_mfa.py | AUTH02 RECOV01 | Mandatory for Administrator and Analyst (SR-02); optional for Manager and Auditor. A lost secret is recovered with reset_mfa.py on the server computer (no in-app reset yet). |
| FR-AUTH-04 | M | RBAC, at least four roles | **Met** | rbac.py; require() on every route | RBAC01 SWP01 | Matrix is SRS 7.8. Resolves the survey vs SRS conflict: Analyst, not Admin, resolves alerts. |
| FR-AUTH-05 | M | Lock 15 min after 5 failed logins and notify admin | **Met** | main.login; notify.queue_lockout | AUTH03 LOCK01 |  |
| FR-AUTH-06 | S | Idle session ends after 15 minutes | **Met** | main.resolve_session | AUTH04 |  |
| FR-AUTH-07 | S | Password reset by time-limited link | **Met** | routes_notify.py | RST01 | Needs SMTP to deliver the link. |
| FR-AUTH-08 | M | Audit every login, logout, failed login | **Met** | audit.py; main.py | AUD01 |  |
| FR-COL-01 | M | Collect from servers and endpoints via lightweight agent | **Partial** | routes_ingest POST /events (source token) | COL01 | The server side exists; no Windows or Linux agent program was written. Any client that sends JSON works. |
| FR-COL-02 | M | Receive syslog over UDP, TCP and TLS | **Partial** | syslog_listener.py; ingest.parse_syslog | COL02 COL11 | UDP and TCP only. TLS (RFC 5425) not implemented. |
| FR-COL-03 | S | Ingest application and cloud logs through REST | **Met** | routes_ingest POST /events | COL01 COL08 |  |
| FR-COL-04 | M | Normalise to a common schema | **Met** | ingest.py | COL01 COL02 |  |
| FR-COL-05 | S | Quarantine malformed events and count them | **Met** | ingest.process_queue; Quarantine table | COL03 |  |
| FR-COL-06 | M | Persistent queue, no event lost | **Met** | QueueItem table; process_queue | COL04 SCA01 | Database-backed queue, at-least-once; not Kafka or RabbitMQ. |
| FR-COL-07 | S | Register, enable, disable source without restart | **Met** | routes_ingest /sources | COL05 |  |
| FR-COL-08 | S | Last-seen and silent-source flag (10 min) | **Met** | routes_ingest._view | COL06 |  |
| FR-DET-01 | M | Signature and rule library | **Met** | detect.py (6 default rules) | DET01 DET05 | Rules are JSON data, never code. |
| FR-DET-02 | M | Brute force: more than 10 failures in 5 min | **Met** | detect.py threshold rule | DET02 |  |
| FR-DET-03 | M | Port scan detection | **Met** | detect.py distinct rule | DET03 |  |
| FR-DET-04 | M | Known-malicious IP, domain, hash via threat intel | **Met** | detect.py ioc rule; IOC table | DET04 STX01 |  |
| FR-DET-05 | S | Privilege escalation and unusual admin activity | **Met** | detect.py match rule | DET05 | Matches listed sudo shell, sudoers and setuid commands only; evasive variants are missed (see detection_evaluation.md). |
| FR-DET-06 | S | Anomaly detection with a baseline per user | **Partial** | detect.py anomaly rule | DET06 | Login hour only, statistical and explainable. No location or data-volume baselines. No machine learning. |
| FR-DET-07 | M | Correlate related events into one alert | **Met** | detect.upsert_alert | DET07 | Correlation by shared entity within 30 min. |
| FR-DET-08 | M | Severity and 0-100 risk score | **Met** | detect.risk_score | DET08 | Score components are stored and shown. |
| FR-DET-09 | S | Create, test, enable, disable, version custom rules | **Met (API only)** | routes_detect.py | DET09 | UI can list and toggle rules; creating, editing and testing are API only. |
| FR-DET-10 | S | Suppression with expiry and audit trail | **Met (API only)** | routes_detect.py /suppressions | DET10 | No UI screen. |
| FR-ALR-01 | M | Alert within 10 s of the triggering event | **Partial** | detect.process_new; ingest worker | DET11 | Measured p95 0.71 s at about 200 events/s on one machine only (latency_report.md). Not verified at 5,000 events/s. |
| FR-ALR-02 | M | New alerts on dashboard without refresh | **Met** | hub.py; routes_alerts /ws; UI live feed | WS01 POLL01 | WebSocket with 10 s polling fallback. |
| FR-ALR-03 | M | E-mail for High and Critical alerts | **Met** | notify.py outbox | NOT01 NOT03 | Delivery verified against a local fake SMTP server only, not a real mail server. |
| FR-ALR-04 | S | SMS or webhook for Critical alerts | **Partial** | notify.send_webhook | NOT02 NOT03 | Webhook only. SMS not implemented. |
| FR-ALR-05 | S | De-duplicate repeats and show occurrence count | **Met** | detect.upsert_alert | DET07 |  |
| FR-ALR-06 | C | Per-user channels and minimum severity | **Met (API only)** | routes_notify /auth/me/notifications | NOT02 | No UI screen. |
| FR-ALR-07 | S | Escalate unacknowledged Critical alert (15 min) | **Met** | notify.escalate | ESC01 | Single level, to Managers. |
| FR-ALR-08 | S | Enrich alerts with owner, criticality, intel | **Met** | routes_detect._alert; Asset; IOC | DET04 DET08 DET11 |  |
| FR-INC-01 | M | Convert alerts into an incident | **Met** | routes_incidents POST /incidents | INC01 INC02 |  |
| FR-INC-02 | M | States New, Investigating, Contained, Resolved, False Positive, Closed | **Met** | routes_incidents.FLOW | INC03 INC04 | Closed is final by design. |
| FR-INC-03 | M | Owner and every state change with user and time | **Met** | IncidentEntry; audit | INC03 INC06 |  |
| FR-INC-04 | S | Notes, attachments, evidence links | **Met** | routes_incidents.py | INC08 | 1 MB limit, allowlisted file types, SHA-256 per file. |
| FR-INC-05 | S | Response playbooks | **Met** | playbooks.py | INC09 | Five checklists based on NIST SP 800-61 phases. |
| FR-INC-06 | C | Optional automated response with approval | **Partial** | routes_incidents /responses; respond.py | INC10 INC11 | Approval workflow works. No firewall connector exists, so approved actions are recorded as not executed. |
| FR-INC-07 | M | Time to detect, acknowledge, contain, resolve | **Met** | routes_incidents._metrics | INC07 RPT04 |  |
| FR-DSH-01 | M | Home dashboard: counts, top assets, top sources | **Met** | routes_dashboard; UI Dashboard | DSH01 |  |
| FR-DSH-02 | M | Trends over 1 h, 24 h, 7 d, 30 d | **Met** | routes_dashboard /trends | DSH02 |  |
| FR-DSH-03 | M | Search and filter events | **Met** | routes_ingest /events | DSH03 |  |
| FR-DSH-04 | C | Geographic view of attack sources | **Partial** | geo.py; /dashboard/geo | GEO01 | Per-country counts only, and only if GEOIP_CSV is supplied. No map. No GeoIP database is bundled. |
| FR-DSH-05 | S | Asset inventory with risk score | **Met** | routes_dashboard /assets | AST01 |  |
| FR-DSH-06 | S | Role-specific landing view | **Met** | routes_dashboard LANDING; UI App.jsx | DSH01 | UI behaviour verified by scripts/verify_ui.py. |
| FR-DSH-07 | S | Drill down from chart elements to events | **Met** | UI Dashboard; /events start,end | DSH02 | Bucket range returns exactly the bucketed events. |
| FR-RPT-01 | M | Daily, weekly, monthly summary reports | **Met** | report.py | RPT01 RPT02 |  |
| FR-RPT-02 | M | Export reports and search results as PDF and CSV | **Met** | report.py; /events?format=csv | RPT01 RPT03 DSH04 | Search export is CSV only; reports are PDF and CSV. |
| FR-RPT-03 | S | MTTD and MTTR per period | **Met** | report.build | RPT04 | Definitions are printed on every report. |
| FR-RPT-04 | C | Compliance view mapping controls to evidence | **Met** | routes_reports /compliance | CMP01 | Design-intent evidence only, not certification (SRS 7.10). |
| FR-RPT-05 | C | Scheduled report delivery by e-mail | **Met** | report.run_due | SCH01 | Needs SMTP. |
| FR-ADM-01 | M | Retention per data category | **Met** | retention.py | RET01 RET02 RET03 | Archive files are compressed and not searchable. Incidents and audit are never auto-deleted. |
| FR-ADM-02 | S | Health page for each component | **Met** | routes_admin /admin/health | HLT01 |  |
| FR-ADM-03 | S | Configuration backup and restore | **Met** | backup.py | BAK01 BAK02 | Restore merges by key; it does not delete items missing from the backup. |
| FR-ADM-04 | M | Immutable, searchable audit log | **Met** | audit.py; dbsetup.py | AUD02 AUDRACE01 | Append-only through database triggers (SQLite and PostgreSQL) and a hash chain. |
| FR-ADM-05 | S | Import and update threat-intel feeds (STIX/TAXII or CSV) | **Partial** | routes_detect /iocs/import; routes_admin /iocs/import-stix | DET04 STX01 | CSV and STIX 2.1 file import. No TAXII polling and no scheduled updates. |
| NFR-PERF-01 | M | Ingest 5,000 events/s on reference deployment | **Not verified** | ingest.py | - | Measured about 2,600 events/s end to end on a 1-CPU SQLite sandbox (bench.py). Not measured on PostgreSQL or reference hardware. |
| NFR-PERF-02 | M | p95 event-to-alert time 10 s or less | **Partial** | detect.py; latency_test.py | DET11 | p95 0.71 s at about 200 events/s on one machine. Not verified at spec load. |
| NFR-PERF-03 | M | Dashboard under 3 s, 24 h search under 5 s (p95) | **Partial** | routes_dashboard cache; perf_test.py | PERF01 | 1 CPU, 200k events, 50 users with think time: dashboard p95 2.9 s, search p95 0.6 s. Continuous-click stress: dashboard p95 4.1 s. |
| NFR-PERF-04 | S | 50 concurrent users with at most 10% slowdown | **Not met** | perf_test.py | - | Median dashboard time rose from 36 ms to 64 ms (+79%). Absolute times are small, but the 10% criterion is not met. |
| NFR-REL-01 | M | 99.5% monthly availability | **Not verified** | - | - | Needs a 30-day pilot with an external probe. |
| NFR-REL-02 | M | No accepted event lost on single-component failure | **Partial** | QueueItem; process_queue | COL04 SCA01 | Tested for a processing crash and for parallel workers. Not tested for database failover. |
| NFR-REL-03 | S | Automatic recovery within 2 minutes | **Not verified** | worker loop; docker-compose restart policy | - | Worker retries after errors. Process restart relies on the container restart policy, which was not run here. |
| NFR-REL-04 | S | RPO 15 min, RTO 4 h | **Not verified** | backup.py (configuration only) | - | No database backup or point-in-time recovery is configured. Use PostgreSQL tooling. |
| NFR-USA-01 | S | Triage and create incident in 5 clicks or fewer | **Met** | UI | - | scripts/verify_ui.py: 2 clicks from the dashboard. |
| NFR-USA-02 | S | WCAG 2.1 AA contrast and keyboard navigation | **Partial** | UI styles | - | Automated axe-core scan: 0 WCAG 2.1 A/AA violations on 38 page-views after fixing 2 (accessibility_report.md). No manual keyboard or screen-reader review; automated scans find only part of all problems. |
| NFR-USA-03 | S | New analyst completes tasks after 2 h training | **Not verified** | - | - | Needs a user study. |
| NFR-USA-04 | C | English now, localisation later | **Partial** | UI | - | English only. Strings are in the source, not externalised. |
| NFR-SCA-01 | S | Doubling nodes gives 1.6x throughput | **Not verified** | FOR UPDATE SKIP LOCKED claims | SCA01 | Parallel workers are safe, but throughput scaling was not measured (1-CPU sandbox). |
| NFR-MNT-01 | S | 80% unit-test coverage on detection and correlation | **Met** | tests/ | - | Line coverage: detect.py 95%, whole application 97% (PostgreSQL run). Branch coverage not measured. |
| NFR-MNT-02 | S | Standard-format logs and metrics | **Partial** | routes_admin /admin/health | HLT01 | Health and counters exist; not a standard format such as Prometheus. |
| NFR-MNT-03 | M | Rule updates without downtime | **Met** | detect.process_new reads rules per batch | DET09 |  |
| NFR-POR-01 | S | Containers on any Linux host | **Partial** | backend/Dockerfile; docker-compose.yml | - | Files written but never built or run: no Docker in the build sandbox. |
| NFR-POR-02 | M | Current and previous Chrome, Firefox, Edge, Safari | **Partial** | UI | UI01 | Tested in Chromium only. |
| NFR-POR-03 | M | Agent for Windows 10/11, Server 2016+, Linux | **Not met** | - | - | No agent was built. |
| NFR-ACC-01 | M | Recall 90% or more per attack class | **Not met** | detect.py | - | 76% overall on synthetic scenarios, 70-85% per class (detection_evaluation.md). |
| NFR-ACC-02 | M | False-positive share 5% or less | **Not met** | detect.py | - | 7.5% on synthetic scenarios (9 of 120 alerts). |
| NFR-ACC-03 | S | Timestamps within 1 s of a trusted time source | **Partial** | Event.timestamp and received_at | - | Source and receive times are both stored. Clock synchronisation is not checked. |
| SR-01 | M | 12+ char passwords, breached-list check, Argon2id or bcrypt | **Partial** | security.py | PWD01 | Argon2id and 12 characters are enforced. The common-password check uses a 10-entry list, not a breached-password database. |
| SR-02 | M | MFA mandatory for Administrator and Analyst | **Met** | rbac.MFA_REQUIRED | AUTH02 |  |
| SR-03 | M | Least privilege, server-side authorisation on every call | **Met** | require() on 62 routes | RBAC01 SWP01 | Sweep tests every route against every role. |
| SR-04 | M | Random short-lived tokens, 8 h maximum, revoked on logout | **Met** | security.py; Session table | AUTH04 AUTH05 | Only token hashes are stored. |
| SR-05 | M | Unique revocable credentials for agents and services | **Partial** | routes_ingest /sources | COL05 | Per-source revocable tokens. No client certificates or mutual TLS. |
| SR-06 | M | TLS 1.2+ for all traffic | **Not verified** | deploy/Caddyfile; security headers | SEC01 | TLS is terminated by a reverse proxy that was not run here. The syslog UDP/TCP listener is plaintext and flagged in the UI. |
| SR-07 | M | Encryption at rest (database, archive, backups) | **Partial** | backup.py | BAK01 | Configuration backups are AES-256-GCM. Database and archive encryption depends on deployment (disk or database encryption). |
| SR-08 | M | Secrets in a secret store, never in code or config files | **Partial** | config.py (environment) | - | No secrets in code. Read from environment variables. No dedicated secret-store integration. |
| SR-09 | S | Minimise and mask personal data in logs | **Partial** | notify.py | - | E-mails carry metadata only. No masking options for stored log content. |
| SR-10 | C | Data-subject export and deletion | **Not implemented** | - | - |  |
| SR-11 | S | Hash events on receipt and detect modification | **Met** | ingest.py; routes_admin /admin/integrity/events | INT01 | Covers the raw text. Normalised fields are not hashed. |
| SR-12 | M | Append-only audit log, even for Administrator | **Met** | dbsetup.py; audit.py | AUD02 AUDRACE01 | Verified on SQLite and PostgreSQL, including database-level blocks on update, delete and truncate. |
| SR-13 | M | Config and rule changes record who, what, when, previous value | **Met** | audit.log calls | DET09 RET01 AST01 USR01 |  |
| SR-14 | M | Input validation, output encoding, OWASP Top 10 tested | **Partial** | pydantic models; React; CSP | SEC01 SQLI01 COL07 | Validation, escaping and headers in place. No OWASP ZAP scan was run. See SECURITY_REPORT.md. |
| SR-15 | M | Parameterised queries only | **Met** | SQLAlchemy | SQL01 SQLI01 | A static test fails the build if any raw SQL is built dynamically. |
| SR-16 | M | Dependency scanning in CI; Critical findings block release | **Partial** | .github/workflows/ci.yml | - | pip-audit, npm audit and bandit were run and are clean. The CI workflow was written but not run. |
| SR-17 | S | Rate-limit authentication and API endpoints | **Partial** | main.rate_limit | - | Login, password reset and per-source ingest are limited. In memory, per process. Other routes are not limited. |
| SR-18 | S | Non-root containers, read-only filesystem, minimal pinned images | **Partial** | backend/Dockerfile; docker-compose.yml | - | Configured, not built or run. |
| SR-19 | M | Penetration test or red-team exercise | **Not met** | - | - | None performed. The scripted checks in SECURITY_REPORT.md are not a penetration test. |
| SR-20 | S | Agent self-protection; alert when stopped | **Not implemented** | - | - | No agent. A source that goes silent is flagged (FR-COL-08). |
| SR-21 | M | Treat log content as untrusted | **Met** | ingest.clean; detect.validate_logic | COL07 SQL01 | Control characters stripped, strict rule schema with no regex or code. |

## Acceptance criteria (SRS section 9)
| ID | Area | Status | Tests | Evidence |
|---|---|---|---|---|
| AC-01 | Authentication | **Met** | AUTH01 AUTH02 AUTH03 LOCK01 |  |
| AC-02 | RBAC | **Met** | SWP01 RBAC01 | 62 routes x 4 roles + anonymous, 0 violations. Forbidden calls return 403. |
| AC-03 | Log collection (5 source types) | **Partial** | COL01 COL11 | Agent, API, IDS via REST, syslog via import and UDP listener. No real Windows or Linux agent. |
| AC-04 | No data loss | **Partial** | COL04 SCA01 | Tested at the processing step, not by stopping a real queue and node. |
| AC-05 | Throughput 5,000 events/s for 60 min | **Not verified** | - | About 2,600 events/s measured on SQLite, 1 CPU, short run. |
| AC-06 | Alert latency p95 10 s or less | **Partial** | - | p95 0.71 s at about 200 events/s, 500 triggers (latency_report.md). |
| AC-07 | Rule detection recall 90% per class | **Not met** | - | 76% overall on the synthetic scenarios. |
| AC-08 | Anomaly and correlation scenarios | **Partial** | DET06 DET07 | Correlation 20 of 20 on synthetic two-source scenarios. |
| AC-09 | False positives 5% or less (200 alerts, 7 days) | **Not met** | - | 7.5% on 120 alerts; the required analyst-labelled 7-day study was not done. |
| AC-10 | Notification within 60 s | **Partial** | NOT03 | Functional path against fake servers only. |
| AC-11 | Incident life cycle and metrics | **Met** | INC03 INC07 |  |
| AC-12 | 24 h search p95 5 s or less | **Partial** | - | p95 0.6 s on 1 CPU with 200k events (performance_report.md). |
| AC-13 | Dashboard with 50 concurrent users, p95 3 s or less | **Partial** | WS01 | Realistic load p95 2.9 s; stress p95 4.1 s; 1 CPU. |
| AC-14 | Reports match the database | **Met** | RPT01 | 0% difference across JSON, CSV, PDF and the database. |
| AC-15 | Audit log complete and immutable | **Met** | AUD01 AUD02 | Update and delete blocked in the database itself. |
| AC-16 | Encryption in transit and at rest | **Not verified** | BAK01 | Configuration backups only; the rest is a deployment matter. |
| AC-17 | OWASP ZAP and manual Top 10 tests | **Partial** | SEC01 SQLI01 SWP01 SQL01 | No ZAP run. Scripted checks and static analysis only. |
| AC-18 | Penetration test | **Not met** | - | Not performed. |
| AC-19 | Availability 99.5% in a 30-day pilot | **Not verified** | - | Needs a pilot. |
| AC-20 | Usability test with 5 or more analysts | **Not verified** | - | Not performed. Click count measured by script: 2. |
| AC-21 | Documentation delivered | **Partial** | - | Delivered in this package; client acceptance is outstanding. |

The SRS Appendix A traces user requirements only for FR and some SR items. This matrix extends it to every FR, NFR and SR (suggested addition, not an SRS change).
