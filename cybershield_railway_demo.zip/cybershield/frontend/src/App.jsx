import { useEffect, useState, useCallback } from "react";
import { api, token } from "./api";
import { Ctx, useData, Err, Field } from "./ui";
import { useRoute, go } from "./route";
import { Dashboard, Alerts } from "./pages1";
import { Incidents, Events } from "./pages2";
import { Assets, Rules, Admin } from "./pages3";
import { Reports } from "./pages4";

const NAV = [["dashboard", "Dashboard", ["Administrator", "Security Analyst", "Manager", "Auditor"]], ["alerts", "Alerts", ["Administrator", "Security Analyst", "Manager", "Auditor"]],
  ["incidents", "Incidents", ["Security Analyst", "Manager", "Auditor"]], ["events", "Event search", ["Administrator", "Security Analyst", "Manager", "Auditor"]],
  ["assets", "Assets", ["Administrator", "Security Analyst", "Manager", "Auditor"]], ["reports", "Reports", ["Administrator", "Security Analyst", "Manager", "Auditor"]], ["rules", "Detection rules", ["Administrator", "Security Analyst", "Auditor"]],
  ["admin", "Administration", ["Administrator", "Manager", "Auditor"]]];
const LANDING = { "Security Analyst": "alerts", Manager: "dashboard", Auditor: "admin", Administrator: "admin" }; // FR-DSH-06: role-specific landing view (auditor opens the audit log tab)
const PAGES = { dashboard: Dashboard, alerts: Alerts, incidents: Incidents, events: Events, assets: Assets, reports: Reports, rules: Rules, admin: Admin };

function FirstRun({ onDone, tokenRequired }) {
  const [f, setF] = useState({ username: "", name: "", email: "", password: "", setup_token: "" }); const [err, setErr] = useState(""); const [made, setMade] = useState(null); const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async (e) => { e.preventDefault(); setErr(""); try { const { setup_token, ...account } = f; setMade(await api("/setup", { method: "POST", body: account, headers: setup_token ? { "X-Setup-Token": setup_token } : {} })); } catch (x) { setErr(x.message); } };
  if (made) return <main className="login"><div className="panel" style={{ width: "min(480px,100%)" }}><h1>Save your authenticator secret</h1><p>Add this secret to an authenticator app now. It is shown only once and you need a code from it to sign in.</p>
    <p className="mono" style={{ wordBreak: "break-all", fontSize: "1.1rem" }}>{made.mfa_secret}</p><button className="btn primary" onClick={onDone}>I have saved it, continue to sign in</button></div></main>;
  return <main className="login"><form onSubmit={submit} className="panel"><h1>Welcome to CyberShield</h1><p className="muted">No accounts exist yet. Create the first administrator.</p>
    <Field label="Username"><input value={f.username} onChange={set("username")} required autoFocus /></Field><Field label="Full name"><input value={f.name} onChange={set("name")} required /></Field><Field label="Email"><input type="email" value={f.email} onChange={set("email")} required /></Field>
    <Field label="Password (12+ characters)"><input type="password" autoComplete="new-password" value={f.password} onChange={set("password")} required /></Field>{tokenRequired && <Field label="Deployment setup token"><input type="password" autoComplete="off" value={f.setup_token} onChange={set("setup_token")} required /></Field>}<Err msg={err} /><button className="btn primary">Create administrator</button></form></main>;
}

function Login({ onDone }) {
  const [f, setF] = useState({ username: "", password: "", otp: "" }); const [err, setErr] = useState(""); const [needOtp, setNeedOtp] = useState(false); const [mode, setMode] = useState("login"); const [msg, setMsg] = useState("");
  const reset = new URLSearchParams(location.hash.split("?")[1] || "").get("token");
  async function submit(e) {
    e.preventDefault(); setErr(""); setMsg("");
    try {
      if (mode === "forgot") { await api("/auth/password-reset/request", { method: "POST", body: { email: f.username } }); setMsg("If that account exists, a reset link has been sent."); return; }
      if (reset) { await api("/auth/password-reset/confirm", { method: "POST", body: { token: reset, new_password: f.password } }); setMsg("Password changed. Sign in with your new password."); location.hash = "#/"; return; }
      const r = await api("/auth/login", { method: "POST", body: { username: f.username, password: f.password, otp: f.otp || undefined } });
      sessionStorage.setItem("cs_token", r.token); onDone(r.user);
    } catch (x) { if (x.message === "MFA code required") setNeedOtp(true); setErr(x.message); }
  }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return <main className="login"><form onSubmit={submit} className="panel">
    <h1>CyberShield</h1><p className="muted">Security monitoring and incident response</p>
    {reset ? <><h2>Choose a new password</h2><Field label="New password (12+ characters)"><input type="password" autoComplete="new-password" value={f.password} onChange={set("password")} required /></Field></>
      : mode === "forgot" ? <Field label="Account email"><input type="email" value={f.username} onChange={set("username")} required /></Field>
      : <><Field label="Username"><input autoComplete="username" value={f.username} onChange={set("username")} required autoFocus /></Field>
          <Field label="Password"><input type="password" autoComplete="current-password" value={f.password} onChange={set("password")} required /></Field>
          {needOtp && <Field label="Authenticator code (6 digits)"><input inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={f.otp} onChange={set("otp")} required autoFocus /></Field>}</>}
    <Err msg={err} />{msg && <p role="status" className="ok">{msg}</p>}
    <button className="btn primary" type="submit">{reset ? "Save new password" : mode === "forgot" ? "Send reset link" : needOtp ? "Verify and sign in" : "Sign in"}</button>
    {!reset && <button type="button" className="linkbtn" onClick={() => { setMode(mode === "login" ? "forgot" : "login"); setErr(""); setMsg(""); }}>{mode === "login" ? "Forgot your password?" : "Back to sign in"}</button>}
  </form></main>;
}

function OriginBar() {
  const { data } = useData(() => api("/dashboard/summary"), []); if (!data) return null;
  const o = data.events_by_origin, t = data.events_total || 1, sim = o.simulated > 0;
  return <div className="originbar" role="group" aria-label="Where the event data comes from">
    <div className="bar" aria-hidden="true">{["live", "imported", "simulated"].map((k) => <i key={k} className={"seg seg-" + k} style={{ width: (100 * o[k]) / t + "%" }} />)}</div>
    <span>Live {o.live.toLocaleString()}</span><span>Imported {o.imported.toLocaleString()}</span><span>Simulated {o.simulated.toLocaleString()}</span>
    {sim && <strong className="simwarn">Simulated data is present. It is not real monitoring.</strong>}
  </div>;
}

export default function App() {
  const [user, setUser] = useState(null); const [first, setFirst] = useState(false); const [setupTokenRequired, setSetupTokenRequired] = useState(false); const [booting, setBooting] = useState(!!token()); const [tick, setTick] = useState(0); const [live, setLive] = useState("connecting");
  const [theme, setTheme] = useState(localStorage.getItem("cs_theme") || "dark"); const route = useRoute();
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem("cs_theme", theme); }, [theme]);
  useEffect(() => { api("/setup/status").then((r) => { setFirst(r.needed); setSetupTokenRequired(!!r.token_required); }).catch(() => {}); }, []);
  useEffect(() => { if (token()) api("/auth/me").then((u) => { setUser(u); if (!location.hash || location.hash === "#/") go(LANDING[u.role] || "dashboard"); }).catch(() => {}).finally(() => setBooting(false)); }, []);
  useEffect(() => { const f = () => setUser(null); addEventListener("cs-logout", f); return () => removeEventListener("cs-logout", f); }, []);
  useEffect(() => {
    if (!user) return; let ws, t, poll, stop = false; const bump = () => setTick((x) => x + 1);
    const connect = () => {
      ws = new WebSocket((location.protocol === "https:" ? "wss" : "ws") + "://" + location.host + "/api/v1/ws");
      ws.onopen = () => ws.send(JSON.stringify({ token: token() }));
      ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.type === "hello") { setLive("live"); clearInterval(poll); } else if (m.type === "alert" || m.type === "incident") bump(); };
      ws.onclose = () => { if (stop) return; setLive("polling"); clearInterval(poll); poll = setInterval(bump, 10000); t = setTimeout(connect, 5000); };
    }; connect();
    return () => { stop = true; ws && ws.close(); clearTimeout(t); clearInterval(poll); };
  }, [user]);
  const logout = useCallback(async () => { try { await api("/auth/logout", { method: "POST" }); } catch {} sessionStorage.removeItem("cs_token"); setUser(null); }, []);
  if (booting) return <p className="empty">Loading</p>;
  if (!user && first) return <FirstRun tokenRequired={setupTokenRequired} onDone={() => setFirst(false)} />;
  if (!user) return <Login onDone={(u) => { setUser(u); if (!location.hash || location.hash.startsWith("#/reset")) go(LANDING[u.role] || "dashboard"); }} />;
  const items = NAV.filter(([, , roles]) => roles.includes(user.role)); const Page = PAGES[route.page] && items.some(([k]) => k === route.page) ? PAGES[route.page] : null;
  return <Ctx.Provider value={{ user, tick, live, route }}>
    <a className="skip" href="#main">Skip to content</a>
    <div className="shell">
      <nav className="side" aria-label="Main"><div className="brand">CyberShield</div>
        {items.map(([k, l]) => <a key={k} href={"#/" + k} aria-current={route.page === k ? "page" : undefined}>{l}</a>)}
        <div className="grow" /><button className="linkbtn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}</button>
      </nav>
      <div className="content">
        <header className="top"><OriginBar />
          <div className="who"><span className={"dot dot-" + live} aria-hidden="true" /><span role="status">{live === "live" ? "Live feed connected" : live === "polling" ? "Live feed offline, refreshing every 10 s" : "Connecting"}</span>
            <span className="muted">{user.username} ({user.role})</span><button className="btn" onClick={logout}>Sign out</button></div></header>
        <main id="main" tabIndex={-1}>{Page ? <Page /> : <p className="empty">You do not have access to this page. Choose another section from the menu.</p>}</main>
      </div>
    </div>
  </Ctx.Provider>;
}
