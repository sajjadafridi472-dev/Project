export const token = () => sessionStorage.getItem("cs_token");
export async function api(path, { method = "GET", body, raw, headers = {} } = {}) {
  const r = await fetch("/api/v1" + path, { method, headers: { ...(token() ? { Authorization: "Bearer " + token() } : {}), ...(body ? { "Content-Type": "application/json" } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 401 && token()) { sessionStorage.removeItem("cs_token"); window.dispatchEvent(new Event("cs-logout")); }
  if (raw) return r;
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error(typeof j?.detail === "string" ? j.detail : Array.isArray(j?.detail) ? j.detail.map((d) => d.msg).join("; ") : "Request failed (" + r.status + ")");
  return j;
}
const utc = (t) => (t ? new Date(/Z|[+-]\d\d:\d\d$/.test(t) ? t : t + "Z") : null);
export const fmt = (t) => (t ? utc(t).toISOString().slice(0, 19).replace("T", " ") + " UTC" : "-");
export const dur = (s) => (s == null ? "-" : s < 90 ? s + " s" : s < 5400 ? Math.round(s / 60) + " min" : (s / 3600).toFixed(1) + " h");
export async function download(path, name) {
  const r = await api(path, { raw: true }); if (!r.ok) throw new Error("Export failed (" + r.status + ")");
  const a = document.createElement("a"); a.href = URL.createObjectURL(await r.blob()); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
