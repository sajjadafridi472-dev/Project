import { Fragment, useState } from "react";
import { api, fmt, dur, download } from "./api";
import { useApp, useData, Status, Err, Empty, Field, Mono, Tabs, Confirm } from "./ui";

const pretty = (k, v) => (k.endsWith("_s") ? dur(v) : v == null ? "-" : typeof v === "number" ? v.toLocaleString() : String(v));
const SECTION = { events: "Events", alerts: "Alerts", top_attack_sources: "Top attack sources", top_attacked_assets: "Top attacked assets", incidents: "Incidents", ingestion_since_start: "Ingestion since start" };

function Summary() {
  const { user } = useApp(); const [period, setPeriod] = useState("weekly"); const r = useData(() => api("/reports/summary?period=" + period), [period]); const [err, setErr] = useState(""); const can = ["Manager", "Auditor"].includes(user.role); const d = r.data;
  const exp = (f) => async () => { try { setErr(""); await download("/reports/summary?period=" + period + "&format=" + f, "cybershield-" + period + "." + f); } catch (e) { setErr(e.message); } };
  return <><div className="row between" style={{ marginBottom: 12 }}><div className="row" role="group" aria-label="Report period">{["daily", "weekly", "monthly"].map((p) => <button key={p} className={"btn" + (p === period ? " primary" : "")} aria-pressed={p === period} onClick={() => setPeriod(p)}>{p[0].toUpperCase() + p.slice(1)}</button>)}</div>
    {can ? <div className="row"><button className="btn" onClick={exp("pdf")}>Export PDF</button><button className="btn" onClick={exp("csv")}>Export CSV</button></div> : <span className="muted">Your role can view reports but not export them.</span>}</div>
    <Err msg={r.err || err} />{d && <>
      <p className="muted">Period {fmt(d.start)} to {fmt(d.end)}. {d.notes.map((n, i) => <span key={i} style={{ display: "block", color: n.includes("SIMULATED") ? "var(--amber)" : undefined }}>{n}</span>)}</p>
      <div className="grid g22">{Object.entries(d.sections).map(([sec, kv]) => <section key={sec} className="panel"><h2>{SECTION[sec] || sec}</h2>{Object.keys(kv).length === 0 ? <Empty>Nothing in this period.</Empty> : <table><tbody>{Object.entries(kv).map(([k, v]) => <tr key={k}><td>{k}</td><td className="num">{pretty(k, v)}</td></tr>)}</tbody></table>}</section>)}</div>
      <p className="muted" style={{ marginTop: 12 }}>{d.definitions}</p></>}</>;
}

function Compliance() {
  const [fw, setFw] = useState("iso27001"); const r = useData(() => api("/compliance/" + fw), [fw]); const d = r.data;
  return <><div className="row" style={{ marginBottom: 12 }}><Field label="Framework"><select value={fw} onChange={(e) => setFw(e.target.value)}><option value="iso27001">ISO/IEC 27001:2022</option><option value="nist_csf">NIST CSF 2.0</option></select></Field></div><Err msg={r.err} />
    {d && <><p className="muted">{d.disclaimer}</p><div className="grid g22">{d.controls.map((c) => <section key={c.id} className="panel"><div className="row between"><h3>{c.id} {c.title}</h3><span className={c.status === "gap" ? "err" : "ok"}>{c.status === "gap" ? "Gap: no evidence" : "Evidence available"}</span></div>
      <dl className="kv">{Object.entries(c.evidence).map(([k, v]) => <Fragment key={k}><dt>{k.replaceAll("_", " ")}</dt><dd>{v == null ? "-" : String(v)}</dd></Fragment>)}</dl></section>)}</div></>}</>;
}

function Schedules() {
  const l = useData(() => api("/reports/schedules"), []); const [f, setF] = useState({ period: "weekly", format: "pdf" }); const [err, setErr] = useState("");
  const add = async (e) => { e.preventDefault(); try { setErr(""); await api("/reports/schedules", { method: "POST", body: f }); l.reload(); } catch (x) { setErr(x.message); } };
  return <><p className="muted">Scheduled reports are e-mailed to your account address. Delivery needs SMTP to be configured by the administrator.</p><Err msg={l.err || err} />
    <form className="panel row" style={{ alignItems: "end", marginBottom: 14 }} onSubmit={add}><Field label="How often"><select value={f.period} onChange={(e) => setF({ ...f, period: e.target.value })}><option>daily</option><option>weekly</option><option>monthly</option></select></Field><Field label="Format"><select value={f.format} onChange={(e) => setF({ ...f, format: e.target.value })}><option>pdf</option><option>csv</option></select></Field><button className="btn primary">Add schedule</button></form>
    <div className="panel">{!l.data?.length ? <Empty>You have no scheduled reports.</Empty> : <table><thead><tr><th>Period</th><th>Format</th><th>Last sent</th><th /></tr></thead><tbody>{l.data.map((s) => <tr key={s.id}><td>{s.period}</td><td>{s.format}</td><td>{fmt(s.last_run_at)}</td><td><Confirm text="Remove this schedule?" onYes={async () => { try { setErr(""); await api("/reports/schedules/" + s.id, { method: "DELETE" }); l.reload(); } catch (x) { setErr(x.message); } }}>Remove</Confirm></td></tr>)}</tbody></table>}</div></>;
}

export function Reports() {
  const { user } = useApp(); const tabs = [["summary", "Summary"], ["compliance", "Compliance"], ...(["Manager", "Auditor"].includes(user.role) ? [["schedules", "Schedules"]] : [])]; const [tab, setTab] = useState("summary");
  return <><h1>Reports</h1><Tabs tabs={tabs} cur={tab} set={setTab} />{tab === "summary" && <Summary />}{tab === "compliance" && <Compliance />}{tab === "schedules" && <Schedules />}</>;
}

export function Retention() {
  const { user } = useApp(); const l = useData(() => api("/admin/retention"), []); const [err, setErr] = useState(""); const [msg, setMsg] = useState(""); const [vals, setVals] = useState({}); const admin = user.role === "Administrator";
  const save = async (c) => { try { setErr(""); const v = vals[c.category] || {}; await api("/admin/retention/" + c.category, { method: "PUT", body: { hot_days: Number(v.hot ?? c.hot_days), archive_days: Number(v.arch ?? c.archive_days) } }); setMsg("Saved " + c.category + "."); l.reload(); } catch (e) { setErr(e.message); } };
  const run = async () => { try { setErr(""); const r = await api("/admin/retention/run", { method: "POST" }); setMsg("Retention run: " + r.events_archived + " events and " + r.alerts_archived + " alerts archived, " + r.iocs_expired + " indicators expired, " + r.archive_files_deleted + " archive files deleted."); } catch (e) { setErr(e.message); } };
  return <><p className="muted">Hot data is searchable. After the hot period, events and alerts are written to a compressed archive file, which is not searchable, and deleted after the archive period. Events that an alert still refers to are kept as evidence. Confirm periods with your legal and compliance staff.</p><Err msg={l.err || err} />{msg && <p role="status" className="ok">{msg}</p>}
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable"><table><thead><tr><th>Category</th><th>Hot (days)</th><th>Archive (days)</th><th>Enforced by the application</th>{admin && <th />}</tr></thead><tbody>{(l.data || []).map((c) => <tr key={c.category}><td>{c.category}</td>
      <td>{admin ? <input aria-label={c.category + " hot days"} type="number" min="1" max="3650" style={{ width: 90 }} defaultValue={c.hot_days} onChange={(e) => setVals({ ...vals, [c.category]: { ...vals[c.category], hot: e.target.value } })} /> : c.hot_days}</td>
      <td>{admin ? <input aria-label={c.category + " archive days"} type="number" min="0" max="3650" style={{ width: 90 }} defaultValue={c.archive_days} onChange={(e) => setVals({ ...vals, [c.category]: { ...vals[c.category], arch: e.target.value } })} /> : c.archive_days}</td>
      <td>{c.enforced_by_application ? "Yes" : "No"}<br /><small className="muted">{c.note}</small></td>{admin && <td><button className="btn sm" onClick={() => save(c)}>Save</button></td>}</tr>)}</tbody></table></div>
    {admin && <div style={{ marginTop: 12 }}><Confirm text="Run retention now? Events and alerts past their hot period will be moved to archive files and removed from search." onYes={run}>Run retention now</Confirm></div>}</>;
}

export function Backup() {
  const [pp, setPp] = useState(""); const [users, setUsers] = useState(false); const [err, setErr] = useState(""); const [msg, setMsg] = useState("");
  const backup = async () => { try { setErr(""); const r = await api("/admin/backup", { method: "POST", body: { passphrase: pp, include_users: users }, raw: true }); if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(typeof j.detail === "string" ? j.detail : Array.isArray(j.detail) ? j.detail.map((d) => d.msg).join("; ") : "Backup failed"); } const a = document.createElement("a"); a.href = URL.createObjectURL(await r.blob()); a.download = "cybershield-config.csbak"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); setMsg("Backup downloaded. Store it and the passphrase separately."); } catch (e) { setErr(e.message); } };
  const restore = (e) => { const file = e.target.files[0]; if (!file) return; if (!window.confirm("Restore settings from " + file.name + "? Items in the backup replace matching items here. Events, alerts, incidents and the audit log are not changed.")) { e.target.value = ""; return; }
    const r = new FileReader(); r.onload = async () => { try { setErr(""); const bytes = new Uint8Array(r.result); let bin = ""; bytes.forEach((b) => (bin += String.fromCharCode(b))); const out = await api("/admin/restore", { method: "POST", body: { passphrase: pp, backup_base64: btoa(bin), include_users: users } }); setMsg("Restored: " + Object.entries(out.restored).map(([k, v]) => v + " " + k).join(", ") + "."); } catch (x) { setErr(x.message); } e.target.value = ""; }; r.readAsArrayBuffer(file); };
  return <div className="panel" style={{ maxWidth: 640 }}><p className="muted">Configuration backups cover assets, rules and their history, suppressions, log sources, threat indicators and retention settings. They are encrypted with AES-256-GCM using your passphrase. Without users, no password hashes or MFA secrets are included. With users, treat the file like a secret.</p>
    <Field label="Passphrase (12+ characters, needed to restore)"><input type="password" autoComplete="off" value={pp} onChange={(e) => setPp(e.target.value)} /></Field>
    <label className="row" style={{ margin: "10px 0" }}><input type="checkbox" checked={users} onChange={(e) => setUsers(e.target.checked)} /> Include user accounts, password hashes and MFA secrets</label>
    <div className="row"><button className="btn primary" onClick={backup} disabled={pp.length < 12}>Download encrypted backup</button><label className="btn" style={{ cursor: pp.length < 12 ? "default" : "pointer", opacity: pp.length < 12 ? 0.5 : 1 }}>Restore from file<input type="file" accept=".csbak" hidden disabled={pp.length < 12} onChange={restore} /></label></div>
    <Err msg={err} />{msg && <p role="status" className="ok">{msg}</p>}<p className="muted">Test a restore on a spare system at least once a quarter.</p></div>;
}

export function Health() {
  const h = useData(() => api("/admin/health"), []);
  return <><Err msg={h.err} />{h.data && <><p>Overall: <Status v={h.data.status} /> <span className="muted">checked {fmt(h.data.checked_at)}</span> <button className="btn sm" onClick={h.reload}>Check again</button></p>
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable"><table><thead><tr><th>Component</th><th>Status</th><th>Detail</th></tr></thead><tbody>{h.data.components.map((c) => <tr key={c.name}><td>{c.name}</td><td><Status v={c.status} /></td><td>{c.detail}</td></tr>)}</tbody></table></div></>}</>;
}

export function Intel() {
  const { user } = useApp(); const l = useData(() => api("/iocs"), []); const [csv, setCsv] = useState(""); const [err, setErr] = useState(""); const [msg, setMsg] = useState(""); const admin = user.role === "Administrator";
  const imp = async () => { try { setErr(""); const r = await api("/iocs/import", { method: "POST", body: { csv } }); setMsg(r.imported + " imported, " + r.rejected + " rejected."); setCsv(""); l.reload(); } catch (e) { setErr(e.message); } };
  const stix = (e) => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = async () => { try { setErr(""); const x = await api("/iocs/import-stix", { method: "POST", body: { bundle: JSON.parse(r.result) } }); setMsg(x.imported + " imported, " + x.rejected + " rejected."); l.reload(); } catch (x) { setErr(x.message); } e.target.value = ""; }; r.readAsText(f); };
  return <><p className="muted">Indicators of compromise are matched against events as they arrive. CSV lines: type,value,source,confidence,expires_at. STIX 2.1 bundles import indicators with a single simple pattern; TAXII feeds are not polled.</p><Err msg={l.err || err} />{msg && <p role="status" className="ok">{msg}</p>}
    {admin && <div className="panel" style={{ marginBottom: 14 }}><Field label="Paste CSV"><textarea value={csv} onChange={(e) => setCsv(e.target.value)} placeholder="ip,203.0.113.99,feed,80," /></Field><div className="row" style={{ marginTop: 8 }}><button className="btn primary" onClick={imp} disabled={!csv}>Import CSV</button><label className="btn" style={{ cursor: "pointer" }}>Import STIX file<input type="file" accept=".json" hidden onChange={stix} /></label></div></div>}
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!l.data?.length ? <Empty>No indicators loaded, so indicator matching has nothing to match.</Empty> : <table><caption className="muted" style={{ textAlign: "left" }}>First 1000 indicators</caption><thead><tr><th>Type</th><th>Value</th><th>Source</th><th>Confidence</th><th>Expires</th></tr></thead><tbody>{l.data.map((i) => <tr key={i.id}><td>{i.type}</td><td className="ip">{i.value}</td><td>{i.source || "-"}</td><td className="num">{i.confidence}</td><td>{i.expires_at ? fmt(i.expires_at) : "never"}</td></tr>)}</tbody></table>}</div></>;
}
