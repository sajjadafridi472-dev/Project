import { useState } from "react";
import { api, fmt } from "./api";
import { useApp, useData, Sev, Status, Err, Empty, Field, Mono, Tabs, Confirm } from "./ui";
import { Retention, Backup, Health, Intel } from "./pages4";

export function Assets() {
  const { user } = useApp(); const l = useData(() => api("/assets"), []); const empty = { hostname: "", ip_address: "", os: "", owner: "", criticality: 3, tags: "" }; const [f, setF] = useState(empty); const [edit, setEdit] = useState(null); const [err, setErr] = useState(""); const admin = user.role === "Administrator";
  const body = () => ({ ...f, criticality: Number(f.criticality), ip_address: f.ip_address || null, os: f.os || null, owner: f.owner || null, tags: f.tags || null });
  const save = async (e) => { e.preventDefault(); try { setErr(""); await api(edit ? "/assets/" + edit : "/assets", { method: edit ? "PUT" : "POST", body: body() }); setF(empty); setEdit(null); l.reload(); } catch (x) { setErr(x.message); } };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return <><h1>Assets</h1><p className="muted">Risk is the highest open alert score on the asset plus 2 for each additional open alert. It is 0 when nothing is open.</p><Err msg={l.err || err} />
    {admin && <form className="panel row" style={{ alignItems: "end", marginBottom: 14 }} onSubmit={save}><Field label="Hostname"><input required value={f.hostname} onChange={set("hostname")} /></Field><Field label="IP address"><input value={f.ip_address} onChange={set("ip_address")} /></Field><Field label="Operating system"><input value={f.os} onChange={set("os")} /></Field><Field label="Owner"><input value={f.owner} onChange={set("owner")} /></Field>
      <Field label="Criticality (1-5)"><select value={f.criticality} onChange={set("criticality")}>{[1, 2, 3, 4, 5].map((n) => <option key={n}>{n}</option>)}</select></Field><button className="btn primary">{edit ? "Save asset" : "Add asset"}</button>{edit && <button type="button" className="btn" onClick={() => { setEdit(null); setF(empty); }}>Cancel</button>}</form>}
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!l.data?.length ? <Empty>No assets registered. Events from unknown hosts are still stored but have no owner or criticality.</Empty> : <table><thead><tr><th>Hostname</th><th>IP</th><th>Owner</th><th>Criticality</th><th>Open alerts</th><th>Risk</th>{admin && <th>Actions</th>}</tr></thead>
      <tbody>{l.data.map((a) => <tr key={a.id}><td><a href={"#/events?hostname=" + encodeURIComponent(a.hostname)}>{a.hostname}</a></td><td className="ip">{a.ip_address || "-"}</td><td>{a.owner || "-"}</td><td className="num">{a.criticality}/5</td><td className="num">{a.open_alerts}</td>
        <td><span className="risk" style={{ width: a.risk_score * 0.8 }} aria-hidden="true" />{a.risk_score}</td>
        {admin && <td className="row"><button className="btn sm" onClick={() => { setEdit(a.id); setF({ ...a, ip_address: a.ip_address || "", os: a.os || "", owner: a.owner || "", tags: a.tags || "" }); }}>Edit</button><Confirm text={"Remove " + a.hostname + " from the inventory?"} onYes={async () => { try { await api("/assets/" + a.id, { method: "DELETE" }); l.reload(); } catch (x) { setErr(x.message); } }}>Remove</Confirm></td>}</tr>)}</tbody></table>}</div></>;
}

export function Rules() {
  const { user } = useApp(); const l = useData(() => api("/rules"), []); const [err, setErr] = useState(""); const analyst = user.role === "Security Analyst";
  const toggle = async (r) => { try { setErr(""); await api("/rules/" + r.id, { method: "PATCH", body: { enabled: !r.enabled } }); l.reload(); } catch (x) { setErr(x.message); } };
  return <><h1>Detection rules</h1><p className="muted">Rules are rule-based and statistical. There is no machine learning. Changes apply to the next batch of events without a restart.</p><Err msg={l.err || err} />
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable"><table><thead><tr><th>Rule</th><th>Severity</th><th>Version</th><th>What it detects</th><th>State</th></tr></thead><tbody>{(l.data || []).map((r) => <tr key={r.id}><td>{r.name}</td><td><Sev v={r.severity} /></td><td className="num">{r.version}</td>
      <td>{r.logic.description || r.logic.type}<details><summary>Rule definition</summary><pre className="mono" style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(r.logic, null, 2)}</pre></details></td>
      <td>{analyst ? <button className="btn sm" aria-pressed={r.enabled} onClick={() => toggle(r)}>{r.enabled ? "Enabled: turn off" : "Disabled: turn on"}</button> : <Status v={r.enabled ? "enabled" : "disabled"} />}</td></tr>)}</tbody></table></div></>;
}

function Users() {
  const { user } = useApp(); const l = useData(() => api("/users"), []); const [f, setF] = useState({ username: "", name: "", email: "", password: "", role: "Auditor" }); const [err, setErr] = useState(""); const [made, setMade] = useState(null); const admin = user.role === "Administrator";
  const add = async (e) => { e.preventDefault(); try { setErr(""); setMade(await api("/users", { method: "POST", body: f })); setF({ ...f, username: "", name: "", email: "", password: "" }); l.reload(); } catch (x) { setErr(x.message); } };
  const patch = async (u, b) => { try { setErr(""); await api("/users/" + u.id, { method: "PATCH", body: b }); l.reload(); } catch (x) { setErr(x.message); } };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return <><Err msg={l.err || err} />
    {admin && <form className="panel row" style={{ alignItems: "end", marginBottom: 14 }} onSubmit={add}><Field label="Username"><input required value={f.username} onChange={set("username")} /></Field><Field label="Full name"><input required value={f.name} onChange={set("name")} /></Field><Field label="Email"><input required type="email" value={f.email} onChange={set("email")} /></Field>
      <Field label="Password (12+ characters)"><input required type="password" autoComplete="new-password" value={f.password} onChange={set("password")} /></Field><Field label="Role"><select value={f.role} onChange={set("role")}>{["Administrator", "Security Analyst", "Manager", "Auditor"].map((r) => <option key={r}>{r}</option>)}</select></Field><button className="btn primary">Create user</button></form>}
    {made?.mfa_secret && <div className="panel" role="status"><h3>Authenticator setup for {made.username}</h3><p>Shown once. Add this secret to an authenticator app: <Mono>{made.mfa_secret}</Mono></p></div>}
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable"><table><thead><tr><th>User</th><th>Role</th><th>Email</th><th>MFA</th><th>Status</th><th>Last sign-in</th>{admin && <th>Actions</th>}</tr></thead><tbody>{(l.data || []).map((u) => <tr key={u.id}><td>{u.username}<br /><small className="muted">{u.name}</small></td><td>{u.role}</td><td>{u.email}</td><td>{u.mfa_enabled ? "On" : "Off"}</td><td><Status v={u.status} /></td><td>{fmt(u.last_login)}</td>
      {admin && <td className="row">{u.username !== user.username && <><button className="btn sm" onClick={() => patch(u, { status: u.status === "active" ? "disabled" : "active" })}>{u.status === "active" ? "Disable" : "Enable"}</button>
        <Confirm text={"Delete " + u.username + "? This cannot be undone."} onYes={async () => { try { await api("/users/" + u.id, { method: "DELETE" }); l.reload(); } catch (x) { setErr(x.message); } }}>Delete</Confirm></>}</td>}</tr>)}</tbody></table></div></>;
}

function Sources() {
  const { user } = useApp(); const l = useData(() => api("/sources"), []); const h = useData(() => api("/ingest/health"), []); const [f, setF] = useState({ name: "", source_type: "agent" }); const [err, setErr] = useState(""); const [made, setMade] = useState(null); const admin = user.role === "Administrator";
  const add = async (e) => { e.preventDefault(); try { setErr(""); setMade(await api("/sources", { method: "POST", body: f })); setF({ ...f, name: "" }); l.reload(); } catch (x) { setErr(x.message); } };
  const toggle = async (s) => { try { await api("/sources/" + s.id, { method: "PATCH", body: { status: s.status === "disabled" ? "active" : "disabled" } }); l.reload(); } catch (x) { setErr(x.message); } };
  return <><Err msg={l.err || err} />{h.data && <p className="muted">Ingestion: {h.data.accepted.toLocaleString()} accepted, {h.data.quarantined} quarantined as malformed, {h.data.duplicates} duplicates counted, {h.data.queue_depth} waiting in the queue.</p>}
    {admin && <form className="panel row" style={{ alignItems: "end", marginBottom: 14 }} onSubmit={add}><Field label="Source name"><input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field><Field label="Type"><select value={f.source_type} onChange={(e) => setF({ ...f, source_type: e.target.value })}><option value="agent">Agent</option><option value="syslog">Syslog</option><option value="api">REST API</option><option value="ids">IDS sensor</option></select></Field><button className="btn primary">Register source</button></form>}
    {made && <div className="panel" role="status"><h3>Token for {made.name}</h3><p>Shown once. Send it in the X-Source-Token header: <Mono>{made.token}</Mono></p></div>}
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!l.data?.length ? <Empty>No sources registered. Register one to start collecting events.</Empty> : <table><thead><tr><th>Name</th><th>Type</th><th>Status</th><th>Last seen</th>{admin && <th>Actions</th>}</tr></thead><tbody>{l.data.map((s) => <tr key={s.id}><td>{s.name}</td><td>{s.source_type}{s.unauthenticated && <small className="err"> unauthenticated, unencrypted</small>}</td><td><Status v={s.status} /></td><td>{fmt(s.last_seen)}</td>
      {admin && <td className="row"><button className="btn sm" onClick={() => toggle(s)}>{s.status === "disabled" ? "Enable" : "Disable"}</button><Confirm text={"Delete source " + s.name + "?"} onYes={async () => { try { await api("/sources/" + s.id, { method: "DELETE" }); l.reload(); } catch (x) { setErr(x.message); } }}>Delete</Confirm></td>}</tr>)}</tbody></table>}</div></>;
}

function Audit() {
  const [action, setAction] = useState(""); const l = useData(() => api("/audit?limit=200" + (action ? "&action=" + encodeURIComponent(action) : "")), [action]); const [chain, setChain] = useState(null);
  return <><div className="row" style={{ marginBottom: 12, alignItems: "end" }}><Field label="Filter by action"><input value={action} placeholder="login.failed" onChange={(e) => setAction(e.target.value)} /></Field>
    <button className="btn" onClick={async () => setChain((await api("/audit/verify")).intact)}>Verify integrity</button>{chain !== null && <span role="status" className={chain ? "ok" : "err"}>{chain ? "The audit chain is intact." : "The audit chain has been altered."}</span>}</div><Err msg={l.err} />
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!l.data?.length ? <Empty>No audit entries match.</Empty> : <table><caption className="muted" style={{ textAlign: "left" }}>Append-only record of security-relevant actions, newest first</caption><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Object</th><th>IP</th></tr></thead><tbody>{l.data.map((e) => <tr key={e.id}><td>{fmt(e.timestamp)}</td><td>{e.username || "-"}</td><td>{e.action}</td><td>{e.object || "-"}</td><td className="ip">{e.ip || "-"}</td></tr>)}</tbody></table>}</div></>;
}

export function Admin() {
  const { user } = useApp(); const A = "Administrator", M = "Manager", U = "Auditor";
  const tabs = [["users", "Users", [A, U]], ["sources", "Log sources", [A, U]], ["intel", "Threat intelligence", [A, U]], ["retention", "Retention", [A, U]], ["backup", "Backup and restore", [A]], ["health", "System health", [A, U]], ["audit", "Audit log", [A, M, U]]].filter((t) => t[2].includes(user.role)).map((t) => [t[0], t[1]]);
  const [tab, setTab] = useState(user.role === "Auditor" ? "audit" : tabs[0][0]);
  return <><h1>Administration</h1><Tabs tabs={tabs} cur={tab} set={setTab} />{tab === "users" && <Users />}{tab === "sources" && <Sources />}{tab === "intel" && <Intel />}{tab === "retention" && <Retention />}{tab === "backup" && <Backup />}{tab === "health" && <Health />}{tab === "audit" && <Audit />}</>;
}
