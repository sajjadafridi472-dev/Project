import { useEffect, useState } from "react";
const parse = () => { const h = location.hash.replace(/^#\/?/, ""); const [path, qs = ""] = h.split("?"); const [page, id] = path.split("/"); return { page: page || "dashboard", id, params: Object.fromEntries(new URLSearchParams(qs)) }; };
export const go = (p) => { location.hash = "#/" + p; };
export function useRoute() { const [r, setR] = useState(parse); useEffect(() => { const f = () => setR(parse()); addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []); return r; }
