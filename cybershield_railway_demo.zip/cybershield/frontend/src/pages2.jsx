import { useEffect, useState } from "react";
import { api, fmt, dur, download } from "./api";
import { go } from "./route";
import { useApp, useData, Sev, Status, Origin, Err, Empty, Field, Mono } from "./ui";

const MIME = { txt: "text/plain", log: "text/plain", csv: "text/csv", json: "application/json", pdf: "application/pdf", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg" };
const STATES = ["New", "Investigating", "Contained", "Resolved", "False Positive", "Closed"];
const FLOW = { New: ["Investigating", "False Positive"], Investigating: ["Contained", "Resolved", "False Positive"], Contained: ["Investigating", "Resolved"], Resolved: ["Closed", "Investigating"], "False Positive": ["Closed", "Investigating"], Closed: [] };

function IncidentDetail({ id }) {
  const { user } = useApp(); const d = useData(() => api("/incidents/" + id), [id]); const i = d.data; const [err, setErr] = useState(""); const [f, setF] = useState({ note: "", url: "", owner: "", ip: "" });
  const analyst = user.role === "Security Analyst", manager = user.role === "Manager";
  const run = (fn) => async () => { try { setErr(""); await fn(); d.reload(); } catch (e) { setErr(e.message); } };
  const patch = (b) => run(() => api("/incidents/" + id, { method: "PATCH", body: b }));
  const post = (p, body, after) => run(async () => { await api("/incidents/" + id + p, { method: "POST", body }); after && after(); });
  const upload = (e) => { const file = e.target.files[0]; if (!file) return; const r = new FileReader(); r.onload = run(async () => { await api("/incidents/" + id + "/attachments", { method: "POST", body: { filename: file.name, content_type: MIME[file.name.split(".").pop().toLowerCase()] || file.type, data_base64: r.result.split(",")[1] } }); e.target.value = ""; }); r.readAsDataURL(file); };
  const dl = async (a) => { try { await download("/incidents/" + id + "/attachments/" + a.id, a.filename); } catch (x) { setErr(x.message); } };
  if (d.err) return <Err msg={d.err} />; if (!i) return null;
  return <section className="panel detail" aria-labelledby="idh"><div className="row between"><h2 id="idh">Incident {i.id}: {i.title}</h2><span className="row"><Sev v={i.severity} /><Status v={i.status} /></span></div>
    <dl className="kv"><dt>Type</dt><dd>{i.incident_type}</dd><dt>Owner</dt><dd>{i.owner || "-"}</dd><dt>Time to detect</dt><dd>{dur(i.time_to_detect_s)}</dd><dt>Time to acknowledge</dt><dd>{dur(i.time_to_acknowledge_s)}</dd><dt>Time to contain</dt><dd>{dur(i.time_to_contain_s)}</dd><dt>Time to resolve</dt><dd>{dur(i.time_to_resolve_s)}</dd>
      <dt>Alerts</dt><dd>{i.alerts.map((a) => <a key={a.id} href={"#/alerts/" + a.id} style={{ marginRight: 10 }}>#{a.id} {a.title}</a>)}</dd></dl>
    {analyst && <div className="row" style={{ margin: "12px 0" }}>{FLOW[i.status].length === 0 ? <span className="muted">Closed incidents cannot change.</span> : FLOW[i.status].map((s) => <button key={s} className="btn" onClick={patch({ status: s })}>Move to {s}</button>)}
      <input aria-label="New owner username" placeholder="analyst username" value={f.owner} onChange={(e) => setF({ ...f, owner: e.target.value })} /><button className="btn" onClick={patch({ owner: f.owner })}>Assign owner</button></div>}
    <div className="grid g22"><div><h3>Response checklist</h3><div className="checks">{i.playbook.map((p) => <label key={p.id}><input type="checkbox" checked={p.done} disabled={!analyst} onChange={(e) => run(() => api("/incidents/" + id + "/playbook/" + p.id, { method: "PATCH", body: { done: e.target.checked } }))()} />
      <span><b>{p.phase}:</b> {p.text}{p.done && <small className="muted"> (done by {p.done_by})</small>}</span></label>)}</div>
      <h3>Automated responses</h3>{i.responses.length === 0 && <Empty>No block requests.</Empty>}
      {i.responses.map((r) => <div key={r.id} className="row" style={{ padding: "4px 0" }}><Mono>{r.action} {r.target}</Mono><Status v={r.status} />{r.result && <small className="muted">{r.result}</small>}
        {manager && r.status === "proposed" && <><button className="btn sm" onClick={run(() => api("/responses/" + r.id, { method: "PATCH", body: { decision: "approve" } }))}>Approve</button><button className="btn sm danger" onClick={run(() => api("/responses/" + r.id, { method: "PATCH", body: { decision: "reject" } }))}>Reject</button></>}</div>)}
      {analyst && <div className="row"><input aria-label="IP address to block" placeholder="IP address" value={f.ip} onChange={(e) => setF({ ...f, ip: e.target.value })} /><button className="btn" onClick={post("/responses", { action: "block_ip", target: f.ip }, () => setF({ ...f, ip: "" }))}>Request IP block</button></div>}
      <h3>Attachments</h3>{i.attachments.length === 0 ? <Empty>No attachments.</Empty> : <ul>{i.attachments.map((a) => <li key={a.id}><button className="linkbtn" onClick={() => dl(a)}>{a.filename}</button> <small className="muted">{a.size} bytes, sha256 <Mono>{a.sha256.slice(0, 12)}</Mono></small></li>)}</ul>}
      {analyst && <Field label="Attach a file (text, CSV, JSON, PDF, PNG, JPEG, up to 1 MB)"><input type="file" accept=".txt,.csv,.json,.pdf,.png,.jpg,.jpeg" onChange={upload} /></Field>}</div>
      <div><h3>Timeline</h3><ul className="tl">{i.timeline.map((e, k) => <li key={k}><b>{e.kind}</b> {e.old ? e.old + " to " + e.new : e.text}<br /><small>{e.user}, {fmt(e.at)}</small></li>)}</ul>
        {analyst && <><Field label="Add a note"><textarea value={f.note} maxLength={4000} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field><div className="row" style={{ marginTop: 6 }}><button className="btn" onClick={post("/notes", { text: f.note }, () => setF({ ...f, note: "" }))}>Add note</button></div>
          <div className="row" style={{ marginTop: 8 }}><input aria-label="Evidence link" placeholder="https://..." value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} /><button className="btn" onClick={post("/evidence", { url: f.url }, () => setF({ ...f, url: "" }))}>Add evidence link</button></div></>}</div></div>
    <Err msg={err} /></section>;
}

export function Incidents() {
  const { route } = useApp(); const l = useData(() => api("/incidents?limit=300"), []); const m = useData(() => api("/incidents/metrics"), []);
  return <><h1>Incidents</h1><Err msg={l.err} />
    {m.data && <p className="muted">Last {m.data.period_days} days: {m.data.incidents} incident{m.data.incidents === 1 ? "" : "s"}. Mean time to detect {dur(m.data.MTTD_s)}, mean time to resolve {dur(m.data.MTTR_s)}. False positives are excluded.</p>}
    {l.data && l.data.length === 0 ? <Empty>No incidents yet. Open an alert and choose Create incident to start one.</Empty> :
      <div className="board">{STATES.map((s) => <section key={s} className="col" aria-label={s}><h3>{s} <span className="muted">({(l.data || []).filter((i) => i.status === s).length})</span></h3>
        {(l.data || []).filter((i) => i.status === s).map((i) => <button key={i.id} className="card" onClick={() => go("incidents/" + i.id)}><Sev v={i.severity} /><div>{i.title}</div><small className="muted">#{i.id}, {i.owner || "no owner"}</small></button>)}</section>)}</div>}
    {route.id && <IncidentDetail id={route.id} />}</>;
}

const FIELDS = [["q", "Text in message"], ["hostname", "Asset"], ["src_ip", "Source IP"], ["user", "User"], ["event_type", "Event type"], ["severity_min", "Minimum severity (0-10)"], ["data_origin", "Data origin"], ["start", "From (UTC)"], ["end", "To (UTC)"]];
export function Events() {
  const { route } = useApp(); const [f, setF] = useState({ ...route.params }); const [applied, setApplied] = useState({ ...route.params }); const [err, setErr] = useState("");
  useEffect(() => { setF({ ...route.params }); setApplied({ ...route.params }); }, [JSON.stringify(route.params)]); // eslint-disable-line
  const qs = (o) => new URLSearchParams(Object.entries(o).filter(([, v]) => v)).toString();
  const r = useData(() => api("/events?limit=200&" + qs(applied)), [JSON.stringify(applied)]);
  return <><h1>Event search</h1>
    <form className="panel row" style={{ alignItems: "end", marginBottom: 14 }} onSubmit={(e) => { e.preventDefault(); setApplied({ ...f }); }}>
      {FIELDS.map(([k, l]) => k === "data_origin" ? <Field key={k} label={l}><select value={f[k] || ""} onChange={(e) => setF({ ...f, [k]: e.target.value })}><option value="">Any</option><option>live</option><option>imported</option><option>simulated</option></select></Field>
        : <Field key={k} label={l}><input value={f[k] || ""} placeholder={k === "start" || k === "end" ? "2026-11-19T08:00:00" : ""} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></Field>)}
      <button className="btn primary" type="submit">Search</button><button type="button" className="btn" onClick={() => { setF({}); setApplied({}); }}>Clear</button>
      <button type="button" className="btn" onClick={async () => { try { setErr(""); await download("/events?format=csv&limit=5000&" + qs(applied), "events.csv"); } catch (e) { setErr(e.message); } }}>Export CSV</button></form>
    <Err msg={r.err || err} />
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!r.data?.length ? <Empty>{r.loading ? "Loading" : "No events match. Widen the time range or clear a filter."}</Empty> : <table><caption className="muted" style={{ textAlign: "left" }}>{r.data.length} events, newest first (up to 200 shown)</caption>
      <thead><tr><th>Time</th><th>Origin</th><th>Asset</th><th>Type</th><th>Sev</th><th>Source IP</th><th>User</th><th>Message</th></tr></thead>
      <tbody>{r.data.map((e) => <tr key={e.id}><td>{fmt(e.timestamp)}</td><td><Origin v={e.data_origin} /></td><td>{e.hostname}</td><td>{e.event_type}</td><td className="num">{e.severity}</td><td className="ip">{e.src_ip || "-"}</td><td>{e.user || "-"}</td><td>{e.message}</td></tr>)}</tbody></table>}</div></>;
}
