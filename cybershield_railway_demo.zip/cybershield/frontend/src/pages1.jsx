import { Fragment, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { api, fmt, dur } from "./api";
import { go } from "./route";
import { useApp, useData, Sev, Status, Err, Empty, Mono, Field, link } from "./ui";

const q = encodeURIComponent;
function Stat({ cls, n, label, onClick }) { return <button className={"stat panel " + cls} style={{ textAlign: "left", cursor: onClick ? "pointer" : "default", color: "inherit", font: "inherit" }} onClick={onClick}><b>{n ?? "-"}</b><span>{label}</span></button>; }

export function Dashboard() {
  const [period, setPeriod] = useState("24h");
  const sum = useData(() => api("/dashboard/summary"), []); const tr = useData(() => api("/dashboard/trends?period=" + period), [period]);
  const al = useData(() => api("/alerts?limit=60"), []); const geo = useData(() => api("/dashboard/geo"), []);
  const s = sum.data; const feed = (al.data || []).filter((a) => a.status === "Open" || a.status === "Investigating").sort((a, b) => (b.created_at > a.created_at ? 1 : -1)).slice(0, 7);
  const lab = (b) => { const d = new Date(b.end + "Z").toISOString(); return period === "1h" || period === "24h" ? d.slice(11, 16) : d.slice(5, 10); };
  const data = (tr.data?.buckets || []).map((b) => ({ ...b, label: lab(b) }));
  const drill = (d) => { const p = d.payload || d; go("events?start=" + q(p.start) + "&end=" + q(p.end)); };
  const tip = { background: "var(--panel)", border: "1px solid var(--line)", color: "var(--text)" };
  return <>
    <h1>Security overview</h1><Err msg={sum.err} />
    <div className="grid g4">{["Critical", "High", "Medium", "Low"].map((k) => <Stat key={k} cls={k.toLowerCase()} n={s?.alerts_open_by_severity[k]} label={k + " alerts open"} onClick={() => go("alerts")} />)}</div>
    <div className="grid g2" style={{ marginTop: 16 }}>
      <section className="panel" aria-labelledby="feed"><div className="row between"><h2 id="feed">Active alerts, newest first</h2><a href="#/alerts">All alerts</a></div>
        {feed.length === 0 ? <Empty>Nothing needs attention. New alerts appear here as they are raised.</Empty> :
          <ul className="feed">{feed.map((a) => <li key={a.id}><div className="row between"><span><Sev v={a.severity} /> <a href={"#/alerts/" + a.id}>{a.title}</a> <Status v={a.status} /></span><span className="muted">score {a.risk_score}</span></div>
            <small className="muted"><Mono>{a.entity}</Mono>, {a.occurrence_count} occurrence{a.occurrence_count > 1 ? "s" : ""}, last event {fmt(a.last_event_at)}</small></li>)}</ul>}</section>
      <div className="grid">
        <section className="panel"><h2>Needs attention</h2><dl className="kv"><dt>Unacknowledged critical</dt><dd><b>{s?.unacknowledged_critical ?? "-"}</b></dd><dt>Open incidents</dt><dd><a href="#/incidents" onClick={link("incidents")}>{s?.open_incidents ?? "-"}</a></dd><dt>Events, last 24 h</dt><dd>{s?.events_24h?.toLocaleString() ?? "-"}</dd></dl></section>
        <section className="panel"><h2>Most attacked assets</h2>{!s?.top_assets.length ? <Empty>No open alerts on any asset.</Empty> : <table><tbody>{s.top_assets.map((a) => <tr key={a.hostname}><td><a href={"#/events?hostname=" + q(a.hostname)}>{a.hostname}</a></td><td className="num">{a.open_alerts} open</td><td className="num">risk {a.max_risk}</td></tr>)}</tbody></table>}</section>
        <section className="panel"><h2>Top attack sources</h2>{!s?.top_sources.length ? <Empty>No source addresses with open alerts.</Empty> : <table><tbody>{s.top_sources.map((a) => <tr key={a.ip}><td className="ip"><a href={"#/events?src_ip=" + q(a.ip)}>{a.ip}</a></td><td className="num">{a.open_alerts} open</td><td className="num">risk {a.max_risk}</td></tr>)}</tbody></table>}</section>
      </div></div>
    <section className="panel" style={{ marginTop: 16 }}><div className="row between"><h2>Volume over time</h2>
      <div className="row" role="group" aria-label="Period">{["1h", "24h", "7d", "30d"].map((p) => <button key={p} className={"btn sm" + (p === period ? " primary" : "")} aria-pressed={p === period} onClick={() => setPeriod(p)}>{p === "1h" ? "Last hour" : p === "24h" ? "24 hours" : p === "7d" ? "7 days" : "30 days"}</button>)}</div></div>
      <Err msg={tr.err} /><p className="muted">Select a bar to open the events from that interval.</p>
      <div className="grid g22"><div><h3>Events</h3><ResponsiveContainer width="100%" height={190}><BarChart data={data}><CartesianGrid stroke="var(--line)" vertical={false} /><XAxis dataKey="label" stroke="var(--muted)" fontSize={12} /><YAxis stroke="var(--muted)" fontSize={12} allowDecimals={false} /><Tooltip contentStyle={tip} cursor={{ fill: "var(--panel2)" }} /><Bar dataKey="events" fill="var(--cyan)" cursor="pointer" onClick={drill} /></BarChart></ResponsiveContainer></div>
        <div><h3>Alerts raised</h3><ResponsiveContainer width="100%" height={190}><BarChart data={data}><CartesianGrid stroke="var(--line)" vertical={false} /><XAxis dataKey="label" stroke="var(--muted)" fontSize={12} /><YAxis stroke="var(--muted)" fontSize={12} allowDecimals={false} /><Tooltip contentStyle={tip} cursor={{ fill: "var(--panel2)" }} /><Bar dataKey="alerts" fill="var(--red)" cursor="pointer" onClick={() => go("alerts")} /></BarChart></ResponsiveContainer></div></div></section>
    <div className="grid g22" style={{ marginTop: 16 }}>
      <section className="panel"><h2>Log sources</h2><dl className="kv">{s && Object.entries(s.source_health).map(([k, v]) => <Fragment key={k}><dt>{k}</dt><dd>{v}</dd></Fragment>)}</dl>{s && s.source_health.silent > 0 && <p className="err">{s.source_health.silent} source(s) have sent nothing for over 10 minutes.</p>}</section>
      <section className="panel"><h2>Attack source locations</h2>{!geo.data?.available ? <Empty>{geo.data?.note || "Loading"} Alert counts per country appear here once a GeoIP table is supplied.</Empty> : <table><tbody>{geo.data.sources.map((g) => <tr key={g.country}><td>{g.country}</td><td className="num">{g.open_alerts} open</td></tr>)}</tbody></table>}</section></div>
  </>;
}

function AlertDetail({ id }) {
  const { user } = useApp(); const d = useData(() => api("/alerts/" + id), [id]); const [note, setNote] = useState(""); const [err, setErr] = useState("");
  const analyst = user.role === "Security Analyst"; const a = d.data;
  const act = async (status) => { try { setErr(""); await api("/alerts/" + id, { method: "PATCH", body: { status, note: note || undefined } }); setNote(""); d.reload(); } catch (e) { setErr(e.message); } };
  const toInc = async () => { try { setErr(""); const r = await api("/incidents", { method: "POST", body: { alert_ids: [Number(id)] } }); go("incidents/" + r.id); } catch (e) { setErr(e.message); } };
  if (d.err) return <Err msg={d.err} />; if (!a) return null;
  return <section className="panel detail" aria-labelledby="ad"><div className="row between"><h2 id="ad">{a.title}</h2><span className="row"><Sev v={a.severity} /><Status v={a.status} /></span></div>
    <dl className="kv"><dt>Risk score</dt><dd>{a.risk_score} / 100</dd><dt>Entity</dt><dd><Mono>{a.entity}</Mono></dd><dt>Occurrences</dt><dd>{a.occurrence_count}</dd><dt>MITRE ATT&amp;CK</dt><dd>{a.mitre || "-"}</dd>
      <dt>Asset</dt><dd>{a.hostname || "-"}{a.enrichment.asset_owner ? ", owner " + a.enrichment.asset_owner : ""}{a.enrichment.asset_criticality ? ", criticality " + a.enrichment.asset_criticality + "/5" : ""}</dd>
      <dt>Threat intelligence</dt><dd>{a.enrichment.ioc_matches.length ? a.enrichment.ioc_matches.join(", ") : "No indicator match"}</dd><dt>Detected in</dt><dd>{a.trigger_latency_ms != null ? (a.trigger_latency_ms / 1000).toFixed(2) + " s after the event arrived" : "-"}</dd></dl>
    <h3 style={{ marginTop: 14 }}>Why this alert was raised</h3><ul>{a.explanation.rules.map((r) => <li key={r.id}><b>{r.name}</b> (rule version {r.version}): {r.summary}</li>)}</ul>
    <p className="muted">Score: {a.explanation.score_components.map(([l, v]) => l + " " + (v > 0 ? "+" : "") + v).join("; ")}</p>
    {analyst && <div style={{ marginTop: 14 }}><Field label="Note (optional)"><textarea value={note} maxLength={2000} onChange={(e) => setNote(e.target.value)} /></Field>
      <div className="row" style={{ marginTop: 8 }}><button className="btn" onClick={() => act("Investigating")}>Start investigating</button><button className="btn" onClick={() => act("Resolved")}>Mark resolved</button><button className="btn" onClick={() => act("False Positive")}>Mark false positive</button><button className="btn" onClick={() => act("Open")}>Reopen</button>
        <button className="btn primary" onClick={toInc}>Create incident</button>{note && <button className="btn" onClick={() => act(undefined)}>Save note only</button>}</div></div>}
    <h3 style={{ marginTop: 14 }}>Triggering events</h3><div className="scroll" style={{ maxHeight: 300, overflowY: "auto" }} tabIndex={0} role="region" aria-label="Table, scrollable"><table><caption className="muted" style={{ textAlign: "left" }}>Up to 100 events linked to this alert</caption><thead><tr><th>Time</th><th>Type</th><th>Source</th><th>Message</th></tr></thead>
      <tbody>{a.events.map((e) => <tr key={e.id}><td>{fmt(e.timestamp)}</td><td>{e.event_type}</td><td className="ip">{e.src_ip || "-"}</td><td>{e.message}</td></tr>)}</tbody></table></div>
    {a.notes.length > 0 && <><h3>Notes</h3><ul>{a.notes.map((n, i) => <li key={i}><b>{n.user}</b> {fmt(n.created_at)}: {n.text}</li>)}</ul></>}
    <Err msg={err} /></section>;
}

export function Alerts() {
  const { route } = useApp(); const [status, setStatus] = useState(""); const [sev, setSev] = useState("");
  const l = useData(() => api("/alerts?limit=200" + (status ? "&status=" + q(status) : "") + (sev ? "&severity=" + sev : "")), [status, sev]);
  return <><h1>Alerts</h1><div className="row" style={{ marginBottom: 12 }}>
    <Field label="Status"><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Any</option>{["Open", "Investigating", "Resolved", "False Positive"].map((x) => <option key={x}>{x}</option>)}</select></Field>
    <Field label="Severity"><select value={sev} onChange={(e) => setSev(e.target.value)}><option value="">Any</option>{["Critical", "High", "Medium", "Low"].map((x) => <option key={x}>{x}</option>)}</select></Field></div>
    <Err msg={l.err} />
    <div className="panel scroll" tabIndex={0} role="region" aria-label="Table, scrollable">{!l.data?.length ? <Empty>{l.loading ? "Loading" : "No alerts match these filters."}</Empty> : <table><caption className="muted" style={{ textAlign: "left" }}>Sorted by risk score, highest first. Select a row to investigate.</caption>
      <thead><tr><th>Severity</th><th>Score</th><th>Alert</th><th>Entity</th><th>Status</th><th>Hits</th><th>Last event</th></tr></thead>
      <tbody>{l.data.map((a) => <tr key={a.id} className={"click" + (String(a.id) === route.id ? " sel" : "")} tabIndex={0} onClick={() => go("alerts/" + a.id)} onKeyDown={(e) => e.key === "Enter" && go("alerts/" + a.id)}>
        <td><Sev v={a.severity} /></td><td className="num">{a.risk_score}</td><td>{a.title}</td><td className="ip">{a.entity}</td><td><Status v={a.status} /></td><td className="num">{a.occurrence_count}x</td><td>{fmt(a.last_event_at)}</td></tr>)}</tbody></table>}</div>
    {route.id && <AlertDetail id={route.id} />}</>;
}
