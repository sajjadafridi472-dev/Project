"""First-run flow in a real browser against an EMPTY database: setup screen, one-time secret, then sign in with MFA. Usage: python scripts/verify_firstrun.py"""
import re, sys, pyotp
from playwright.sync_api import sync_playwright
B = "http://127.0.0.1:8000"; PW = "First-Run-Passw0rd-xyz"; ok = True
with sync_playwright() as pw:
    br = pw.chromium.launch(); p = br.new_page(viewport={"width": 1280, "height": 800}); errs = []; p.on("pageerror", lambda e: errs.append(str(e)))
    p.goto(B); p.wait_for_selector("text=No accounts exist yet"); p.screenshot(path="docs/screenshots/00-first-run.png")
    p.fill("label:has-text('Username') input", "owner"); p.fill("label:has-text('Full name') input", "Site Owner"); p.fill("label:has-text('Email') input", "owner@example.org"); p.fill("input[type=password]", "short"); p.click("button:has-text('Create administrator')")
    p.wait_for_selector("[role=alert]"); weak = p.locator("[role=alert]").inner_text(); print("PASS weak password rejected:", weak) if "12" in weak else (print("FAIL weak password", weak), sys.exit(1))
    p.fill("input[type=password]", PW); p.click("button:has-text('Create administrator')"); p.wait_for_selector("text=Save your authenticator secret")
    secret = p.locator("p.mono").inner_text().strip(); print("PASS secret shown once:", bool(re.fullmatch(r"[A-Z2-7]{32}", secret)))
    p.click("button:has-text('I have saved it')"); p.wait_for_selector("label:has-text('Username') input")
    p.fill("label:has-text('Username') input", "owner"); p.fill("label:has-text('Password') input", PW); p.click("button[type=submit]"); p.wait_for_selector("text=Authenticator code")
    p.fill("input[autocomplete=one-time-code]", pyotp.TOTP(secret).now()); p.click("button[type=submit]"); p.wait_for_selector("button:has-text('Sign out')"); p.wait_for_timeout(400); land = p.url.split("/#")[-1]; print("PASS signed in with MFA, administrator landed on:", land); ok = land == "/admin" or land.endswith("admin"); print("PASS landing is Administration" if ok else "FAIL landing " + land)
    p.reload(); p.wait_for_selector("h1"); print("PASS setup screen not offered again after setup:", p.locator("text=No accounts exist yet").count() == 0); print("page errors:", errs or "none"); br.close()
