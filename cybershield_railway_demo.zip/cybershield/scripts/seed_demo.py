"""Seed a LOCAL DEMO database through the public API. Uses ONLY simulated and imported data (nothing here is real monitoring).
Usage: python scripts/seed_demo.py http://127.0.0.1:8000   (prints the generated demo password and TOTP secrets)"""
import secrets, sys, time
import httpx, pyotp
base = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000") + "/api/v1"; c = httpx.Client(timeout=30)
PW = "Demo-" + secrets.token_urlsafe(12); out = {"password": PW}
def login(u, secret=None):
    r = c.post(base + "/auth/login", json={"username": u, "password": PW, "otp": pyotp.TOTP(secret).now() if secret else None}); r.raise_for_status(); return {"Authorization": "Bearer " + r.json()["token"]}
a = c.post(base + "/setup", json={"username": "admin", "name": "Demo Admin", "email": "admin@demo.local", "password": PW}).json(); out["admin"] = a["mfa_secret"]; H = login("admin", a["mfa_secret"])
for u, role in (("analyst", "Security Analyst"), ("manager", "Manager"), ("auditor", "Auditor")):
    r = c.post(base + "/users", headers=H, json={"username": u, "name": u.title(), "email": f"{u}@demo.local", "password": PW, "role": role}).json(); out[u] = r.get("mfa_secret")
for h, ip, o, k in (("web01", "10.0.0.5", "IT Services", 5), ("fw01", "10.0.0.1", "Network team", 4), ("db01", "10.0.0.20", "Data team", 5)):
    c.post(base + "/assets", headers=H, json={"hostname": h, "ip_address": ip, "owner": o, "criticality": k, "os": "Linux"})
for n, t in (("lab-agent", "agent"), ("perimeter-fw", "ids")): c.post(base + "/sources", headers=H, json={"name": n, "source_type": t})
for sc, n in (("benign", 60), ("brute_force", 25), ("port_scan", 30)): c.post(base + "/simulate", headers=H, json={"scenario": sc, "count": n})
c.post(base + "/ingest/import", headers=H, json={"format": "syslog", "content": "\n".join(f"<38>Nov 19 05:{i:02d}:10 db01 sshd[9]: Failed password for root from 192.0.2.77 port 22 ssh2" for i in range(14))})
for _ in range(60):
    if len(c.get(base + "/alerts", headers=H).json()) >= 3: break
    time.sleep(1)
HA = login("analyst", out["analyst"]); al = c.get(base + "/alerts", headers=HA).json()
bf = [x for x in al if "Brute" in x["title"]]
if bf:
    inc = c.post(base + "/incidents", headers=HA, json={"alert_ids": [bf[0]["id"]]}).json()
    c.patch(f"{base}/incidents/{inc['id']}", headers=HA, json={"status": "Investigating"}); c.post(f"{base}/incidents/{inc['id']}/notes", headers=HA, json={"text": "Source address is a documentation range from the simulator."})
    d = c.get(f"{base}/incidents/{inc['id']}", headers=HA).json(); c.patch(f"{base}/incidents/{inc['id']}/playbook/{d['playbook'][0]['id']}", headers=HA, json={"done": True})
    c.post(f"{base}/incidents/{inc['id']}/responses", headers=HA, json={"action": "block_ip", "target": "203.0.113.50"})
import json; print(json.dumps(out))
