"""End-to-end UI checks against a seeded server: role landing views (FR-DSH-06), clicks to triage-and-create-incident (NFR-USA-01), console errors.
Usage: python scripts/verify_ui.py seed.json"""
import json, sys, httpx, pyotp
from playwright.sync_api import sync_playwright
d = json.load(open(sys.argv[1])); B = "http://127.0.0.1:8000"; errs = []; ok = True
def token(u, s=None): return httpx.post(B + "/api/v1/auth/login", json={"username": u, "password": d["password"], "otp": pyotp.TOTP(s).now() if s else None}).json()["token"]
def check(name, cond, extra=""):
    global ok; ok &= bool(cond); print(("PASS " if cond else "FAIL ") + name, extra)
with sync_playwright() as pw:
    br = pw.chromium.launch()
    def page(u, s=None):
        c = br.new_context(viewport={"width": 1440, "height": 900}); c.add_init_script(f"sessionStorage.setItem('cs_token','{token(u, s)}')"); p = c.new_page()
        p.on("pageerror", lambda e: errs.append(str(e))); p.on("response", lambda r: errs.append((r.status, r.url)) if r.status >= 400 else None); return p
    for u, s, want in (("analyst", d["analyst"], "#/alerts"), ("manager", None, "#/dashboard"), ("auditor", None, "#/admin"), ("admin", d["admin"], "#/admin")):
        p = page(u, s); p.goto(B + "/"); p.wait_for_selector("h1"); p.wait_for_timeout(500); check(f"landing view for {u}", p.url.endswith(want), p.url.split("/#")[-1])
        if u == "auditor": check("auditor lands on the Audit log tab", p.locator("[role=tab][aria-selected=true]").inner_text() == "Audit log")
    p = page("analyst", d["analyst"]); p.goto(B + "/#/dashboard"); p.wait_for_selector(".feed a"); clicks = 0
    p.click(".feed a >> nth=0"); clicks += 1; p.wait_for_selector("text=Create incident"); p.click("text=Create incident"); clicks += 1; p.wait_for_url("**/incidents/*")
    check("alert to incident from the dashboard in <= 5 clicks (NFR-USA-01)", clicks <= 5 and "/incidents/" in p.url, f"{clicks} clicks")
    p.goto(B + "/#/alerts"); p.reload(); p.wait_for_selector("h1"); p.keyboard.press("Tab"); check("skip link is the first focus target (keyboard access)", p.evaluate("document.activeElement.className") == "skip")
    br.close()
check("no browser console or network errors", not errs, str(errs[:3]))
sys.exit(0 if ok else 1)
