"""Generates docs/er_diagram_*.png from the SQLAlchemy models (so it cannot drift from the code) and docs/architecture.png. Needs graphviz `dot`."""
import pathlib, subprocess, sys
root = pathlib.Path(__file__).resolve().parents[1]; sys.path.insert(0, str(root / "backend"))
import app.models  # noqa
from app.db import Base
CORE = {"roles", "users", "assets", "log_sources", "events", "rules", "alerts", "alert_events", "incidents", "incident_alerts", "iocs", "alert_iocs", "audit_log"}
def er(tables, path, title):
    lines = [f'digraph ER {{ graph [rankdir=LR, labelloc=t, label="{title}", fontname="Helvetica", fontsize=20, pad=0.3, nodesep=0.35, ranksep=1.1, bgcolor="white"]; node [shape=plain, fontname="Helvetica"]; edge [color="#4b5d7d", arrowsize=0.7, fontname="Helvetica", fontsize=9];']
    for t in tables:
        rows = "".join(f'<TR><TD ALIGN="LEFT" PORT="{c.name}">{"<B>PK </B>" if c.primary_key else ("<I>FK </I>" if c.foreign_keys else "")}{c.name} <FONT COLOR="#6b7a99" POINT-SIZE="9">{str(c.type).split("(")[0].lower()}</FONT></TD></TR>' for c in t.columns)
        lines.append(f'"{t.name}" [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" COLOR="#24324f"><TR><TD BGCOLOR="#17233f"><FONT COLOR="white"><B>{t.name}</B></FONT></TD></TR>{rows}</TABLE>>];')
    names = {t.name for t in tables}
    for t in tables:
        for fk in t.foreign_keys:
            if fk.column.table.name in names: lines.append(f'"{t.name}":"{fk.parent.name}" -> "{fk.column.table.name}":"{fk.column.name}" [label="N:1"];')
    lines.append("}"); (root / "docs" / (path + ".dot")).write_text("\n".join(lines))
    subprocess.run(["dot", "-Tpng", "-Gdpi=110", str(root / "docs" / (path + ".dot")), "-o", str(root / "docs" / (path + ".png"))], check=True); (root / "docs" / (path + ".dot")).unlink()
T = list(Base.metadata.sorted_tables)
er([t for t in T if t.name in CORE], "er_diagram_core", "CyberShield: core entities (audit_log links to users by a soft reference so entries survive user deletion)")
er(T, "er_diagram_full", "CyberShield: complete schema (generated from the models)")
arch = '''digraph A { rankdir=LR; graph [fontname="Helvetica", pad=0.3, nodesep=0.3, ranksep=0.6, label="CyberShield architecture (what was built; dashed = optional or not tested in the build environment)", labelloc=t, fontsize=18];
node [shape=box, style="rounded,filled", fillcolor="#eef3fb", color="#24324f", fontname="Helvetica", fontsize=11]; edge [color="#4b5d7d", fontname="Helvetica", fontsize=9];
subgraph cluster_src { label="Event sources"; style=dashed; color="#8ea3c2"; agent [label="Any client with a source token\\n(agent program not built)", style="rounded,dashed,filled"]; syslog [label="Syslog devices\\nUDP / TCP (no TLS)"]; files [label="Sample files\\n(imported)"]; sim [label="Built-in simulator\\n(tagged simulated)", fillcolor="#fff3d6"]; }
subgraph cluster_col { label="Collection"; style=dashed; color="#8ea3c2"; rest [label="REST /events\\nsource token, 1000/batch"]; lst [label="Syslog listener"]; imp [label="Import / simulate\\n(admin)"]; queue [label="Persistent queue\\n(ingest_queue table)", fillcolor="#dff3ee"]; }
subgraph cluster_proc { label="Background worker (one or many; row-locked claims)"; style=dashed; color="#8ea3c2"; norm [label="Normalise + SHA-256\\nquarantine malformed\\ncount duplicates"]; det [label="Detection\\nrules / IOC / login-hour baseline"]; cor [label="Correlate + score\\n0-100, explained"]; mnt [label="Housekeeping\\nschedules, retention, heartbeat"]; }
subgraph cluster_out { label="Outputs"; style=dashed; color="#8ea3c2"; outbox [label="Notification outbox\\nretry + backoff"]; smtp [label="SMTP / webhook", style="rounded,dashed,filled"]; hub [label="WebSocket hub\\n+ polling fallback"]; arch [label="Archive files\\n(compressed, not searchable)"]; }
db [label="PostgreSQL (or SQLite for development)\\nevents, alerts, incidents, rules, assets, IOCs,\\nusers, sessions, audit_log (append-only, hash chain)", shape=cylinder, fillcolor="#e4e8f7"];
api [label="FastAPI REST API\\nRBAC on every route, rate limits,\\nsecurity headers", fillcolor="#dff3ee"]; ui [label="React web UI\\nDashboard, Alerts, Incidents, Events,\\nAssets, Reports, Rules, Administration", fillcolor="#dff3ee"]; proxy [label="TLS reverse proxy\\n(Caddy, not run here)", style="rounded,dashed,filled"];
agent -> rest; syslog -> lst; files -> imp; sim -> imp; rest -> queue; lst -> queue; imp -> queue; queue -> norm -> det -> cor; cor -> db; norm -> db; cor -> outbox -> smtp; cor -> hub; mnt -> arch; mnt -> db; mnt -> outbox [label="scheduled reports"];
db -> api [dir=both]; api -> ui [label="HTTPS + WS"]; hub -> ui [style=dotted]; ui -> proxy [dir=back, style=dashed]; }'''
(root / "docs" / "architecture.dot").write_text(arch); subprocess.run(["dot", "-Tpng", "-Gdpi=110", str(root / "docs" / "architecture.dot"), "-o", str(root / "docs" / "architecture.png")], check=True); (root / "docs" / "architecture.dot").unlink()
print("ok")
