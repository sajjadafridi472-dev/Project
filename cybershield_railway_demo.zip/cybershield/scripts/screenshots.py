"""Drive the built UI in headless Chromium against a seeded demo server and save screenshots. Usage: python scripts/screenshots.py seed.json"""
import json, sys, httpx, pyotp
from playwright.sync_api import sync_playwright
d = json.load(open(sys.argv[1])); B = "http://127.0.0.1:8000"; OUT = "docs/screenshots/"; errs = []
def token(u, s=None): return httpx.post(B + "/api/v1/auth/login", json={"username": u, "password": d["password"], "otp": pyotp.TOTP(s).now() if s else None}).json()["token"]
with sync_playwright() as p:
    br = p.chromium.launch(); ctx = br.new_context(viewport={"width": 1440, "height": 900}); pg = ctx.new_page()
    pg.on("console", lambda m: errs.append(("console", m.text)) if m.type == "error" else None); pg.on("pageerror", lambda e: errs.append(("pageerror", str(e))))
    pg.on("response", lambda r: errs.append(("http", r.status, r.url)) if r.status >= 400 and "/auth/login" not in r.url else None)
    pg.goto(B); pg.screenshot(path=OUT + "01-login.png")
    pg.fill("input[autocomplete=username]", "analyst"); pg.fill("input[type=password]", d["password"]); pg.click("button[type=submit]")
    pg.wait_for_selector("text=Authenticator code"); pg.screenshot(path=OUT + "02-login-mfa.png")
    pg.fill("input[autocomplete=one-time-code]", pyotp.TOTP(d["analyst"]).now()); pg.click("button[type=submit]")
    pg.wait_for_selector("h1:has-text('Security overview')"); pg.wait_for_selector("text=Live feed connected", timeout=8000); pg.wait_for_timeout(1200)
    pg.screenshot(path=OUT + "03-dashboard.png", full_page=True)
    pg.click("text=Alerts >> nth=0"); pg.wait_for_selector("tbody tr"); pg.click("tbody tr >> nth=0"); pg.wait_for_selector("text=Why this alert was raised"); pg.wait_for_timeout(500); pg.screenshot(path=OUT + "04-alert-detail.png", full_page=True)
    pg.click("nav >> text=Incidents"); pg.wait_for_selector(".board"); pg.click(".card >> nth=0"); pg.wait_for_selector("text=Response checklist"); pg.wait_for_timeout(500); pg.screenshot(path=OUT + "05-incident.png", full_page=True)
    pg.click("nav >> text=Event search"); pg.wait_for_selector("tbody tr"); pg.screenshot(path=OUT + "06-events.png")
    pg.click("nav >> text=Dashboard"); pg.wait_for_selector(".recharts-bar-rectangle path, .recharts-rectangle", timeout=5000)
    pg.locator("button:has-text('24 hours')").click(); pg.wait_for_timeout(500)
    pg.locator(".recharts-bar-rectangle").nth(0).evaluate("e => 1")
    # drill-down: click the tallest events bar and confirm we land on event search with a time range
    bars = pg.locator(".recharts-wrapper >> nth=0").locator(".recharts-bar-rectangle path"); n = bars.count(); drilled = False
    for i in range(n):
        h = bars.nth(i).bounding_box()
        if h and h["height"] > 2: bars.nth(i).click(); drilled = True; break
    pg.wait_for_timeout(800); print("drill-down url:", pg.url.split("#")[1][:70] if drilled else "no bar with data", "| rows:", pg.locator("tbody tr").count())
    pg.screenshot(path=OUT + "07-drilldown.png")
    pg.click("text=Switch to light theme"); pg.click("nav >> text=Dashboard"); pg.wait_for_selector("h1:has-text('Security overview')"); pg.wait_for_timeout(600); pg.screenshot(path=OUT + "08-light-theme.png")
    # admin and manager contexts via API tokens
    for name, u, s, shots in (("admin", "admin", d["admin"], (("assets", "09-assets.png", "h1:has-text('Assets')"), ("admin", "10-admin-audit.png", "h1:has-text('Administration')"))),):
        c2 = br.new_context(viewport={"width": 1440, "height": 900}); t = token(u, s); c2.add_init_script(f"sessionStorage.setItem('cs_token','{t}')"); q = c2.new_page(); q.on("pageerror", lambda e: errs.append(("pageerror", str(e))))
        for page, f, sel in shots: q.goto(B + "/#/" + page); q.wait_for_selector(sel); q.wait_for_timeout(800); q.screenshot(path=OUT + f, full_page=True)
        q.click("role=tab[name='Audit log']"); q.wait_for_selector("tbody tr"); q.screenshot(path=OUT + "10-admin-audit.png", full_page=True)
    c3 = br.new_context(viewport={"width": 390, "height": 800}); t = token("manager"); c3.add_init_script(f"sessionStorage.setItem('cs_token','{t}')"); m = c3.new_page(); m.goto(B + "/#/dashboard"); m.wait_for_selector("h1"); m.wait_for_timeout(800); m.screenshot(path=OUT + "11-mobile-manager.png", full_page=True)
    c4 = br.new_context(); t = token("auditor"); c4.add_init_script(f"sessionStorage.setItem('cs_token','{t}')"); a = c4.new_page(); a.goto(B + "/#/dashboard"); a.wait_for_selector("nav"); print("auditor nav:", [x.strip() for x in a.locator("nav a").all_inner_texts()])
    c5 = br.new_context(); t = token("admin", d["admin"]); c5.add_init_script(f"sessionStorage.setItem('cs_token','{t}')"); z = c5.new_page(); z.goto(B + "/#/incidents"); z.wait_for_timeout(800); print("admin on /incidents:", z.locator("main").inner_text()[:90].replace("\n", " "))
    br.close()
print("browser errors:", errs or "none")
