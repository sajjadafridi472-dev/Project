"""Automated WCAG 2.1 A/AA scan (axe-core) of every screen, both themes, the relevant roles. Usage: python scripts/a11y_audit.py seed.json /path/to/axe.min.js
An automated scan finds only a part of the possible problems (roughly a third by common estimates); it does not replace a screen-reader or keyboard review."""
import collections, json, sys, httpx, pyotp
from playwright.sync_api import sync_playwright
d = json.load(open(sys.argv[1])); AXE = sys.argv[2]; B = "http://127.0.0.1:8000"
def token(u, s=None): return httpx.post(B + "/api/v1/auth/login", json={"username": u, "password": d["password"], "otp": pyotp.TOTP(s).now() if s else None}).json()["token"]
TAGS = ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"]
PLAN = [("anonymous", None, None, [("#/", None)]),
        ("analyst", "analyst", d["analyst"], [("#/dashboard", None), ("#/alerts/1", None), ("#/incidents/1", None), ("#/events", None), ("#/assets", None), ("#/reports", "Compliance"), ("#/rules", None)]),
        ("manager", "manager", None, [("#/reports", "Summary"), ("#/reports", "Schedules"), ("#/admin", None)]),
        ("admin", "admin", d["admin"], [("#/assets", None)] + [("#/admin", t) for t in ("Users", "Log sources", "Threat intelligence", "Retention", "Backup and restore", "System health", "Audit log")])]
results, agg, pages = [], collections.defaultdict(lambda: {"impact": "", "help": "", "pages": set(), "nodes": 0, "examples": []}), 0
with sync_playwright() as pw:
    br = pw.chromium.launch()
    for theme in ("dark", "light"):
        for role, user, secret, routes in PLAN:
            ctx = br.new_context(viewport={"width": 1366, "height": 900}, bypass_csp=True)  # test browser only: lets axe be injected despite the app's strict CSP
            init = f"localStorage.setItem('cs_theme','{theme}');" + (f"sessionStorage.setItem('cs_token','{token(user, secret)}');" if user else "")
            ctx.add_init_script(init); p = ctx.new_page()
            for route, tab in routes:
                p.goto(B + "/" + route); p.wait_for_selector("main h1, h1"); p.wait_for_timeout(700)
                if tab: p.click(f"role=tab[name='{tab}']"); p.wait_for_timeout(600)
                p.add_script_tag(path=AXE); r = p.evaluate("(tags) => axe.run(document, {runOnly: {type: 'tag', values: tags}})", TAGS); pages += 1
                label = f"{role}:{route}{'/' + tab if tab else ''}:{theme}"
                for v in r["violations"]:
                    a = agg[v["id"]]; a["impact"], a["help"] = v["impact"], v["help"]; a["pages"].add(label); a["nodes"] += len(v["nodes"])
                    if len(a["examples"]) < 3: a["examples"].append((label, v["nodes"][0]["target"][0] if v["nodes"][0]["target"] else "", v["nodes"][0].get("failureSummary", "").split("\n")[1:3]))
                results.append((label, len(r["violations"]), len(r["passes"])))
    br.close()
print(f"pages x themes scanned: {pages}")
if not agg: print("NO violations found by axe-core (WCAG 2.1 A and AA rules).")
for k, a in sorted(agg.items(), key=lambda x: -x[1]["nodes"]):
    print(f"\n{a['impact'].upper()} {k}: {a['help']} | {a['nodes']} nodes on {len(a['pages'])} page-views")
    for lab, sel, fs in a["examples"]: print("   e.g.", lab, "|", sel[:70], "|", " ".join(x.strip() for x in fs)[:150])
json.dump({"scanned": pages, "violations": {k: {"impact": v["impact"], "help": v["help"], "nodes": v["nodes"], "pages": sorted(v["pages"])} for k, v in agg.items()}}, open("/tmp/a11y.json", "w"))
