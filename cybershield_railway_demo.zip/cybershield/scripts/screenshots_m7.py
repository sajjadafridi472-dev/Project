"""Screenshots of the Module 7 pages (reports, compliance, retention, backup, health, intel). Usage: python scripts/screenshots_m7.py seed.json"""
import json, sys, httpx, pyotp
from playwright.sync_api import sync_playwright
d = json.load(open(sys.argv[1])); B = "http://127.0.0.1:8000"; OUT = "docs/screenshots/"; errs = []
def token(u, s=None): return httpx.post(B + "/api/v1/auth/login", json={"username": u, "password": d["password"], "otp": pyotp.TOTP(s).now() if s else None}).json()["token"]
def page(br, who, secret=None, w=1440):
    c = br.new_context(viewport={"width": w, "height": 900}); c.add_init_script(f"sessionStorage.setItem('cs_token','{token(who, secret)}')"); p = c.new_page()
    p.on("pageerror", lambda e: errs.append(("pageerror", str(e)))); p.on("response", lambda r: errs.append((r.status, r.url)) if r.status >= 400 else None); return p
with sync_playwright() as pw:
    br = pw.chromium.launch(); m = page(br, "manager")
    m.goto(B + "/#/reports"); m.wait_for_selector("text=Events"); m.wait_for_timeout(700); m.screenshot(path=OUT + "12-report-summary.png", full_page=True)
    with m.expect_download() as dl: m.click("text=Export PDF")
    path = dl.value.path(); print("PDF download:", dl.value.suggested_filename, open(path, "rb").read(5))
    with m.expect_download() as dl2: m.click("text=Export CSV")
    print("CSV download:", dl2.value.suggested_filename, open(dl2.value.path()).read().splitlines()[0])
    m.click("role=tab[name='Compliance']"); m.wait_for_selector("text=Evidence available"); m.screenshot(path=OUT + "13-compliance.png", full_page=True)
    a = page(br, "analyst", d["analyst"]); a.goto(B + "/#/reports"); a.wait_for_selector("text=Events"); print("analyst export hint:", a.locator("text=can view reports but not export").count(), "| analyst tabs:", a.locator("[role=tab]").all_inner_texts())
    ad = page(br, "admin", d["admin"])
    for tab, f in (("Retention", "14-retention.png"), ("System health", "15-health.png"), ("Backup and restore", "16-backup.png"), ("Threat intelligence", "17-intel.png")):
        ad.goto(B + "/#/admin"); ad.wait_for_selector("role=tab[name='" + tab + "']"); ad.click("role=tab[name='" + tab + "']"); ad.wait_for_timeout(700); ad.screenshot(path=OUT + f, full_page=True)
    br.close()
print("errors:", errs or "none")
