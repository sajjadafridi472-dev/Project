"""Builds docs/RTM.md, docs/RTM.csv and docs/TEST_REPORT.md from rtm_data.py, the test sources and the JUnit results. Fails on unknown test IDs."""
import ast, collections, csv, pathlib, re, sys, xml.etree.ElementTree as ET
sys.path.insert(0, str(pathlib.Path(__file__).parent)); from rtm_data import REQ, AC
root = pathlib.Path(__file__).resolve().parents[1]; docs = root / "docs"; tests = root / "backend" / "tests"
funcs = {}  # test id -> (file, ast node, def-line comment)
for f in sorted(tests.glob("test_module*.py")):
    src = f.read_text(); lines = src.splitlines()
    for n in ast.parse(src).body:
        if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"):
            funcs[n.name[5:].split("_")[0]] = (f.name, n, lines[n.lineno - 1], n.name)
unknown = sorted({t for r in REQ for t in r[5].split()} | {t for a in AC for t in a[3].split()} - set(funcs)); unknown = [t for t in unknown if t not in funcs]
if unknown: sys.exit(f"RTM references unknown test IDs: {unknown}")
cnt = collections.Counter(r[3] for r in REQ); acn = collections.Counter(a[2] for a in AC)
kind = lambda i: "FR" if i.startswith("FR") else "NFR" if i.startswith("NFR") else "SR"
rows = ["| ID | Pri | Requirement | Status | Implemented in | Tests | Notes |", "|---|---|---|---|---|---|---|"] + [f"| {i} | {p} | {s} | **{st}** | {w or '-'} | {t or '-'} | {n or ''} |" for i, p, s, st, w, t, n in REQ]
arows = ["| ID | Area | Status | Tests | Evidence |", "|---|---|---|---|---|"] + [f"| {i} | {a} | **{s}** | {t or '-'} | {n} |" for i, a, s, t, n in AC]
by = {k: collections.Counter(r[3] for r in REQ if kind(r[0]) == k) for k in ("FR", "NFR", "SR")}
summ = ["| Group | Total | " + " | ".join(["Met", "Met (API only)", "Partial", "Not met", "Not verified", "Not implemented"]) + " |", "|---|---|" + "---|" * 6]
for k, name in (("FR", "Functional"), ("NFR", "Non-functional"), ("SR", "Security")): summ.append(f"| {name} | {sum(by[k].values())} | " + " | ".join(str(by[k][s]) for s in ["Met", "Met (API only)", "Partial", "Not met", "Not verified", "Not implemented"]) + " |")
summ.append(f"| **All** | **{len(REQ)}** | " + " | ".join(f"**{cnt[s]}**" for s in ["Met", "Met (API only)", "Partial", "Not met", "Not verified", "Not implemented"]) + " |")
(docs / "RTM.md").write_text(f"""# Requirements Traceability Matrix

Source of truth: SRS v1.0 (19 Oct 2026). The SRS counts 101 requirements (58 FR, 22 NFR, 21 SR); this matrix lists {len(REQ)}. Status is stated honestly:
**Met** = implemented and covered by an automated test or a recorded measurement. **Met (API only)** = works through the API with tests but has no UI screen.
**Partial** = part of the requirement is built or verified. **Not met** = measured and below the target. **Not verified** = cannot be verified in the build environment.
**Not implemented** = not built. Test IDs refer to functions in `backend/tests/` (for example `AUTH01` is `test_AUTH01_...`); the build script rejects unknown IDs.

## Summary
{chr(10).join(summ)}

## Requirements
{chr(10).join(rows)}

## Acceptance criteria (SRS section 9)
{chr(10).join(arows)}

The SRS Appendix A traces user requirements only for FR and some SR items. This matrix extends it to every FR, NFR and SR (suggested addition, not an SRS change).
""")
with open(docs / "RTM.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["id", "priority", "requirement", "status", "implemented_in", "tests", "notes"]); [w.writerow(r) for r in REQ]
# ---- test report
def res(p):
    out = {}
    for tc in ET.parse(p).getroot().iter("testcase"):
        k = tc.get("name"); st = "FAIL" if tc.find("failure") is not None or tc.find("error") is not None else "SKIP" if tc.find("skipped") is not None else "PASS"; out[k] = (st, float(tc.get("time", 0)))
    return out
sq, pg = res(docs / "evidence" / "junit-sqlite.xml"), res(docs / "evidence" / "junit-postgresql.xml")
def short(n, k=110): s = ast.unparse(n).replace("\n", " "); return (s[:k] + "...") if len(s) > k else s
trs = ["| Test ID | Requirement(s) | Description | Key input (first setup step) | Expected (first assertion) | SQLite | PostgreSQL |", "|---|---|---|---|---|---|---|"]
for tid, (fn, node, defline, name) in sorted(funcs.items(), key=lambda x: (x[1][0], x[1][1].lineno)):
    req = ", ".join(sorted(set(re.findall(r"(?:N?FR|SR|AC)-[A-Z]*-?\d+|UC-\d+|NFR-[A-Z]+-\d+|SRS [\d.]+", defline)))) or "-"
    desc = (ast.get_docstring(node) or name.split("_", 2)[-1].replace("_", " ")).split("\n")[0]
    body = [s for s in node.body if not (isinstance(s, ast.Expr) and isinstance(getattr(s, "value", None), ast.Constant))]
    setup = next((short(s) for s in body if not isinstance(s, ast.Assert)), "-"); first = next((short(s.test) for s in ast.walk(node) if isinstance(s, ast.Assert)), "-")
    f = lambda d: d.get(name, ("n/a", 0))[0]
    trs.append(f"| {tid} | {req} | {desc.replace('|', '/')} | `{setup.replace('|', '/')}` | `{first.replace('|', '/')}` | {f(sq)} | {f(pg)} |")
c = lambda d: collections.Counter(v[0] for v in d.values())
(docs / "TEST_REPORT.md").write_text(f"""# Test report

Generated from the JUnit results in `docs/evidence/` by `scripts/build_docs.py`. Command: `cd backend && python -m pytest -q`.
Run on SQLite: {dict(c(sq))}. Run on PostgreSQL 16: {dict(c(pg))}. The two skipped tests on SQLite are PostgreSQL-only (audit-chain concurrency and parallel-worker claim).

Kinds of test: unit (rule engine, scoring, parsers), integration (API plus database), system (queue to detection to alert to notification to incident to report, with real SMTP and webhook clients against local servers),
functional (every module), input validation, authentication and authorisation (including a sweep of every route against every role), error handling, and basic security (injection, headers, tamper evidence, static scan for dynamic SQL).

How to read the columns: **Key input** and **Expected** are extracted automatically from each test's source (first setup statement and first assertion) and are shortened; the full inputs and every assertion are in the named test.
**Actual result** is the pass or fail recorded in the JUnit file for that database. Measurements that are not pass/fail tests (detection quality, latency, throughput, concurrency load) are in `detection_evaluation.md`, `latency_report.md` and `performance_report.md`.

{chr(10).join(trs)}
""")
print("RTM rows:", len(REQ), dict(cnt), "| AC:", dict(acn), "| tests documented:", len(funcs), "| sqlite", dict(c(sq)), "| pg", dict(c(pg)))
