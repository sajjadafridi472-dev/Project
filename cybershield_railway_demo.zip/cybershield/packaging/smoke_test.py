"""Checks a RUNNING CyberShield (packaged or not) end to end through its API. Usage: python packaging/smoke_test.py http://127.0.0.1:8000
Uses a throw-away administrator, so run it against a fresh data folder only."""
import base64, sys, time, uuid, httpx, pyotp
B = sys.argv[1].rstrip("/") + "/api/v1"; c = httpx.Client(timeout=60); ok = True
def check(name, cond, extra=""):
    global ok; ok &= bool(cond); print(("PASS " if cond else "FAIL ") + name, extra)
check("UI is served", "CyberShield" in c.get(B.replace("/api/v1", "/")).text)
check("first run is offered", c.get(B + "/setup/status").json() == {"needed": True})
pw = "Smoke-" + uuid.uuid4().hex[:14]; a = c.post(B + "/setup", json={"username": "smoke", "name": "Smoke", "email": "s@example.org", "password": pw}); check("administrator created (Argon2 hashing)", a.status_code == 201)
tok = c.post(B + "/auth/login", json={"username": "smoke", "password": pw, "otp": pyotp.TOTP(a.json()["mfa_secret"]).now()}).json()["token"]; H = {"Authorization": "Bearer " + tok}; check("sign-in with authenticator code", bool(tok))
check("simulator queues events", c.post(B + "/simulate", headers=H, json={"scenario": "brute_force", "count": 25}).status_code == 202)
al = []
for _ in range(40):
    al = c.get(B + "/alerts", headers=H).json()
    if al: break
    time.sleep(0.5)
check("detection raised an alert", bool(al) and "Brute" in al[0]["title"], al[0]["title"] if al else "")
mp = "Manager-" + uuid.uuid4().hex[:12]; check("manager account created", c.post(B + "/users", headers=H, json={"username": "mgr", "name": "Manager", "email": "m@example.org", "password": mp, "role": "Manager"}).status_code == 201)
MH = {"Authorization": "Bearer " + c.post(B + "/auth/login", json={"username": "mgr", "password": mp}).json()["token"]}   # only Manager and Auditor may export (SRS 7.8)
pdf = c.get(B + "/reports/summary?period=daily&format=pdf", headers=MH); check("PDF report generated", pdf.content[:5] == b"%PDF-" and len(pdf.content) > 2000, f"{len(pdf.content)} bytes")
check("administrator is correctly refused PDF export", c.get(B + "/reports/summary?period=daily&format=pdf", headers=H).status_code == 403)
bk = c.post(B + "/admin/backup", headers=H, json={"passphrase": "smoke test passphrase 1"}); check("encrypted backup created", bk.status_code == 200 and b"AES-256-GCM" in bk.content)
rs = c.post(B + "/admin/restore", headers=H, json={"passphrase": "smoke test passphrase 1", "backup_base64": base64.b64encode(bk.content).decode()}); check("backup restores", rs.status_code == 200)
check("health endpoint", c.get(B + "/health").json()["status"] in ("ok", "degraded"))
sys.exit(0 if ok else 1)
