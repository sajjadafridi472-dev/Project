# PyInstaller recipe for the one-file program. Run from the project root, ON THE OPERATING SYSTEM YOU WANT TO TARGET
# (a Windows .exe must be built on Windows):   pyinstaller --noconfirm packaging/cybershield.spec
import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules
root = os.path.abspath(os.path.join(os.path.dirname(SPEC), ".."))
hidden = collect_submodules("uvicorn") + collect_submodules("app") + collect_submodules("websockets") + collect_submodules("anyio") + ["sqlalchemy.dialects.sqlite", "reset_mfa"]
datas = [(os.path.join(root, "frontend", "dist"), "frontend_dist")] + collect_data_files("reportlab")
a = Analysis([os.path.join(root, "backend", "launcher.py")], pathex=[os.path.join(root, "backend")], datas=datas, hiddenimports=hidden,
             excludes=["tkinter", "psycopg", "psycopg_binary", "pytest", "alembic"])  # packaged program uses SQLite; use the server install for PostgreSQL
exe = EXE(PYZ(a.pure), a.scripts, a.binaries, a.datas, [], name="CyberShield", console=True, upx=False)
