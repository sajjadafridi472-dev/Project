"""Recover an account whose authenticator secret was lost. Run it on the computer that holds the CyberShield database.

    python reset_mfa.py USERNAME              issues a NEW authenticator secret (the old one stops working)
    python reset_mfa.py USERNAME --password   also asks you to choose a new password

It also unlocks the account and signs it out everywhere. Anyone who can run this already has full access to the database,
so it is an on-the-machine administrator tool, and every use is written to the audit log."""
import argparse, getpass, os, pathlib, sys

def _find_database():
    """Use DATABASE_URL if set; otherwise look for the SQLite file the launcher or the project folder would have created."""
    if os.environ.get("DATABASE_URL"): return
    base = os.environ.get("CYBERSHIELD_DATA") or (os.environ.get("LOCALAPPDATA") or os.path.expanduser("~/.local/share")) + "/CyberShield"
    for p in (pathlib.Path("cybershield.db"), pathlib.Path(base) / "cybershield.db"):
        if p.exists(): os.environ["DATABASE_URL"] = "sqlite:///" + p.resolve().as_posix(); print("Using database:", p.resolve()); return

def reset(username: str, new_password: str | None = None):
    from sqlalchemy import select
    from app import audit, security as sec
    from app.db import SessionLocal
    from app.models import User
    with SessionLocal() as db:
        u = db.scalar(select(User).where(User.username == username))
        if not u: raise LookupError(f"No user named '{username}'. Check the spelling (it is case-sensitive).")
        if new_password:
            if (e := sec.password_error(new_password)): raise ValueError(e)
            u.password_hash = sec.hash_password(new_password)
        u.mfa_secret, u.mfa_enabled, u.failed_attempts, u.locked_until = sec.new_totp_secret(), True, 0, None
        for s in u.sessions: s.revoked = True
        audit.log(db, "account.recovery_cli", username="local-administrator", obj=u.username, new="authenticator secret reissued" + (" and password changed" if new_password else ""))
        db.commit(); return u.mfa_secret, sec.totp_uri(u.mfa_secret, u.username)

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Reissue the authenticator secret of an account."); ap.add_argument("username"); ap.add_argument("--password", action="store_true", help="also set a new password")
    a = ap.parse_args(argv); _find_database(); pw = None
    if a.password:
        pw = getpass.getpass("New password (12+ characters): ")
        if pw != getpass.getpass("Repeat it: "): print("The two passwords differ. Nothing was changed."); return 1
    try: secret, uri = reset(a.username, pw)
    except (LookupError, ValueError) as e: print("Nothing was changed:", e); return 1
    except Exception as e: print("Could not open the database. Run this in the folder that contains cybershield.db, or set DATABASE_URL.\n", type(e).__name__, str(e)[:200]); return 1
    print(f"\nDone. The account '{a.username}' is unlocked and signed out everywhere.\n\nNEW authenticator secret (shown only now, save it):\n\n    {secret}\n\nIn your authenticator app choose 'Enter a setup key' and paste it. Setup link: {uri}\n"); return 0

if __name__ == "__main__": sys.exit(main())
