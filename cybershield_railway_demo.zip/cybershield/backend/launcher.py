"""One-click launcher: starts CyberShield on this computer and opens it in the default browser.
Used both directly (python launcher.py) and as the entry point of the packaged program (CyberShield.exe)."""
import os, pathlib, socket, sys, threading, time, webbrowser

frozen = getattr(sys, "frozen", False)
root = pathlib.Path(sys._MEIPASS) if frozen else pathlib.Path(__file__).resolve().parents[1]
data = pathlib.Path(os.environ.get("CYBERSHIELD_DATA") or (os.environ.get("LOCALAPPDATA") or os.path.expanduser("~/.local/share")) + "/CyberShield")
data.mkdir(parents=True, exist_ok=True)
# Settings are read when the application is imported, so they must be set first. Your own environment variables always win.
os.environ.setdefault("CYBERSHIELD_UI_DIR", str(root / ("frontend_dist" if frozen else "frontend/dist")))
os.environ.setdefault("DATABASE_URL", "sqlite:///" + (data / "cybershield.db").as_posix())
os.environ.setdefault("ARCHIVE_DIR", str(data / "archive"))

def free_port(want: int) -> int:
    for p in (want, *range(want + 1, want + 20)):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0: return p
    return want

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--reset-mfa":  # CyberShield.exe --reset-mfa USERNAME [--password]
        import reset_mfa; sys.exit(reset_mfa.main(sys.argv[2:]))
    import uvicorn
    from app.main import app
    host = os.environ.get("CYBERSHIELD_HOST", "127.0.0.1")  # this computer only, unless you choose otherwise
    port = free_port(int(os.environ.get("PORT", "8000"))); url = f"http://127.0.0.1:{port}"
    print("=" * 62 + f"\n  CyberShield is starting.\n  Address : {url}\n  Data in : {data}\n  Close this window (or press Ctrl+C) to stop it.\n" + "=" * 62, flush=True)
    def open_when_ready():
        for _ in range(60):
            with socket.socket() as s:
                if s.connect_ex(("127.0.0.1", port)) == 0: break
            time.sleep(0.5)
        if not os.environ.get("CYBERSHIELD_NO_BROWSER"):
            try: webbrowser.open(url)
            except Exception: pass
    threading.Thread(target=open_when_ready, daemon=True).start()
    uvicorn.run(app, host=host, port=port, log_level="warning")

if __name__ == "__main__": main()
