"""Measures what THIS machine achieves for queue -> normalise -> store (SQLite). Not the SRS reference deployment."""
import os, tempfile, time
os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/b.db"; os.environ["INGEST_WORKER"] = "0"
from app.main import init_db
from app import ingest
from app.db import SessionLocal
init_db(); N = 5000
items = [{"timestamp": "2026-10-19T09:15:02Z", "hostname": f"h{i % 50}", "event_type": "auth.failure", "severity": 3,
          "src_ip": f"203.0.113.{i % 250}", "message": f"Failed login {i}"} for i in range(N)]
with SessionLocal() as db:
    t = time.time(); ingest.enqueue(db, items, "json", None, "api", "simulated"); db.commit(); t1 = time.time() - t
    t = time.time()
    while ingest.process_queue(db): pass
    t2 = time.time() - t
print(f"enqueue {N/t1:,.0f} ev/s | process+store {N/t2:,.0f} ev/s | end-to-end {N/(t1+t2):,.0f} ev/s (single thread, SQLite)")
