from alembic import context
from sqlalchemy import engine_from_config, pool
import app.models  # noqa: F401  (registers all tables on Base.metadata)
from app.config import settings
from app.db import Base

config = context.config
config.set_main_option("sqlalchemy.url", settings.database_url.replace("%", "%%"))

def run():
    engine = engine_from_config(config.get_section(config.config_ini_section), prefix="sqlalchemy.", poolclass=pool.NullPool)
    with engine.connect() as conn:
        context.configure(connection=conn, target_metadata=Base.metadata, compare_type=True)
        with context.begin_transaction(): context.run_migrations()

run()  # online mode only: the audit-log guard needs a live connection
