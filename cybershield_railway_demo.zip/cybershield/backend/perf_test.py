"""NFR-PERF-03/04 measurement. Usage: python perf_test.py seed | python perf_test.py run <workers>
Environment: DATABASE_URL (PostgreSQL), server at http://127.0.0.1:8000. Results are for THIS machine only (not the SRS reference deployment)."""
import hashlib, os, random, statistics, sys, threading, time, uuid
from datetime import timedelta
EVENTS, ALERTS, USERS, ITER = 200_000, 1_000, 50, 6
THINK = float(os.environ.get("THINK", "0"))  # seconds between a user's page loads (0 = continuous clicking, a stress test)
if sys.argv[1] == "seed":
    from app.main import init_db
    from app.db import engine
    from app.models import Event, Alert, utcnow
    init_db(); rnd = random.Random(7); now = utcnow(); rows = []
    with engine.begin() as c:
        for i in range(EVENTS):
            t = now - timedelta(seconds=rnd.randint(0, 86400)); m = f"Failed password for user{i % 40} from 10.{i % 200}.{i % 250}.{i % 90} attempt {i}"
            rows.append(dict(id=str(uuid.uuid4()), timestamp=t, received_at=t, hostname=f"h{i % 50}", event_type=rnd.choice(["auth.failure", "auth.success", "net.fw", "web.request"]), severity=rnd.randint(0, 9),
                             src_ip=f"10.{i % 200}.{i % 250}.{i % 90}", message=m, raw=m, hash=hashlib.sha256(m.encode()).hexdigest(), data_origin="simulated", detected=True, source_type="agent"))
            if len(rows) == 10000: c.execute(Event.__table__.insert(), rows); rows = []
        for i in range(ALERTS):
            c.execute(Alert.__table__.insert(), [dict(rule_id=1, rule_version=1, severity=rnd.choice(["Low", "Medium", "High", "Critical"]), risk_score=rnd.randint(10, 95), status="Open", title="Seeded alert", entity=f"src_ip:10.0.{i % 250}.1",
                                                      hostname=f"h{i % 50}", explanation="{}", occurrence_count=1, escalated=False, created_at=now, updated_at=now, last_event_at=now)])
    print("seeded", EVENTS, "events and", ALERTS, "alerts"); sys.exit()
import httpx, pyotp
B = "http://127.0.0.1:8000/api/v1"; W = sys.argv[2]; PW = "Perf-" + uuid.uuid4().hex[:16]
a = httpx.post(B + "/setup", json={"username": "perf", "name": "P", "email": "p@x.pk", "password": PW}, timeout=30).json()
tok = httpx.post(B + "/auth/login", json={"username": "perf", "password": PW, "otp": pyotp.TOTP(a["mfa_secret"]).now()}, timeout=30).json()["token"]; H = {"Authorization": "Bearer " + tok}
def since(): return (time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 86400)))
def page(c):
    t = time.perf_counter()
    for p in ("/dashboard/summary", "/dashboard/trends?period=24h", "/alerts?limit=60", "/dashboard/geo"): assert c.get(B + p, headers=H).status_code == 200
    return time.perf_counter() - t
def search(c):
    t = time.perf_counter(); r = c.get(B + "/events", headers=H, params={"start": since(), "hostname": "h5", "severity_min": 3, "q": "Failed", "limit": 100}); assert r.status_code == 200
    return time.perf_counter() - t
def pct(v, p): v = sorted(v); return v[min(len(v) - 1, int(p / 100 * len(v)))]
def run(users, it):
    P, S, errs = [], [], []
    def w():
        try:
            with httpx.Client(timeout=60) as c:
                for _ in range(it): P.append(page(c)); S.append(search(c)); time.sleep(random.uniform(0.5, 1.5) * THINK) if (THINK and users > 1) else None
        except Exception as e: errs.append(repr(e))
    ts = [threading.Thread(target=w) for _ in range(users)]; t0 = time.time(); [t.start() for t in ts]; [t.join() for t in ts]; return P, S, errs, time.time() - t0
page(httpx.Client()); search(httpx.Client())  # warm-up
bp, bs, _, _ = run(1, 20); lp, ls, errs, wall = run(USERS, ITER)
f = lambda v: f"p50 {statistics.median(v):.3f} s, p95 {pct(v, 95):.3f} s, max {max(v):.3f} s"
degr = lambda a, b: f"{(statistics.median(a) / statistics.median(b) - 1) * 100:+.0f}% at p50, {(pct(a, 95) / pct(b, 95) - 1) * 100:+.0f}% at p95"
out = f"""## Server with {W} worker process(es), think time {THINK:g} s
Data: {EVENTS:,} events (24 h), {ALERTS:,} alerts, PostgreSQL on the same machine ({os.cpu_count()} CPU cores). Background queue worker disabled to isolate request handling.
| Measure | 1 user (baseline) | {USERS} concurrent users |
|---|---|---|
| Dashboard load (4 API calls, sequential) | {f(bp)} | {f(lp)} |
| 24 h search, 5 combined filters | {f(bs)} | {f(ls)} |
Degradation with {USERS} users vs 1 user: dashboard {degr(lp, bp)}; search {degr(ls, bs)}. Errors: {len(errs)}. Wall time {wall:.0f} s.
Targets: dashboard p95 <= 3 s (NFR-PERF-03): {'MET' if pct(lp, 95) <= 3 else 'NOT MET'} at {USERS} users. Search p95 <= 5 s: {'MET' if pct(ls, 95) <= 5 else 'NOT MET'}. Degradation <= 10% (NFR-PERF-04): {'MET' if statistics.median(lp) <= 1.1 * statistics.median(bp) and statistics.median(ls) <= 1.1 * statistics.median(bs) else 'NOT MET'}.
"""
print(out); open("../docs/performance_report.md", "a").write(out + "\n")
