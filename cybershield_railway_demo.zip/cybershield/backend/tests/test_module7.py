import base64, dataclasses, gzip, io, json, os, time
from datetime import timedelta
import pyotp, pypdf, pytest
from sqlalchemy import select
from app import backup, maintenance, notify, report, retention, routes_admin
from app.db import SessionLocal, engine, Base
from app.main import init_db
from app.models import Alert, AlertEvent, AuditLog, Event, IOC, Incident, IncidentAlert, IngestMetric, Notification, QueueItem, ReportSchedule, utcnow
from app import audit
from conftest import PW, login, make_user
from test_module3 import E, fails, scan, T0, run as run3, alerts
from test_module4 import staff, H, FakeSMTP, outbox

def rec(n, ip="203.0.113.5", et="auth.failure", ago=30, host="web01", message=None, **kw):
    t = utcnow() - timedelta(minutes=ago)
    return [{"timestamp": (t + timedelta(seconds=i * 2)).strftime("%Y-%m-%dT%H:%M:%SZ"), "hostname": host, "event_type": et, "severity": 3, "user": "root", "src_ip": ip,
             "message": message or f"Failed password {i}", **kw} for i in range(n)]

def get(c, h, path, **p): return c.get("/api/v1" + path, headers=h, params=p)

def test_RPT01_totals_match_database_and_formats_agree(client, admin):            # FR-RPT-01/02, AC-14
    s = staff(client, admin); run3(rec(12) + rec(20, ip="198.51.100.7", et="net.fw", host="fw01", message=None, dst_ip="10.0.0.5"))
    with SessionLocal() as db: ev, al = db.query(Event).count(), db.query(Alert).count()
    j = get(client, s["man"], "/reports/summary", period="daily").json(); S = j["sections"]
    assert S["events"]["total"] == ev and S["alerts"]["total"] == al and S["events"]["origin.simulated"] == ev
    assert sum(v for k, v in S["alerts"].items() if k.startswith("severity.")) == al and sum(v for k, v in S["alerts"].items() if k.startswith("status.")) == al
    assert any("SIMULATED" in n for n in j["notes"]) and "no machine learning" in j["notes"][0]
    c = get(client, s["man"], "/reports/summary", period="daily", format="csv"); assert c.headers["content-type"].startswith("text/csv") and "attachment" in c.headers["content-disposition"]
    import csv
    rows = {(r["section"], r["item"]): r["value"] for r in csv.DictReader(io.StringIO(c.text))}
    assert rows[("events", "total")] == str(ev) and rows[("alerts", "total")] == str(al)               # CSV equals JSON equals database, 0% difference
    p = get(client, s["aud"], "/reports/summary", period="daily", format="pdf"); assert p.content[:5] == b"%PDF-"
    txt = " ".join(pg.extract_text() for pg in pypdf.PdfReader(io.BytesIO(p.content)).pages)
    assert "CyberShield daily security summary" in txt and str(ev) in txt and "SIMULATED" in txt and "Definitions" in txt

def test_RPT02_period_windows_and_validation(client, admin):                       # FR-RPT-01
    s = staff(client, admin); run3(rec(4, ago=60 * 24 * 2, ip="192.0.2.1", et="proc.start", message="old") + rec(3, ago=30, ip="192.0.2.2", et="proc.start", message="new"))
    t = lambda per: get(client, s["man"], "/reports/summary", period=per).json()["sections"]["events"]["total"]
    assert (t("daily"), t("weekly"), t("monthly")) == (3, 7, 7)
    assert get(client, s["man"], "/reports/summary", period="yearly").status_code == 422 and get(client, s["man"], "/reports/other").status_code == 404
    assert get(client, s["man"], "/reports/summary", format="xml").status_code == 422 and get(client, s["man"], "/reports/summary", end="junk").status_code == 422
    assert get(client, {}, "/reports/summary").status_code == 401

def test_RPT03_export_needs_write_role(client, admin):                              # SRS 7.8: Manager/Auditor RW, Analyst/Admin R
    s = staff(client, admin); run3(rec(2, et="proc.start"))
    for h in (s["ana"], admin["h"]):
        assert get(client, h, "/reports/summary").status_code == 200 and get(client, h, "/reports/summary", format="pdf").status_code == 403 and get(client, h, "/reports/summary", format="csv").status_code == 403
    for h in (s["man"], s["aud"]): assert get(client, h, "/reports/summary", format="csv").status_code == 200
    with SessionLocal() as db: assert sum(1 for e in db.query(AuditLog) if e.action == "report.export") == 2

def test_RPT04_incident_metrics_in_report_match_incident_api(client, admin):       # FR-RPT-03
    s = staff(client, admin); run3(rec(12)); aid = alerts()[0][0]
    i = client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": [aid]}).json()
    for st in ("Investigating", "Contained", "Resolved"): client.patch(f"/api/v1/incidents/{i['id']}", headers=s["ana"], json={"status": st})
    m = get(client, s["man"], "/incidents/metrics").json(); r = get(client, s["man"], "/reports/summary", period="daily").json()["sections"]["incidents"]
    assert r["created"] == 1 and r["resolved_in_period"] == 1 and r["open_at_end"] == 0 and r["MTTD_s"] == m["MTTD_s"] and r["MTTR_s"] == m["MTTR_s"] and r["MTTR_s"] is not None

def test_RPT05_csv_formula_injection_neutralised(client, admin):
    s = staff(client, admin); run3(rec(1, et="priv.sudo", host="=1+1", message="sudo: COMMAND=/bin/bash"))
    assert "=1+1" in get(client, s["man"], "/reports/summary", period="daily").json()["sections"]["top_attacked_assets"]
    c = get(client, s["man"], "/reports/summary", period="daily", format="csv").text
    assert ",'=1+1," in c and ",=1+1," not in c

def test_SCH01_schedules_rbac_and_delivery_with_attachment(client, admin, monkeypatch):   # FR-RPT-05 (Could)
    s = staff(client, admin); run3(rec(3, et="proc.start"))
    assert get(client, s["ana"], "/reports/schedules").status_code == 403 and client.post("/api/v1/reports/schedules", headers=admin["h"], json={"period": "daily", "format": "pdf"}).status_code == 403
    for bad in ({"period": "hourly", "format": "pdf"}, {"period": "daily", "format": "docx"}): assert client.post("/api/v1/reports/schedules", headers=s["man"], json=bad).status_code == 422
    sid = client.post("/api/v1/reports/schedules", headers=s["man"], json={"period": "weekly", "format": "pdf"}).json()["id"]
    assert client.post("/api/v1/reports/schedules", headers=s["man"], json={"period": "weekly", "format": "pdf"}).status_code == 409
    client.post("/api/v1/reports/schedules", headers=s["aud"], json={"period": "daily", "format": "csv"})
    assert len(get(client, s["man"], "/reports/schedules").json()) == 1 and client.delete(f"/api/v1/reports/schedules/{sid + 1}", headers=s["man"]).status_code == 404   # own only
    with SessionLocal() as db: assert report.run_due(db, utcnow()) == 0                                                         # not due yet
    with SessionLocal() as db: assert report.run_due(db, utcnow() + timedelta(days=8)) == 2 and report.run_due(db, utcnow() + timedelta(days=8)) == 0
    smtp = FakeSMTP(); monkeypatch.setattr(notify, "settings", dataclasses.replace(notify.settings, smtp_host="127.0.0.1", smtp_port=smtp.port, smtp_starttls=0))
    with SessionLocal() as db: notify.deliver_pending(db)
    assert any("application/pdf" in m and "cybershield-weekly-" in m for m in smtp.msgs) and any("text/csv" in m for m in smtp.msgs)
    with SessionLocal() as db:
        assert all(n.attach_data is None and n.status == "sent" for n in db.query(Notification).filter(Notification.attach_name.isnot(None)))
        assert "report.scheduled" in {e.action for e in db.query(AuditLog)}
    assert client.delete(f"/api/v1/reports/schedules/{sid}", headers=s["man"]).status_code == 200

def test_RET01_policy_config_rbac_and_audit(client, admin):                         # FR-ADM-01, SR-13
    s = staff(client, admin); r = get(client, admin["h"], "/admin/retention").json(); d = {x["category"]: x for x in r}
    assert (d["events"]["hot_days"], d["events"]["archive_days"]) == (30, 365) and d["audit"]["enforced_by_application"] is False and d["incidents"]["enforced_by_application"] is False
    assert get(client, s["aud"], "/admin/retention").status_code == 200 and get(client, s["ana"], "/admin/retention").status_code == 403 and get(client, s["man"], "/admin/retention").status_code == 403
    assert client.put("/api/v1/admin/retention/events", headers=s["aud"], json={"hot_days": 10, "archive_days": 10}).status_code == 403
    for bad in ({"hot_days": 0, "archive_days": 1}, {"hot_days": 5000, "archive_days": 1}, {"hot_days": 5, "archive_days": -1}): assert client.put("/api/v1/admin/retention/events", headers=admin["h"], json=bad).status_code == 422
    assert client.put("/api/v1/admin/retention/events", headers=admin["h"], json={"hot_days": 14, "archive_days": 90}).status_code == 200 and client.put("/api/v1/admin/retention/nope", headers=admin["h"], json={"hot_days": 1, "archive_days": 1}).status_code == 404
    with SessionLocal() as db: e = [x for x in db.query(AuditLog) if x.action == "retention.update"][0]
    assert e.old_value == "hot=30 archive=365" and e.new_value == "hot=14 archive=90"

def test_RET02_enforcement_archives_keeps_evidence_never_touches_audit(client, admin, tmp_path):   # FR-ADM-01, SRS 6.5
    ad = str(tmp_path / "arch"); run3(fails(12)); run3([E(500 + i, "auth.success", user="u", src_ip="192.0.2.50", message=f"ok {i}") for i in range(5)]); run3(rec(3, et="proc.start"))
    now = T0 + timedelta(days=40)
    with SessionLocal() as db: linked = {e for e in db.scalars(select(AlertEvent.event_id))}; audit_n = db.query(AuditLog).count()
    with SessionLocal() as db: r = retention.run(db, now=now, archive_dir=ad)
    assert r["events_archived"] == 5 and r["alerts_archived"] == 0                      # alert is still Open; its evidence events are kept
    with SessionLocal() as db: assert db.query(Event).count() == 12 + 3 and linked <= {e.id for e in db.query(Event)}
    files = os.listdir(ad); assert len(files) == 1 and files[0].startswith("events_")
    rows = [json.loads(l) for l in gzip.open(os.path.join(ad, files[0]), "rt")]; assert len(rows) == 5 and {x["username"] for x in rows} == {"u"} and all(x["hash"] for x in rows)
    with SessionLocal() as db: assert retention.run(db, now=now, archive_dir=ad)["events_archived"] == 0   # idempotent
    with SessionLocal() as db: a = db.query(Alert).one(); a.status = "Resolved"; db.commit()
    with SessionLocal() as db: r = retention.run(db, now=utcnow() + timedelta(days=380), archive_dir=ad)  # real clock (alerts are stamped with it): past the 365-day alert window, before the 395-day events archive expiry
    assert r["alerts_archived"] == 1 and r["events_archived"] == 12 + 3                  # alert gone, so its events are no longer protected
    with SessionLocal() as db: assert db.query(Alert).count() == 0 and db.query(Event).count() == 0 and db.query(AlertEvent).count() == 0
    assert any(f.startswith("alerts_") for f in os.listdir(ad))
    with SessionLocal() as db: assert db.query(AuditLog).count() == audit_n and audit.verify_chain(db) is True        # audit log untouched
    # archives follow hot + archive days: the first events file (395 d) went in the previous run; the second goes now; alerts keep 365 + 1095 days
    with SessionLocal() as db: r = retention.run(db, now=utcnow() + timedelta(days=900), archive_dir=ad)
    assert r["archive_files_deleted"] == 1 and [f.split("_")[0] for f in os.listdir(ad)] == ["alerts"]
    with SessionLocal() as db: r = retention.run(db, now=utcnow() + timedelta(days=2000), archive_dir=ad)
    assert r["archive_files_deleted"] == 1 and os.listdir(ad) == []

def test_RET03_incident_alerts_and_open_alerts_and_expired_iocs(client, admin, tmp_path):
    s = staff(client, admin); ad = str(tmp_path / "arch"); run3(fails(12) + fails(12, ip="203.0.113.6", start=1000)); ids = [a[0] for a in alerts()]
    client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": [ids[0]]})
    with SessionLocal() as db:
        for a in db.query(Alert): a.status = "Resolved"
        db.add(IOC(type="ip", value="1.2.3.4", expires_at=utcnow() - timedelta(days=1))); db.add(IOC(type="ip", value="5.6.7.8", expires_at=None)); db.commit()
    with SessionLocal() as db: r = retention.run(db, now=utcnow() + timedelta(days=400), archive_dir=ad)
    assert r["alerts_archived"] == 1 and r["iocs_expired"] == 1
    with SessionLocal() as db: assert [a.id for a in db.query(Alert)] == [ids[0]] and [i.value for i in db.query(IOC)] == ["5.6.7.8"]   # incident evidence kept
    assert client.post("/api/v1/admin/retention/run", headers=admin["h"]).status_code == 200 and client.post("/api/v1/admin/retention/run", headers=s["aud"]).status_code == 403

def test_BAK01_encrypted_round_trip_into_a_fresh_database(client, admin):          # FR-ADM-03, UC-09, SR-07
    ana = make_user(client, admin, "Security Analyst", "ana"); HA = H(login(client, "ana", ana["mfa_secret"]).json()["token"])
    client.post("/api/v1/assets", headers=admin["h"], json={"hostname": "web01", "ip_address": "10.0.0.5", "criticality": 5, "owner": "IT"})
    client.post("/api/v1/sources", headers=admin["h"], json={"name": "lab-agent", "source_type": "agent"}); client.post("/api/v1/iocs/import", headers=admin["h"], json={"csv": "ip,203.0.113.99,feed,80,\n"})
    client.post("/api/v1/rules", headers=HA, json={"name": "Custom rule", "severity": "High", "logic": {"type": "match", "match": {"event_type": "x.y"}}})
    client.post("/api/v1/suppressions", headers=HA, json={"src_ip": "192.0.2.9", "reason": "known scanner", "expires_in_days": 30}); client.put("/api/v1/admin/retention/events", headers=admin["h"], json={"hot_days": 21, "archive_days": 100})
    PP = "a long backup passphrase 42"; r = client.post("/api/v1/admin/backup", headers=admin["h"], json={"passphrase": PP, "include_users": True}); assert r.status_code == 200
    blob = r.content; assert b"argon2" not in blob and b"ana@x.pk" not in blob and b"web01" not in blob and b"AES-256-GCM" in blob           # nothing readable
    Base.metadata.drop_all(engine); init_db()                                          # a brand new, empty system
    new = client.post("/api/v1/setup", json={"username": "boss", "name": "B", "email": "b@x.pk", "password": PW}).json(); HB = H(login(client, "boss", new["mfa_secret"]).json()["token"])
    b64 = base64.b64encode(blob).decode(); body = lambda **k: {"passphrase": PP, "backup_base64": b64, "include_users": True, **k}
    assert client.post("/api/v1/admin/restore", headers=HB, json=body(passphrase="the wrong passphrase 1")).status_code == 400
    tam = bytearray(blob); tam[-20] ^= 1; assert client.post("/api/v1/admin/restore", headers=HB, json=body(backup_base64=base64.b64encode(bytes(tam)).decode())).status_code == 400
    assert client.post("/api/v1/admin/restore", headers=HB, json=body(passphrase="short")).status_code == 422
    assert client.post("/api/v1/admin/restore", headers=HB, json=body(backup_base64="!!!")).status_code == 400
    out = client.post("/api/v1/admin/restore", headers=HB, json=body()); assert out.status_code == 200, out.text; c = out.json()["restored"]
    assert c["assets"] == 1 and c["log_sources"] == 1 and c["iocs"] == 1 and c["users"] == 2 and c["suppressions"] == 1
    assert [a["hostname"] for a in get(client, HB, "/assets").json()] == ["web01"] and "Custom rule" in {x["name"] for x in get(client, HB, "/rules").json()}   # rules visible to Admin (R)
    assert [x["value"] for x in get(client, HB, "/iocs").json()] == ["203.0.113.99"] and {x["category"]: x["hot_days"] for x in get(client, HB, "/admin/retention").json()}["events"] == 21
    assert login(client, "ana", ana["mfa_secret"]).status_code == 200 and login(client, "boss", new["mfa_secret"]).status_code == 200      # password hash and MFA secret restored
    with SessionLocal() as db: assert db.query(Event).count() == 0 and {e.action for e in db.query(AuditLog)} >= {"backup.restore"}            # events untouched, restore audited

def test_BAK02_rbac_no_admin_guard_and_users_optional(client, admin):
    s = staff(client, admin); PP = "another long passphrase 9"
    for h in (s["ana"], s["man"], s["aud"]): assert client.post("/api/v1/admin/backup", headers=h, json={"passphrase": PP}).status_code == 403
    assert client.post("/api/v1/admin/backup", headers=admin["h"], json={"passphrase": "short"}).status_code == 422
    with SessionLocal() as db:
        snap = backup.snapshot(db, True); assert backup.decrypt(PP, backup.encrypt(PP, snap))["tables"]["users"]
        for u in snap["tables"]["users"]: u["status"] = "disabled"
        with pytest.raises(ValueError): backup.restore(db, snap)                       # would lock everyone out
        db.rollback()
    b = client.post("/api/v1/admin/backup", headers=admin["h"], json={"passphrase": PP}).content                                   # without users
    assert "users" not in backup.decrypt(PP, b)["tables"]
    assert client.post("/api/v1/admin/restore", headers=admin["h"], json={"passphrase": PP, "backup_base64": base64.b64encode(b).decode()}).status_code == 200

def test_HLT01_health_components_public_probe_and_worker_states(client, admin, monkeypatch):    # FR-ADM-02, SRS 5.5
    s = staff(client, admin); assert get(client, admin["h"], "/admin/health").json()["status"] == "degraded"           # SMTP not configured: alerts cannot be e-mailed
    n = [c for c in get(client, admin["h"], "/admin/health").json()["components"] if c["name"] == "notification service"][0]; assert n["status"] == "degraded" and "SMTP not configured" in n["detail"]
    monkeypatch.setattr(routes_admin, "settings", dataclasses.replace(routes_admin.settings, smtp_host="smtp.example"))
    h = get(client, admin["h"], "/admin/health").json()
    assert {c["name"] for c in h["components"]} >= {"database", "queue", "detection engine", "background worker", "notification service", "collectors"} and h["status"] == "ok"
    assert [c for c in h["components"] if c["name"] == "background worker"][0]["status"] == "disabled"
    assert get(client, s["aud"], "/admin/health").status_code == 200 and get(client, s["ana"], "/admin/health").status_code == 403 and get(client, s["man"], "/admin/health").status_code == 403
    p = client.get("/api/v1/health"); assert p.status_code == 200 and p.json() == {"status": "ok"}                                   # no detail, no auth
    with SessionLocal() as db: db.add(QueueItem(source_type="api", origin="live", fmt="json", payload="{}", received_at=utcnow() - timedelta(minutes=5))); db.commit()
    assert get(client, admin["h"], "/admin/health").json()["status"] == "degraded"
    monkeypatch.setattr(routes_admin, "settings", dataclasses.replace(routes_admin.settings, ingest_worker=1))
    assert get(client, admin["h"], "/admin/health").json()["status"] == "down" and client.get("/api/v1/health").status_code == 503      # worker silent
    with SessionLocal() as db: maintenance.heartbeat(db)
    assert [c for c in get(client, admin["h"], "/admin/health").json()["components"] if c["name"] == "background worker"][0]["status"] == "ok"

def test_STX01_stix_bundle_import_feeds_detection(client, admin):                  # FR-ADM-05
    s = staff(client, admin); h = "c" * 64
    bundle = {"type": "bundle", "objects": [
        {"type": "indicator", "pattern": "[ipv4-addr:value = '203.0.113.99']", "confidence": 90},
        {"type": "indicator", "pattern": "[domain-name:value = 'Evil.Example.org']"},
        {"type": "indicator", "pattern": f"[file:hashes.'SHA-256' = '{h}']", "valid_until": "2030-01-01T00:00:00Z"},
        {"type": "indicator", "pattern": "[ipv4-addr:value = '198.51.100.200']", "valid_until": "2020-01-01T00:00:00Z"},
        {"type": "indicator", "pattern": "[ipv4-addr:value = '1.1.1.1' OR ipv4-addr:value = '2.2.2.2']"}, {"type": "malware", "name": "x"}, "junk"]}
    r = client.post("/api/v1/iocs/import-stix", headers=admin["h"], json={"bundle": bundle}).json(); assert r == {"imported": 4, "rejected": 3}
    assert client.post("/api/v1/iocs/import-stix", headers=s["ana"], json={"bundle": bundle}).status_code == 403 and client.post("/api/v1/iocs/import-stix", headers=admin["h"], json={"bundle": {"objects": [{}] * 5001}}).status_code == 413
    run3([E(1, "net.fw", src_ip="10.1.1.1", dst_ip="203.0.113.99", message="c"), E(2, "net.fw", src_ip="10.1.1.2", dst_ip="198.51.100.200", message="expired")])
    assert [a[1] for a in alerts()] == ["src_ip:10.1.1.1"]

def test_CMP01_compliance_view_is_evidence_not_certification(client, admin):       # FR-RPT-04 (Could), SRS 7.10
    s = staff(client, admin)
    for fw in ("iso27001", "nist_csf"):
        d = get(client, s["ana"], f"/compliance/{fw}").json(); assert "not certification" in d["disclaimer"] and len(d["controls"]) >= 6 and all(c["status"] in ("evidence available", "gap") for c in d["controls"])
    iso = {c["id"]: c for c in get(client, s["aud"], "/compliance/iso27001").json()["controls"]}; assert iso["A.8.13"]["status"] == "gap" and iso["A.8.15"]["status"] == "evidence available"
    client.post("/api/v1/admin/backup", headers=admin["h"], json={"passphrase": "a long backup passphrase 42"})
    iso = {c["id"]: c for c in get(client, s["aud"], "/compliance/iso27001").json()["controls"]}; assert iso["A.8.13"]["status"] == "evidence available" and iso["A.8.13"]["evidence"]["backups_created"] == 1
    assert get(client, s["ana"], "/compliance/cobit").status_code == 404 and get(client, {}, "/compliance/iso27001").status_code == 401

def test_MNT01_worker_housekeeping_is_throttled_and_safe(client, admin, tmp_path, monkeypatch):
    monkeypatch.setattr(retention.settings, "archive_dir", str(tmp_path / "a"), raising=False) if False else None
    with SessionLocal() as db: maintenance.tick(db); maintenance.tick(db); assert db.get(IngestMetric, "worker_heartbeat").value > 0
    with SessionLocal() as db: r = retention.run_if_due(db, utcnow()); assert r is None or isinstance(r, dict)
