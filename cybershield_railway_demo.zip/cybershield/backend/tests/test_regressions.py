"""Regression tests for bugs found in review (see FIXES.md, second round)."""
import json
from sqlalchemy import select
from app import detect, ingest
from app.db import SessionLocal
from app.models import Alert, Event, IOC, LogSource, PasswordReset, QueueItem, utcnow
from app import security as sec
from conftest import PW, login, make_user
from test_module3 import E, run, fails, alerts

def H(t): return {"Authorization": f"Bearer {t}"}
def tok(c, admin, role, name):
    u = make_user(c, admin, role, name); return H(login(c, name, u.get("mfa_secret")).json()["token"])

def test_deleted_source_does_not_jam_the_worker(client, admin):
    s = client.post("/api/v1/sources", headers=admin["h"], json={"name": "gone", "source_type": "api"}).json()
    assert client.post("/api/v1/events", headers={"X-Source-Token": s["token"]}, json=[E(1, "auth.failure", src_ip="192.0.2.1", message="x")]).status_code == 202
    assert client.delete(f"/api/v1/sources/{s['id']}", headers=admin["h"]).status_code == 200
    with SessionLocal() as db: ingest.process_queue(db)            # used to raise AttributeError forever
    with SessionLocal() as db: assert db.query(QueueItem).filter_by(status="pending").count() == 0 and db.query(Event).count() == 1

def test_duplicate_indicator_in_one_import(client, admin):
    r = client.post("/api/v1/iocs/import", headers=admin["h"], json={"csv": "ip,203.0.113.9,a,50,\nip,203.0.113.9,b,60,\n"})
    assert r.status_code == 200 and r.json()["imported"] == 2
    ind = {"type": "indicator", "pattern": "[domain-name:value = 'evil.example']"}
    r = client.post("/api/v1/iocs/import-stix", headers=admin["h"], json={"bundle": {"objects": [ind, ind, {**ind, "pattern": "[domain-name:value = 'x.example']", "valid_until": 5}]}})
    assert r.status_code == 200 and r.json() == {"imported": 2, "rejected": 1}
    with SessionLocal() as db: assert db.query(IOC).count() == 2

def test_rule_rename_conflict_is_409(client, admin):
    h = tok(client, admin, "Security Analyst", "ana")
    rules = client.get("/api/v1/rules", headers=h).json(); a, b = rules[0], rules[1]
    r = client.put(f"/api/v1/rules/{a['id']}", headers=h, json={"name": b["name"], "severity": a["severity"], "logic": a["logic"]})
    assert r.status_code == 409

def test_user_edit_email_conflict_self_role_and_new_mfa_secret(client, admin):
    u = make_user(client, admin, "Auditor", "aud"); make_user(client, admin, "Manager", "man")
    me = client.get("/api/v1/auth/me", headers=admin["h"]).json()
    assert client.patch(f"/api/v1/users/{u['id']}", headers=admin["h"], json={"email": "man@x.pk"}).status_code == 409
    assert client.patch(f"/api/v1/users/{me['id']}", headers=admin["h"], json={"role": "Auditor"}).status_code == 400
    r = client.patch(f"/api/v1/users/{u['id']}", headers=admin["h"], json={"role": "Security Analyst"}).json()
    assert r["mfa_enabled"] and r["mfa_secret"] and login(client, "aud", r["mfa_secret"]).status_code == 200

def test_reset_token_of_deleted_user(client, admin):
    u = make_user(client, admin, "Auditor", "aud")
    with SessionLocal() as db:
        db.add(PasswordReset(user_id=u["id"], token_hash=sec.token_hash("t0k"), expires_at=utcnow().replace(year=2100))); db.commit()
    assert client.delete(f"/api/v1/users/{u['id']}", headers=admin["h"]).status_code == 200
    r = client.post("/api/v1/auth/password-reset/confirm", json={"token": "t0k", "new_password": "Another-Strong-Pass-7"})
    assert r.status_code == 400                                     # was 500 (or, with a reused id, someone else's account)

def test_second_analyst_can_pick_up_reopened_alert(client, admin):
    a1, a2 = tok(client, admin, "Security Analyst", "ana"), tok(client, admin, "Security Analyst", "bob")
    run(fails(12)); aid = alerts()[0][0]
    assert client.patch(f"/api/v1/alerts/{aid}", headers=a1, json={"status": "Investigating"}).status_code == 200
    assert client.patch(f"/api/v1/alerts/{aid}", headers=a1, json={"status": "Open"}).status_code == 200
    assert client.patch(f"/api/v1/alerts/{aid}", headers=a2, json={"status": "Investigating"}).status_code == 200
    assert client.patch(f"/api/v1/alerts/{aid}", headers=a2, json={"note": "still mine"}).status_code == 200   # was 409
    assert client.patch(f"/api/v1/alerts/{aid}", headers=a1, json={"note": "not mine"}).status_code == 409

def test_rule_window_with_numeric_and_text_values(client):
    L = {"type": "threshold", "match": {"severity": "4", "event_type": "auth.failure"}, "group_by": "src_ip", "more_than": 2, "window_seconds": 300}
    run([E(i, "auth.failure", src_ip="192.0.2.77", severity=4, message=f"f{i}") for i in range(4)])
    with SessionLocal() as db:
        ev = detect.ev_dict(db.scalars(select(Event).order_by(Event.timestamp.desc())).first())
        assert detect.eval_rule(L, ev, detect.DBStore(db)) is not None
