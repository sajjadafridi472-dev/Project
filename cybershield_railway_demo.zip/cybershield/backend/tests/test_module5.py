import base64, hashlib
from datetime import timedelta
import pytest
from sqlalchemy import select
from app import respond
from app.db import SessionLocal
from app.models import Alert, AuditLog, Event, Incident, IncidentAlert, utcnow
from conftest import login, make_user
from test_module3 import E, fails, run, alerts
from test_module4 import staff, H

def two_alerts():
    run(fails(12, ip="203.0.113.5") + fails(12, ip="203.0.113.6", start=1000)); a = alerts(); assert len(a) == 2; return [x[0] for x in a]

def mk(client, s, ids=None, **kw):
    r = client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": ids or [two_alerts()[0]], **kw}); assert r.status_code == 201, r.text; return r.json()

def test_INC01_convert_alerts_and_rbac(client, admin):                              # FR-INC-01, UC-04, SRS 7.8
    s = staff(client, admin); ids = two_alerts()
    i = mk(client, s, ids); assert i["status"] == "New" and i["owner"] == "ana" and i["incident_type"] == "brute_force" and i["severity"] in ("Medium", "High")
    with SessionLocal() as db: assert {a.status for a in db.scalars(select(Alert))} == {"Investigating"}
    assert client.post("/api/v1/incidents", headers=s["bea"], json={"alert_ids": [ids[0]]}).status_code == 409        # already linked
    assert client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": [9999]}).status_code == 404
    assert client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": []}).status_code == 422
    for who in ("man", "aud"): assert client.post("/api/v1/incidents", headers=s[who], json={"alert_ids": ids}).status_code == 403
    assert client.post("/api/v1/incidents", headers=admin["h"], json={"alert_ids": ids}).status_code == 403
    for who in ("man", "aud", "ana"): assert client.get("/api/v1/incidents", headers=s[who]).status_code == 200      # R for Manager/Auditor
    assert client.get("/api/v1/incidents", headers=admin["h"]).status_code == 403                                      # Admin: none
    assert client.get("/api/v1/incidents").status_code == 401 and client.delete(f"/api/v1/incidents/{i['id']}", headers=s["ana"]).status_code == 405

def test_INC02_false_positive_alert_cannot_be_converted(client, admin):
    s = staff(client, admin); a = two_alerts()[0]; client.patch(f"/api/v1/alerts/{a}", headers=s["ana"], json={"status": "False Positive"})
    assert client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": [a]}).status_code == 409

def test_INC03_state_machine_timeline_and_audit(client, admin):                   # FR-INC-02, FR-INC-03, AC-11
    s = staff(client, admin); i = mk(client, s); url = f"/api/v1/incidents/{i['id']}"
    for bad in ("Closed", "Resolved", "Contained"): assert client.patch(url, headers=s["ana"], json={"status": bad}).status_code == 409     # from New
    for st in ("Investigating", "Contained", "Resolved", "Closed"): assert client.patch(url, headers=s["ana"], json={"status": st}).status_code == 200
    assert client.patch(url, headers=s["ana"], json={"status": "Investigating"}).status_code == 409                    # Closed is final
    d = client.get(url, headers=s["aud"]).json(); st = [(e["old"], e["new"], e["user"]) for e in d["timeline"] if e["kind"] == "state"]
    assert st == [("New", "Investigating", "ana"), ("Investigating", "Contained", "ana"), ("Contained", "Resolved", "ana"), ("Resolved", "Closed", "ana")]
    assert all(d[k] for k in ("acknowledged_at", "contained_at", "resolved_at", "closed_at")) and d["time_to_resolve_s"] is not None
    with SessionLocal() as db: assert sum(1 for e in db.query(AuditLog) if e.action == "incident.status") == 4

def two_alerts_ids():
    with SessionLocal() as db: return [a.id for a in db.scalars(select(Alert).order_by(Alert.id))]

def test_INC04_reopen_and_false_positive_paths(client, admin):
    s = staff(client, admin); i = mk(client, s); url = f"/api/v1/incidents/{i['id']}"
    client.patch(url, headers=s["ana"], json={"status": "Investigating"}); client.patch(url, headers=s["ana"], json={"status": "Resolved"})
    assert client.patch(url, headers=s["ana"], json={"status": "Investigating"}).status_code == 200                      # reopen
    d = client.get(url, headers=s["ana"]).json(); assert d["resolved_at"] is None and d["status"] == "Investigating"
    assert client.patch(url, headers=s["ana"], json={"status": "False Positive"}).status_code == 200
    d = client.get(url, headers=s["ana"]).json(); assert d["false_positive"] is True and all(a["status"] == "False Positive" for a in d["alerts"])
    assert client.patch(url, headers=s["ana"], json={"status": "Closed"}).status_code == 200

def test_INC05_resolve_syncs_alert_status(client, admin):
    s = staff(client, admin); i = mk(client, s); url = f"/api/v1/incidents/{i['id']}"
    client.patch(url, headers=s["ana"], json={"status": "Investigating"}); client.patch(url, headers=s["ana"], json={"status": "Resolved"})
    assert [a["status"] for a in client.get(url, headers=s["ana"]).json()["alerts"]] == ["Resolved"]

def test_INC06_owner_assignment_only_analysts(client, admin):                      # FR-INC-03
    s = staff(client, admin); i = mk(client, s); url = f"/api/v1/incidents/{i['id']}"
    for who in ("man", "aud", "root", "nobody"): assert client.patch(url, headers=s["ana"], json={"owner": who}).status_code == 422
    assert client.patch(url, headers=s["ana"], json={"owner": "bea"}).json()["owner"] == "bea"
    assert ("assign", "ana", "bea") in [(e["kind"], e["old"], e["new"]) for e in client.get(url, headers=s["ana"]).json()["timeline"]]

def test_INC07_metrics_arithmetic_and_fp_excluded(client, admin):                  # FR-INC-07, FR-RPT-03 basis, AC-11 "metrics correct"
    s = staff(client, admin); ids = two_alerts(); a = mk(client, s, [ids[0]]); b = mk(client, s, [ids[1]])
    t0 = utcnow() - timedelta(hours=5)
    with SessionLocal() as db:
        for inc, al, (ttd, tta, ttc, ttr) in ((a["id"], ids[0], (60, 120, 600, 3600)), (b["id"], ids[1], (180, 240, None, 7200))):
            al_row = db.get(Alert, al); al_row.created_at = t0
            i = db.get(Incident, inc); i.first_event_at = t0 - timedelta(seconds=ttd); i.acknowledged_at = t0 + timedelta(seconds=tta)
            i.contained_at = t0 + timedelta(seconds=ttc) if ttc else None; i.resolved_at = t0 + timedelta(seconds=ttr); i.status = "Resolved"
        db.commit()
    d = client.get(f"/api/v1/incidents/{a['id']}", headers=s["man"]).json()
    assert (d["time_to_detect_s"], d["time_to_acknowledge_s"], d["time_to_contain_s"], d["time_to_resolve_s"]) == (60, 120, 600, 3600)
    m = client.get("/api/v1/incidents/metrics", headers=s["man"]).json()
    assert (m["MTTD_s"], m["mean_time_to_acknowledge_s"], m["mean_time_to_contain_s"], m["MTTR_s"]) == (120, 180, 600, 5400)   # contain mean ignores missing
    with SessionLocal() as db: db.get(Incident, b["id"]).false_positive = True; db.commit()
    assert client.get("/api/v1/incidents/metrics", headers=s["man"]).json()["MTTR_s"] == 3600                            # false positives excluded
    assert client.get("/api/v1/incidents/metrics", headers=admin["h"]).status_code == 403

def test_INC08_notes_evidence_attachments(client, admin):                          # FR-INC-04
    s = staff(client, admin); i = mk(client, s); u = f"/api/v1/incidents/{i['id']}"; ok = b"ip,count\n203.0.113.5,12\n"
    assert client.post(u + "/notes", headers=s["ana"], json={"text": "<b>checked</b> logs"}).status_code == 201
    assert client.post(u + "/evidence", headers=s["ana"], json={"url": "https://ticket.example/1", "label": "ticket"}).status_code == 201
    assert client.post(u + "/evidence", headers=s["ana"], json={"url": "javascript:alert(1)"}).status_code == 422
    body = lambda **k: {"filename": "evidence.csv", "content_type": "text/csv", "data_base64": base64.b64encode(ok).decode(), **k}
    r = client.post(u + "/attachments", headers=s["ana"], json=body()); assert r.status_code == 201 and r.json()["sha256"] == hashlib.sha256(ok).hexdigest()
    for bad in (body(content_type="text/html"), body(content_type="application/x-msdownload"), body(filename="../etc/passwd"), body(filename="a/b.csv"),
                body(data_base64="!!notbase64!!"), body(data_base64=base64.b64encode(b"x" * 1_000_001).decode())):
        assert client.post(u + "/attachments", headers=s["ana"], json=bad).status_code == 422
    for who in ("man", "aud"): assert client.post(u + "/notes", headers=s[who], json={"text": "x"}).status_code == 403
    dl = client.get(u + f"/attachments/{r.json()['id']}", headers=s["aud"]); assert dl.content == ok
    assert dl.headers["x-content-type-options"] == "nosniff" and dl.headers["content-disposition"].startswith("attachment")
    assert client.get(u + "/attachments/999", headers=s["aud"]).status_code == 404
    t = client.get(u, headers=s["man"]).json()["timeline"]; assert {"note", "evidence", "attachment"} <= {e["kind"] for e in t}

def test_INC09_playbooks_by_type_and_ticking(client, admin):                       # FR-INC-05
    s = staff(client, admin); i = mk(client, s); d = client.get(f"/api/v1/incidents/{i['id']}", headers=s["ana"]).json()
    assert len(d["playbook"]) >= 5 and any("block" in p["text"].lower() for p in d["playbook"])                           # brute-force playbook
    pid = d["playbook"][0]["id"]; assert client.patch(f"/api/v1/incidents/{i['id']}/playbook/{pid}", headers=s["ana"], json={"done": True}).status_code == 200
    p = client.get(f"/api/v1/incidents/{i['id']}", headers=s["ana"]).json()["playbook"][0]; assert p["done"] and p["done_by"] == "ana" and p["done_at"]
    assert client.patch(f"/api/v1/incidents/{i['id']}/playbook/{pid}", headers=s["man"], json={"done": False}).status_code == 403
    run(fails(12, ip="203.0.113.77", start=9000)); new = [x[0] for x in alerts() if x[1].endswith("77")]
    ph = mk(client, s, new, incident_type="phishing"); assert any("mailbox" in p["text"].lower() for p in client.get(f"/api/v1/incidents/{ph['id']}", headers=s["ana"]).json()["playbook"])
    assert client.post("/api/v1/incidents", headers=s["ana"], json={"alert_ids": [1], "incident_type": "worm"}).status_code == 422

def test_INC10_response_requires_manager_approval(client, admin, monkeypatch):    # FR-INC-06, SRS 7.8
    s = staff(client, admin); i = mk(client, s); calls = []
    monkeypatch.setattr(respond, "execute", lambda a, t: calls.append((a, t)) or ("executed", "blocked"))
    for bad in ("127.0.0.1", "169.254.1.1", "224.0.0.1", "0.0.0.0", "not-an-ip"): assert client.post(f"/api/v1/incidents/{i['id']}/responses", headers=s["ana"], json={"action": "block_ip", "target": bad}).status_code == 422
    assert client.post(f"/api/v1/incidents/{i['id']}/responses", headers=s["ana"], json={"action": "format_disk", "target": "1.2.3.4"}).status_code == 422
    r1 = client.post(f"/api/v1/incidents/{i['id']}/responses", headers=s["ana"], json={"action": "block_ip", "target": "203.0.113.5"}).json()
    r2 = client.post(f"/api/v1/incidents/{i['id']}/responses", headers=s["ana"], json={"action": "block_ip", "target": "203.0.113.6"}).json()
    assert calls == []                                                                  # proposing never executes
    for who in ("ana", "aud"): assert client.patch(f"/api/v1/responses/{r1['id']}", headers=s[who], json={"decision": "approve"}).status_code == 403
    assert client.patch(f"/api/v1/responses/{r1['id']}", headers=admin["h"], json={"decision": "approve"}).status_code == 403
    assert calls == [] and client.patch(f"/api/v1/responses/{r1['id']}", headers=s["man"], json={"decision": "approve"}).json()["status"] == "executed" and calls == [("block_ip", "203.0.113.5")]
    assert client.patch(f"/api/v1/responses/{r2['id']}", headers=s["man"], json={"decision": "reject"}).json()["status"] == "rejected" and len(calls) == 1
    assert client.patch(f"/api/v1/responses/{r1['id']}", headers=s["man"], json={"decision": "approve"}).status_code == 409 and len(calls) == 1   # decided once
    with SessionLocal() as db: acts = [e.action for e in db.query(AuditLog)]
    assert "response.approve" in acts and "response.reject" in acts

def test_INC11_default_executor_is_an_honest_dry_run(client, admin):
    s = staff(client, admin); i = mk(client, s)
    r = client.post(f"/api/v1/incidents/{i['id']}/responses", headers=s["ana"], json={"action": "block_ip", "target": "203.0.113.5"}).json()
    out = client.patch(f"/api/v1/responses/{r['id']}", headers=s["man"], json={"decision": "approve"}).json()
    assert out["status"] == "not_executed" and "no firewall connector" in out["result"].lower()

def test_INC12_add_alerts_recomputes_detection_time(client, admin):
    s = staff(client, admin); ids = two_alerts(); i = mk(client, s, [ids[0]]); url = f"/api/v1/incidents/{i['id']}"
    first = lambda: client.get(url, headers=s["ana"]).json()["first_event_at"]; before = first()
    run(fails(12, ip="203.0.113.9", start=-5000)); early = [a[0] for a in alerts() if a[1].endswith(".9")][0]
    assert client.post(url + "/alerts", headers=s["ana"], json={"alert_ids": [early]}).status_code == 200
    assert first() < before                                                              # earliest linked event moved back
    assert len(client.get(url, headers=s["ana"]).json()["alerts"]) == 2
    assert client.post(url + "/alerts", headers=s["ana"], json={"alert_ids": [early]}).status_code == 409           # already linked
    run(fails(12, ip="203.0.113.10", start=20000)); fresh = [a[0] for a in alerts() if a[1].endswith(".10")][0]
    for st in ("False Positive", "Closed"): client.patch(url, headers=s["ana"], json={"status": st})
    r = client.post(url + "/alerts", headers=s["ana"], json={"alert_ids": [fresh]}); assert r.status_code == 409 and "closed" in r.json()["detail"].lower()
