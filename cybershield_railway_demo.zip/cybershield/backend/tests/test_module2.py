import hashlib, socket, time
from datetime import timedelta
import pytest
from app import ingest
from app.db import SessionLocal
from app.models import LogSource, Event, utcnow
from conftest import login, make_user

def drain():
    with SessionLocal() as db:
        while ingest.process_queue(db): pass

def mk_source(c, admin, name, typ):
    r = c.post("/api/v1/sources", headers=admin["h"], json={"name": name, "source_type": typ}); assert r.status_code == 201, r.text
    return r.json()

def post(c, tok, items): return c.post("/api/v1/events", headers={"X-Source-Token": tok}, json=items)
def ev(i=0, **kw):
    d = {"timestamp": "2026-10-19T09:15:02Z", "hostname": "web01", "event_type": "auth.failure", "severity": 3,
         "user": "bob", "src_ip": "203.0.113.5", "message": f"Failed login {i}"}; d.update(kw); return d

def test_COL01_five_source_types_normalised_and_searchable(client, admin):          # FR-COL-01..04, AC-03
    for name, typ in (("win-agent", "agent"), ("lin-agent", "agent"), ("fw-ids", "ids"), ("app-api", "api")):
        s = mk_source(client, admin, name, typ)
        assert post(client, s["token"], [ev(hostname=name, message=f"hello from {name}")]).status_code == 202
    mk_source(client, admin, "fw-syslog", "syslog")
    r = client.post("/api/v1/ingest/import", headers=admin["h"], json={"format": "syslog", "content":
        "<34>1 2026-10-19T09:15:02Z fw01 kernel - - - IN=eth0 SRC=198.51.100.7 DST=10.0.0.5 PROTO=TCP DPT=22"})
    assert r.status_code == 202
    drain()
    rows = client.get("/api/v1/events", headers=admin["h"]).json()
    assert {e["source_type"] for e in rows} >= {"agent", "ids", "api", "syslog"} and len(rows) == 5
    e = [x for x in rows if x["hostname"] == "win-agent"][0]
    assert e["hash"] and len(e["hash"]) == 64 and e["data_origin"] == "live"
    assert len(client.get("/api/v1/events?q=hello", headers=admin["h"]).json()) == 4

def test_COL02_syslog_parsing_and_severity():                                         # FR-COL-02/04, section 6.3
    a = ingest.parse_syslog("<38>Oct 19 09:15:02 web01 sshd[1]: Failed password for invalid user admin from 203.0.113.50 port 4 ssh2")
    assert (a["event_type"], a["username"], a["src_ip"], a["hostname"], a["severity"]) == ("auth.failure", "admin", "203.0.113.50", "web01", 1)
    b = ingest.parse_syslog("<34>1 2026-10-19T09:15:02Z fw01 kernel - - - IN=eth0 SRC=198.51.100.7 DST=10.0.0.5 DPT=22")
    assert (b["event_type"], b["src_ip"], b["dst_ip"], b["severity"]) == ("net.fw", "198.51.100.7", "10.0.0.5", 7)
    with pytest.raises(ValueError): ingest.parse_syslog("not a syslog line")

def test_COL03_malformed_quarantined_and_counted(client, admin):                      # FR-COL-05
    s = mk_source(client, admin, "api1", "api")
    bad = [{"hostname": "h"}, ev(timestamp="yesterday-ish"), ev(src_ip="999.1.1.1"), ev(severity=99),
           ev(event_type="Bad Type!"), "just a string", 42, ev(message="x" * 20000)]
    assert post(client, s["token"], bad + [ev()]).status_code == 202
    drain(); h = client.get("/api/v1/ingest/health", headers=admin["h"]).json()
    assert h["quarantined"] == len(bad) and h["accepted"] == 1 and h["queue_depth"] == 0
    assert len(h["recent_quarantine"]) == len(bad)
    assert len(client.get("/api/v1/events", headers=admin["h"]).json()) == 1

def test_COL04_no_event_lost_on_crash(client, admin, monkeypatch):                   # FR-COL-06, NFR-REL-02, AC-04
    s = mk_source(client, admin, "api1", "api"); N = 25
    assert post(client, s["token"], [ev(i) for i in range(N)]).status_code == 202     # accepted = durably queued
    real, calls = ingest.normalize, {"n": 0}
    def boom(q):
        calls["n"] += 1
        if calls["n"] == 10: raise RuntimeError("simulated processing-node crash")
        return real(q)
    monkeypatch.setattr(ingest, "normalize", boom)
    with pytest.raises(RuntimeError): drain()
    with SessionLocal() as db: assert db.query(Event).count() == 0                    # batch rolled back
    assert client.get("/api/v1/ingest/health", headers=admin["h"]).json()["queue_depth"] == N
    monkeypatch.setattr(ingest, "normalize", real); drain()                           # "restart"
    assert len(client.get("/api/v1/events?limit=500", headers=admin["h"]).json()) == N

def test_COL05_enable_disable_without_restart(client, admin):                         # FR-COL-07, SR-05
    a, b = mk_source(client, admin, "src-a", "api"), mk_source(client, admin, "src-b", "api")
    assert a["token"] != b["token"]
    assert client.patch(f"/api/v1/sources/{a['id']}", headers=admin["h"], json={"status": "disabled"}).status_code == 200
    assert post(client, a["token"], [ev()]).status_code == 401 and post(client, b["token"], [ev()]).status_code == 202
    client.patch(f"/api/v1/sources/{a['id']}", headers=admin["h"], json={"status": "active"})
    assert post(client, a["token"], [ev()]).status_code == 202
    assert client.delete(f"/api/v1/sources/{a['id']}", headers=admin["h"]).status_code == 200
    assert post(client, a["token"], [ev()]).status_code == 401                         # revoked

def test_COL06_silent_source_flagged(client, admin):                                  # FR-COL-08, UC-02 4a
    s = mk_source(client, admin, "quiet", "api"); st = lambda: client.get("/api/v1/sources", headers=admin["h"]).json()[0]["status"]
    assert st() == "pending"
    with SessionLocal() as db: db.get(LogSource, s["id"]).created_at = utcnow() - timedelta(minutes=11); db.commit()
    assert st() == "silent"
    post(client, s["token"], [ev()]); drain(); assert st() == "active"
    with SessionLocal() as db: db.get(LogSource, s["id"]).last_seen = utcnow() - timedelta(minutes=11); db.commit()
    assert st() == "silent"

def test_COL07_log_injection_sanitised(client, admin):                                # SR-21
    s = mk_source(client, admin, "api1", "api")
    post(client, s["token"], [ev(message="line1\nFAKE ALERT\x1b[31m red \x00<script>x</script>")]); drain()
    m = client.get("/api/v1/events", headers=admin["h"]).json()[0]["message"]
    assert "\n" not in m and "\x1b" not in m and "\x00" not in m

def test_COL08_auth_limits_and_rbac(client, admin):                                   # SR-03, SR-17, sample API contract
    s = mk_source(client, admin, "api1", "api")
    assert client.post("/api/v1/events", json=[ev()]).status_code == 401
    assert post(client, "wrong-token", [ev()]).status_code == 401
    assert post(client, s["token"], [ev(i) for i in range(1001)]).status_code == 400
    assert post(client, s["token"], []).status_code == 400
    a = make_user(client, admin, "Security Analyst", "ana"); t = login(client, "ana", a["mfa_secret"]).json()["token"]
    au = make_user(client, admin, "Auditor", "aud"); ta = login(client, "aud").json()["token"]
    H = lambda x: {"Authorization": f"Bearer {x}"}
    assert client.post("/api/v1/sources", headers=H(t), json={"name": "zz", "source_type": "api"}).status_code == 403
    assert client.post("/api/v1/sources", headers=H(ta), json={"name": "zz", "source_type": "api"}).status_code == 403
    assert client.get("/api/v1/sources", headers=H(ta)).status_code == 200
    assert client.get("/api/v1/events", headers=H(t)).status_code == 200
    assert client.post("/api/v1/simulate", headers=H(t), json={"scenario": "benign"}).status_code == 403
    r = client.get("/api/v1/sources", headers=admin["h"]).json()[0]; assert "token" not in r and "token_hash" not in r

def test_COL09_duplicates_counted_not_stored(client, admin):                          # section 6.6
    s = mk_source(client, admin, "api1", "api")
    post(client, s["token"], [ev(1), ev(1), ev(2)]); drain(); post(client, s["token"], [ev(1)]); drain()
    h = client.get("/api/v1/ingest/health", headers=admin["h"]).json()
    assert (h["accepted"], h["duplicates"]) == (2, 2)

def test_COL10_origin_labels_simulated_imported_live(client, admin):                  # master prompt section 6
    s = mk_source(client, admin, "api1", "api"); post(client, s["token"], [ev()])
    client.post("/api/v1/simulate", headers=admin["h"], json={"scenario": "brute_force", "count": 12})
    client.post("/api/v1/simulate", headers=admin["h"], json={"scenario": "port_scan", "count": 8})
    client.post("/api/v1/ingest/import", headers=admin["h"], json={"format": "jsonl", "content": '{"timestamp":"2026-10-19T09:15:02Z","hostname":"h","event_type":"proc.start","message":"m"}\nnot json'})
    drain(); get = lambda o: client.get(f"/api/v1/events?data_origin={o}&limit=500", headers=admin["h"]).json()
    assert len(get("live")) == 1 and len(get("simulated")) == 20 and len(get("imported")) == 1
    assert {e["event_type"] for e in get("simulated")} == {"auth.failure", "net.fw"}
    assert client.get("/api/v1/ingest/health", headers=admin["h"]).json()["quarantined"] == 1

def test_COL11_live_syslog_udp_listener(client, admin):                               # FR-COL-02 (UDP path)
    from app.syslog_listener import start
    mk_source(client, admin, "fw-syslog", "syslog"); stop = start(15514, "fw-syslog")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(b"<38>Oct 19 09:15:02 web01 sshd[1]: Failed password for root from 203.0.113.9 port 1 ssh2", ("127.0.0.1", 15514))
        for _ in range(40):
            drain(); rows = client.get("/api/v1/events", headers=admin["h"]).json()
            if rows: break
            time.sleep(0.1)
    finally: stop()
    assert rows and rows[0]["data_origin"] == "live" and rows[0]["src_ip"] == "203.0.113.9"
    assert client.get("/api/v1/sources", headers=admin["h"]).json()[0]["unauthenticated"] is True
