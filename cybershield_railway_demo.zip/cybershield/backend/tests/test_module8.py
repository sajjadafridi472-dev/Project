"""Close-out checks: event integrity (SR-11), authorization on EVERY route (AC-02), no dynamic SQL (SR-15), audit chain under concurrency (SR-12)."""
import ast, pathlib, threading
import pytest
from fastapi.routing import APIRoute
from sqlalchemy import text
from app import audit, rbac
from app.db import SessionLocal, engine
from app.main import app
from app.models import Event
from conftest import make_user, login
from test_module3 import E, run as run3
from test_module4 import staff

PUBLIC = {"/api/v1/setup", "/api/v1/setup/status", "/api/v1/auth/login", "/api/v1/auth/password-reset/request", "/api/v1/auth/password-reset/confirm", "/api/v1/events", "/api/v1/health"}   # no user session by design
SESSION_ONLY = {"/api/v1/auth/me", "/api/v1/auth/logout", "/api/v1/auth/me/notifications"}                                                                          # any signed-in user

def test_INT01_stored_event_modification_is_detected(client, admin):               # SR-11
    s = staff(client, admin); run3([E(i, "proc.start", message=f"m{i}") for i in range(5)])
    g = lambda h: client.get("/api/v1/admin/integrity/events", headers=h)
    assert g(admin["h"]).json() == {"checked": 5, "modified": 0, "modified_event_ids": [], "intact": True}
    with SessionLocal() as db: e = db.query(Event).first(); eid = e.id; e.raw = e.raw + " tampered"; db.commit()
    r = g(s["aud"]).json(); assert r["intact"] is False and r["modified_event_ids"] == [eid] and r["checked"] == 5
    assert g(s["ana"]).status_code == 403 and g(s["man"]).status_code == 403 and client.get("/api/v1/admin/integrity/events").status_code == 401

def _routes(rs):  # newer FastAPI wraps included routers in a container; walk into it so no route is skipped
    for r in rs:
        if isinstance(r, APIRoute): yield r
        elif hasattr(r, "original_router"): yield from _routes(r.original_router.routes)
        elif getattr(r, "routes", None): yield from _routes(r.routes)

def _rbac_of(dep):
    for d in dep.dependencies:
        f = getattr(d.call, "rbac", None)
        if f: return f
        f = _rbac_of(d)
        if f: return f
    return None

def test_SWP01_every_route_enforces_the_role_matrix(client, admin):                # FR-AUTH-04, SR-03, AC-02: 0 violations
    s = staff(client, admin); toks = {"Administrator": admin["h"], "Security Analyst": s["ana"], "Manager": s["man"], "Auditor": s["aud"]}; bad, checked, unclassified = [], 0, []
    for r in _routes(app.routes):
        meta = _rbac_of(r.dependant)
        if meta is None:
            if r.path not in PUBLIC | SESSION_ONLY: unclassified.append(r.path)
            continue
        method = next(m for m in sorted(r.methods) if m not in ("HEAD", "OPTIONS")); path = r.path
        for part in [x for x in path.split("/") if x.startswith("{")]: path = path.replace(part, "999999")
        kw = {"json": {}} if method in ("POST", "PUT", "PATCH") else {}
        un = client.request(method, path, **kw)
        if un.status_code != 401: bad.append((method, r.path, "anonymous", un.status_code))
        for role, h in toks.items():
            code = client.request(method, path, headers=h, **kw).status_code; ok = rbac.allowed(role, *meta); checked += 1
            if (ok and code in (401, 403)) or (not ok and code != 403): bad.append((method, r.path, role, code, "allowed" if ok else "forbidden"))
    assert unclassified == [], f"routes with no authorization declared: {unclassified}"
    assert bad == [], bad
    assert checked >= 150                                                          # a meaningful number of route x role combinations

def test_SWP02_session_only_routes_reject_anonymous(client):
    for p in ("/api/v1/auth/me", "/api/v1/users"): assert client.get(p).status_code == 401
    assert client.post("/api/v1/auth/logout").status_code == 401 and client.patch("/api/v1/auth/me/notifications", json={"notify_email": True, "min_severity": "High"}).status_code == 401

def test_SQL01_no_dynamic_sql_anywhere_in_the_application():                       # SR-15
    offenders = []
    for f in pathlib.Path(__file__).resolve().parents[1].joinpath("app").glob("*.py"):
        for n in ast.walk(ast.parse(f.read_text())):
            if isinstance(n, ast.Call) and getattr(n.func, "attr", getattr(n.func, "id", "")) in ("text", "exec_driver_sql", "execute") and n.args:
                a = n.args[0]
                if isinstance(a, (ast.JoinedStr, ast.BinOp)) or (isinstance(a, ast.Call) and getattr(a.func, "attr", "") in ("format", "join")): offenders.append(f"{f.name}:{n.lineno}")
    assert offenders == []

@pytest.mark.skipif(engine.dialect.name != "postgresql", reason="advisory lock exists for PostgreSQL; SQLite serialises writers itself")
def test_AUDRACE01_concurrent_audit_writers_keep_the_chain_intact(client):         # SR-12 (the race noted in Module 4)
    errs = []
    def work(k):
        try:
            for i in range(15):
                with SessionLocal() as db: audit.log(db, "race.test", username=f"t{k}", obj=str(i)); db.commit()
        except Exception as e: errs.append(repr(e))
    ts = [threading.Thread(target=work, args=(k,)) for k in range(8)]; [t.start() for t in ts]; [t.join() for t in ts]
    assert errs == []
    with SessionLocal() as db:
        from app.models import AuditLog
        assert db.query(AuditLog).filter_by(action="race.test").count() == 120 and audit.verify_chain(db) is True

@pytest.mark.skipif(engine.dialect.name != "postgresql", reason="row-level claim (FOR UPDATE SKIP LOCKED) is PostgreSQL behaviour")
def test_SCA01_two_parallel_workers_never_process_the_same_queue_item(client):      # NFR-SCA-01 / NFR-REL-02
    from app import ingest
    items = [{"timestamp": "2026-10-19T09:00:00Z", "hostname": "h", "event_type": "proc.start", "severity": 1, "message": f"unique {i}"} for i in range(600)]
    with SessionLocal() as db: ingest.enqueue(db, items, "json", None, "api", "simulated"); db.commit()
    errs = []
    def worker():
        try:
            with SessionLocal() as db:
                while ingest.process_queue(db, batch=40): pass
        except Exception as e: errs.append(repr(e))
    ts = [threading.Thread(target=worker) for _ in range(3)]; [t.start() for t in ts]; [t.join() for t in ts]
    assert errs == []
    with SessionLocal() as db: assert db.query(Event).count() == 600 and db.query(Event.hash).distinct().count() == 600     # nothing lost, nothing doubled


def test_SETUP02_first_run_status_flips_after_setup(client):                         # SRS 7.9: no default credentials
    assert client.get("/api/v1/setup/status").json() == {"needed": True, "token_required": False}
    assert client.post("/api/v1/setup", json={"username": "boss", "name": "B", "email": "b@x.pk", "password": "Correct-Horse-Battery-9"}).status_code == 201
    assert client.get("/api/v1/setup/status").json() == {"needed": False, "token_required": False} and client.post("/api/v1/setup", json={"username": "second", "name": "B", "email": "c@x.pk", "password": "Correct-Horse-Battery-9"}).status_code == 409
