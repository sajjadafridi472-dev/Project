from datetime import timedelta
import pytest
from sqlalchemy import text
from app.db import SessionLocal, engine
from app.models import Session as S, AuditLog, User, utcnow
from app import rbac, dbsetup
from conftest import PW, login, make_user

def H(tok): return {"Authorization": f"Bearer {tok}"}

def test_AUTH01_login_valid_and_invalid(client, admin):                       # FR-AUTH-02
    assert client.post("/api/v1/auth/login", json={"username": "root", "password": "wrong-password-1"}).status_code == 401
    assert client.get("/api/v1/auth/me", headers=admin["h"]).json()["username"] == "root"

def test_AUTH02_mfa_required_and_checked(client, admin):                      # FR-AUTH-03, SR-02
    assert login(client, "root").status_code == 401
    assert client.post("/api/v1/auth/login", json={"username": "root", "password": PW, "otp": "000000"}).status_code == 401
    assert login(client, "root", admin["secret"]).status_code == 200
    assert make_user(client, admin, "Security Analyst", "ana")["mfa_enabled"] is True

def test_AUTH03_lockout_after_five_failures(client, admin):                   # FR-AUTH-05
    u = make_user(client, admin, "Security Analyst", "ana")
    for _ in range(5): login(client, "ana", u["mfa_secret"], pw="bad-password-123")
    assert login(client, "ana", u["mfa_secret"]).status_code == 423
    with SessionLocal() as db:
        db.query(User).filter_by(username="ana").one().locked_until = utcnow() - timedelta(seconds=1); db.commit()
    assert login(client, "ana", u["mfa_secret"]).status_code == 200

def test_AUTH04_idle_timeout(client, admin):                                  # FR-AUTH-06
    with SessionLocal() as db:
        for s in db.query(S): s.last_seen = utcnow() - timedelta(minutes=16)
        db.commit()
    assert client.get("/api/v1/auth/me", headers=admin["h"]).status_code == 401

def test_AUTH05_logout_invalidates_token(client, admin):                      # SR-04
    assert client.post("/api/v1/auth/logout", headers=admin["h"]).status_code == 200
    assert client.get("/api/v1/auth/me", headers=admin["h"]).status_code == 401

def test_RBAC01_matrix_enforced_server_side(client, admin):                   # FR-AUTH-04, SR-03, AC-02
    toks = {}
    for role, n in (("Security Analyst", "ana"), ("Auditor", "aud"), ("Manager", "man")):
        u = make_user(client, admin, role, n)
        toks[n] = login(client, n, u.get("mfa_secret")).json()["token"]
    assert client.get("/api/v1/users").status_code == 401
    assert client.get("/api/v1/users", headers=H(toks["ana"])).status_code == 403
    assert client.get("/api/v1/users", headers=H(toks["aud"])).status_code == 200
    new = {"username": "zz1", "name": "z", "email": "z@x.pk", "password": PW, "role": "Auditor"}
    for n in toks: assert client.post("/api/v1/users", headers=H(toks[n]), json=new).status_code == 403
    assert client.get("/api/v1/audit", headers=H(toks["ana"])).status_code == 403
    assert client.get("/api/v1/audit", headers=H(toks["man"])).status_code == 200
    for fn in rbac.MATRIX:
        for role in rbac.ROLES:
            assert rbac.allowed(role, fn, "RW") == (rbac.MATRIX[fn].get(role) == "RW")

def test_USR01_crud_and_disable(client, admin):                               # FR-AUTH-01
    u = make_user(client, admin, "Auditor", "aud"); tok = login(client, "aud").json()["token"]
    assert client.patch(f"/api/v1/users/{u['id']}", headers=admin["h"], json={"status": "disabled"}).json()["status"] == "disabled"
    assert client.get("/api/v1/auth/me", headers=H(tok)).status_code == 401
    assert login(client, "aud").status_code == 401
    assert client.delete(f"/api/v1/users/{u['id']}", headers=admin["h"]).status_code == 200
    assert client.delete("/api/v1/users/1", headers=admin["h"]).status_code == 400

def test_PWD01_policy_and_argon2(client, admin):                              # SR-01
    base = {"username": "bad", "name": "b", "email": "b@x.pk", "role": "Auditor"}
    for pw in ("short1", "password1234", "aaaaaaaaaaaaaa"):
        assert client.post("/api/v1/users", headers=admin["h"], json={**base, "password": pw}).status_code == 422
    make_user(client, admin, "Auditor", "aud")
    with SessionLocal() as db: assert db.query(User).filter_by(username="aud").one().password_hash.startswith("$argon2id$")

def test_SQLI01_injection_rejected(client, admin):                            # SR-14, SR-15
    assert client.post("/api/v1/auth/login", json={"username": "' OR '1'='1' --", "password": "x"}).status_code == 401
    assert client.post("/api/v1/users", headers=admin["h"], json={"username": "a;DROP TABLE users", "name": "x",
                       "email": "a@x.pk", "password": PW, "role": "Auditor"}).status_code == 422

def test_SETUP01_only_once(client, admin):                                    # section 7.9
    assert client.post("/api/v1/setup", json={"username": "evil", "name": "e", "email": "e@x.pk", "password": PW}).status_code == 409

def test_AUD01_events_logged(client, admin):                                  # FR-AUTH-08, FR-ADM-04
    login(client, "root", pw="bad-password-123"); client.post("/api/v1/auth/logout", headers=admin["h"])
    with SessionLocal() as db: acts = {e.action for e in db.query(AuditLog)}
    assert {"login.success", "login.failed", "logout", "setup.admin_created"} <= acts

def test_AUD02_append_only_and_tamper_evident(client, admin):                 # SR-12, AC-15
    with SessionLocal() as db:
        db.query(AuditLog).first().action = "x"
        with pytest.raises(PermissionError): db.commit()
    with SessionLocal() as db:
        db.delete(db.query(AuditLog).first())
        with pytest.raises(PermissionError): db.commit()
    with pytest.raises(Exception):
        with engine.begin() as c: c.execute(text("UPDATE audit_log SET action='x'"))
    with pytest.raises(Exception):
        with engine.begin() as c: c.execute(text("DELETE FROM audit_log"))
    assert client.get("/api/v1/audit/verify", headers=admin["h"]).json()["intact"] is True
    with engine.begin() as c:
        dbsetup.drop_audit_guard_for_tests(c); c.execute(text("UPDATE audit_log SET username='mallory' WHERE id=1"))
    assert client.get("/api/v1/audit/verify", headers=admin["h"]).json()["intact"] is False
