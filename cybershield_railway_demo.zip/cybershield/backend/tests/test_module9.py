"""Account recovery for a lost authenticator secret (backend/reset_mfa.py)."""
import pyotp, pytest
from sqlalchemy import select
from app.db import SessionLocal
from app.models import AuditLog
from conftest import PW, login
import reset_mfa

def test_RECOV01_lost_authenticator_secret_can_be_reissued(client, admin):          # FR-AUTH-03 usability, FR-AUTH-05
    old = admin["secret"]; assert login(client, "root", old).status_code == 200
    token = admin["h"]["Authorization"][7:]
    new, uri = reset_mfa.reset("root")
    assert new != old and uri.startswith("otpauth://totp/") and new in uri
    assert login(client, "root", old).status_code == 401                              # the old secret no longer works
    assert login(client, "root", new).status_code == 200                              # the new one does, with the same password
    assert client.get("/api/v1/auth/me", headers={"Authorization": "Bearer " + token}).status_code == 401   # earlier sessions signed out
    with SessionLocal() as db: e = [x for x in db.query(AuditLog) if x.action == "account.recovery_cli"][0]
    assert e.object == "root" and "reissued" in e.new_value and new not in (e.new_value or "") and new not in (e.object or "")   # logged, secret not logged

def test_RECOV02_also_clears_a_lockout(client, admin):
    for _ in range(5): login(client, "root", admin["secret"], pw="wrong-password-123")
    assert login(client, "root", admin["secret"]).status_code == 423
    new, _ = reset_mfa.reset("root"); assert login(client, "root", new).status_code == 200

def test_RECOV03_optional_password_change_follows_the_password_policy(client, admin):
    with pytest.raises(ValueError): reset_mfa.reset("root", "short")                    # rejected, nothing changed
    assert login(client, "root", admin["secret"]).status_code == 200
    new, _ = reset_mfa.reset("root", "A-Brand-New-Passphrase-77")
    assert login(client, "root", new).status_code == 401 and login(client, "root", new, pw="A-Brand-New-Passphrase-77").status_code == 200

def test_RECOV04_unknown_user_changes_nothing(client, admin):
    with pytest.raises(LookupError): reset_mfa.reset("nobody")
    assert login(client, "root", admin["secret"]).status_code == 200
    assert reset_mfa.main(["nobody"]) == 1
