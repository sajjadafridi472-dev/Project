import csv, io
from datetime import timedelta
import pytest
from app import routes_dashboard
from app.config import settings
from app.db import SessionLocal
from app.models import AuditLog, Asset, utcnow
from conftest import login, make_user
from test_module3 import E, fails, scan, run as run3, alerts
from test_module4 import staff, H, make_critical

def recent(n, minutes_ago=10, **kw):
    now = utcnow() - timedelta(minutes=minutes_ago)
    return [{"timestamp": (now + timedelta(seconds=i)).strftime("%Y-%m-%dT%H:%M:%SZ"), "hostname": "web01", "event_type": "auth.success", "severity": 1,
             "user": "bob", "src_ip": "192.0.2.5", "message": f"ok {i}", **kw} for i in range(n)]

def test_DSH01_summary_roles_and_counts(client, admin):                              # FR-DSH-01, FR-DSH-06
    s = staff(client, admin); run3(fails(12) + scan(20, start=100)); make_critical()
    d = client.get("/api/v1/dashboard/summary", headers=s["man"]).json()
    assert d["alerts_open_by_severity"]["Critical"] == 1 and sum(d["alerts_open_by_severity"].values()) == 3 and d["unacknowledged_critical"] == 1
    assert d["events_by_origin"]["simulated"] == d["events_total"] > 0 and d["events_by_origin"]["live"] == 0            # honest origin split
    assert {a["hostname"] for a in d["top_assets"]} >= {"crown", "fw01"} and {x["ip"] for x in d["top_sources"]} == {"203.0.113.5", "198.51.100.7"}
    assert {k: client.get("/api/v1/dashboard/summary", headers=h).json()["landing"] for k, h in (("ana", s["ana"]), ("man", s["man"]), ("aud", s["aud"]), ("root", admin["h"]))} == \
           {"ana": "alerts", "man": "dashboard", "aud": "audit", "root": "admin"}
    assert client.get("/api/v1/dashboard/summary").status_code == 401

def test_DSH02_trends_buckets_and_drilldown(client, admin):                          # FR-DSH-02, FR-DSH-07
    run3(recent(7, 10) + recent(5, 200, message="older"))
    for per, n in (("1h", 12), ("24h", 24), ("7d", 28), ("30d", 30)):
        b = client.get(f"/api/v1/dashboard/trends?period={per}", headers=admin["h"]).json()["buckets"]; assert len(b) == n
    h = client.get("/api/v1/dashboard/trends?period=1h", headers=admin["h"]).json()["buckets"]; assert sum(x["events"] for x in h) == 7
    day = client.get("/api/v1/dashboard/trends?period=24h", headers=admin["h"]).json()["buckets"]; assert sum(x["events"] for x in day) == 12
    hit = [x for x in day if x["events"]][0]                                          # drill down: bucket range -> the same events
    ev = client.get("/api/v1/events", params={"start": hit["start"], "end": hit["end"], "limit": 500}, headers=admin["h"]).json()
    assert len(ev) == hit["events"]
    assert client.get("/api/v1/dashboard/trends?period=2y", headers=admin["h"]).status_code == 422

def test_DSH03_event_filters_and_literal_search(client, admin):                      # FR-DSH-03, SR-15
    run3(recent(5, 10) + recent(3, 20, hostname="db01", user="alice", src_ip="192.0.2.9", severity=6, message="50% done_ok 'quote'", event_type="auth.failure"))
    g = lambda **p: client.get("/api/v1/events", params=p, headers=admin["h"]).json()
    assert len(g(hostname="db01")) == 3 and len(g(user="bob")) == 5 and len(g(src_ip="192.0.2.9")) == 3 and len(g(severity_min=5)) == 3
    assert len(g(event_type="auth.failure", hostname="db01")) == 3 and len(g(hostname="db01", user="bob")) == 0
    assert len(g(q="50%")) == 3 and len(g(q="%")) == 3 and len(g(q="_")) == 3 and len(g(q="'")) == 3 and len(g(q="zzz")) == 0   # % _ ' are literals, no injection
    assert len(g(q="x' OR '1'='1")) == 0
    assert len(g(start=(utcnow() - timedelta(minutes=15)).isoformat())) == 5 and len(g(limit=2)) == 2
    assert client.get("/api/v1/events?start=notadate", headers=admin["h"]).status_code == 422

def test_DSH04_csv_export_neutralises_formulas(client, admin):                      # FR-RPT-02 (CSV), OWASP CSV injection
    run3(recent(1, 5, message="=HYPERLINK(\"http://evil\")") + recent(1, 6, message="+1+1") + recent(1, 7, message="@SUM(A1)") + recent(1, 8, message="normal"))
    r = client.get("/api/v1/events?format=csv", headers=admin["h"]); assert r.headers["content-type"].startswith("text/csv") and "attachment" in r.headers["content-disposition"]
    rows = list(csv.DictReader(io.StringIO(r.text))); msgs = {x["message"] for x in rows}
    assert len(rows) == 4 and "normal" in msgs and all(m.startswith("'") for m in msgs - {"normal"})

def test_AST01_asset_inventory_crud_risk_and_rbac(client, admin):                    # FR-DSH-05, SR-13
    s = staff(client, admin); new = {"hostname": "web01", "ip_address": "10.0.0.5", "os": "Ubuntu", "owner": "IT", "criticality": 5}
    assert client.post("/api/v1/assets", headers=s["ana"], json=new).status_code == 403 and client.post("/api/v1/assets", headers=s["man"], json=new).status_code == 403
    r = client.post("/api/v1/assets", headers=admin["h"], json=new); assert r.status_code == 201 and r.json()["risk_score"] == 0
    assert client.post("/api/v1/assets", headers=admin["h"], json=new).status_code == 409
    for bad in ({**new, "hostname": "a b"}, {**new, "hostname": "x", "ip_address": "999.1.1.1"}, {**new, "hostname": "y", "criticality": 9}): assert client.post("/api/v1/assets", headers=admin["h"], json=bad).status_code == 422
    client.post("/api/v1/assets", headers=admin["h"], json={"hostname": "quiet", "criticality": 1})
    run3(fails(12))                                                                  # one open alert on web01 (its score already includes criticality)
    a = {x["hostname"]: x for x in client.get("/api/v1/assets", headers=s["aud"]).json()}
    assert a["web01"]["open_alerts"] == 1 and a["web01"]["risk_score"] == alerts()[0][3] and a["quiet"]["risk_score"] == 0
    assert client.get("/api/v1/assets", headers=s["aud"]).json()[0]["hostname"] == "web01"                               # sorted by risk
    e = client.put(f"/api/v1/assets/{r.json()['id']}", headers=admin["h"], json={**new, "criticality": 1}).json(); assert e["risk_score"] == alerts()[0][3]   # no double counting
    assert client.delete(f"/api/v1/assets/{r.json()['id']}", headers=admin["h"]).status_code == 200 and client.delete("/api/v1/assets/999", headers=admin["h"]).status_code == 404
    with SessionLocal() as db: assert {"asset.create", "asset.update", "asset.delete"} <= {x.action for x in db.query(AuditLog)}

def test_GEO01_unconfigured_is_honest_and_configured_works(client, admin, monkeypatch, tmp_path):   # FR-DSH-04 (Could)
    run3(fails(12) + scan(20, start=100))
    d = client.get("/api/v1/dashboard/geo", headers=admin["h"]).json(); assert d["available"] is False and d["sources"] == []
    f = tmp_path / "geo.csv"; f.write_text("cidr,country,lat,lon\n203.0.113.0/24,Testland,10.5,20.5\nbroken line\n198.51.100.0/24,Otherland,1,2\n")
    monkeypatch.setattr(routes_dashboard, "settings", type("S", (), {"geoip_csv": str(f)})())
    d = client.get("/api/v1/dashboard/geo", headers=admin["h"]).json(); assert d["available"] and {x["country"] for x in d["sources"]} == {"Testland", "Otherland"}

def test_SEC01_security_headers(client, admin):                                       # SR-14
    h = client.get("/api/v1/auth/me", headers=admin["h"]).headers
    assert h["x-content-type-options"] == "nosniff" and h["x-frame-options"] == "DENY" and "default-src 'self'" in h["content-security-policy"] and "frame-ancestors 'none'" in h["content-security-policy"]
    assert "content-security-policy" not in client.get("/docs").headers                # Swagger needs its CDN assets

def test_UI01_built_ui_is_served_and_api_routes_still_win(client):
    from pathlib import Path
    if not (Path(__file__).resolve().parents[2] / "frontend" / "dist" / "index.html").exists(): pytest.skip("UI not built (cd frontend && npm install && npm run build)")
    r = client.get("/"); assert r.status_code == 200 and "CyberShield" in r.text and "default-src 'self'" in r.headers["content-security-policy"]
    assert client.get("/api/v1/auth/me").status_code == 401 and client.get("/api/v1/dashboard/summary").status_code == 401   # API not shadowed by the static mount


def test_PERF01_shared_cache_serves_repeat_calls_without_requerying(client, admin, monkeypatch):   # NFR-PERF-03/04
    from app import routes_dashboard as rd
    run3(recent(5, event_type="proc.start")); monkeypatch.setattr(rd, "settings", type("S", (), {"dashboard_cache_seconds": 30, "geoip_csv": ""})()); rd.cache_clear()
    a = client.get("/api/v1/dashboard/summary", headers=admin["h"]).json()["events_total"]; run3(recent(3, 12, event_type="proc.start", src_ip="192.0.2.8", message="later"))
    assert client.get("/api/v1/dashboard/summary", headers=admin["h"]).json()["events_total"] == a == 5                 # served from cache within the TTL
    rd.cache_clear(); assert client.get("/api/v1/dashboard/summary", headers=admin["h"]).json()["events_total"] == 8    # fresh after expiry
