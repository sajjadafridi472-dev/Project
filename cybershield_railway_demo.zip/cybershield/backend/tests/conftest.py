import os, tempfile, pytest, pyotp
os.environ.setdefault("DATABASE_URL", f"sqlite:///{tempfile.mkdtemp()}/t.db")  # set DATABASE_URL=postgresql+psycopg://... to run the suite on PostgreSQL
os.environ["RATE_LIMIT_PER_MIN"] = "100000"
os.environ["INGEST_WORKER"] = "0"
os.environ["DASHBOARD_CACHE_SECONDS"] = "0"  # caching is covered by its own test
from fastapi.testclient import TestClient
from app.main import app
from app.db import Base, engine
PW = "Correct-Horse-Battery-9"

@pytest.fixture()
def client():
    from app import routes_dashboard; routes_dashboard.cache_clear()
    Base.metadata.drop_all(engine)
    with TestClient(app) as c: yield c

def login(c, user, secret=None, pw=PW):
    body = {"username": user, "password": pw}
    if secret: body["otp"] = pyotp.TOTP(secret).now()
    return c.post("/api/v1/auth/login", json=body)

@pytest.fixture()
def admin(client):
    r = client.post("/api/v1/setup", json={"username": "root", "name": "Root", "email": "r@x.pk", "password": PW}).json()
    tok = login(client, "root", r["mfa_secret"]).json()["token"]
    return {"h": {"Authorization": f"Bearer {tok}"}, "secret": r["mfa_secret"]}

def make_user(c, admin, role, name):
    r = c.post("/api/v1/users", headers=admin["h"], json={"username": name, "name": name, "email": f"{name}@x.pk",
                                                         "password": PW, "role": role})
    assert r.status_code == 201, r.text
    return r.json()
