import dataclasses, http.server, json, signal, socket, threading, time
from datetime import timedelta
import pytest
from sqlalchemy import select
from app import detect, ingest, notify
from app.db import SessionLocal
from app.hub import hub
from app.models import Alert, Asset, AuditLog, IOC, Notification, PasswordReset, User, utcnow
from conftest import PW, login, make_user
from test_module3 import E, fails, run as run3, alerts

def run(items):
    with SessionLocal() as db:
        ingest.enqueue(db, items, "json", None, "agent", "simulated"); db.commit()
        while ingest.process_queue(db): pass
        while detect.process_new(db, on_alerts=hub.publish_alerts): pass

def H(tok): return {"Authorization": f"Bearer {tok}"}
def staff(client, admin):
    a = make_user(client, admin, "Security Analyst", "ana"); b = make_user(client, admin, "Security Analyst", "bea")
    m = make_user(client, admin, "Manager", "man"); u = make_user(client, admin, "Auditor", "aud")
    t = lambda n, s=None: H(login(client, n, s).json()["token"]) if not s else H(login(client, n, s).json()["token"])
    return {"ana": H(login(client, "ana", a["mfa_secret"]).json()["token"]), "bea": H(login(client, "bea", b["mfa_secret"]).json()["token"]),
            "man": H(login(client, "man").json()["token"]), "aud": H(login(client, "aud").json()["token"])}

def make_critical():
    with SessionLocal() as db:
        db.add(Asset(hostname="crown", criticality=5, owner="CFO")); db.add(IOC(type="hash", value="b" * 64, source="t", confidence=90)); db.commit()
    run([E(1, "priv.sudo", hostname="crown", user="mallory", message="sudo: COMMAND=/bin/bash"),
         E(2, "proc.start", hostname="crown", user="mallory", message="exec " + "b" * 64)])

def outbox(**f):
    with SessionLocal() as db: return [(n.channel, n.recipient, n.subject, n.status, n.attempts) for n in db.scalars(select(Notification).order_by(Notification.id))]

def test_TRI01_triage_workflow_rbac_and_duplicate_work(client, admin):             # UC-04, elicitation FR-06
    s = staff(client, admin); run(fails(12)); aid = alerts()[0][0]; url = f"/api/v1/alerts/{aid}"
    for who in ("aud", "man"): assert client.patch(url, headers=s[who], json={"status": "Resolved"}).status_code == 403
    assert client.patch(url, headers=admin["h"], json={"status": "Resolved"}).status_code == 403           # Admin cannot triage (SRS 7.8)
    assert client.patch(url, headers=s["ana"], json={"status": "Bogus"}).status_code == 422 and client.patch(url, headers=s["ana"], json={}).status_code == 422
    r = client.patch(url, headers=s["ana"], json={"status": "Investigating", "note": "checking auth logs"}).json()
    assert r["status"] == "Investigating" and r["acknowledged_at"] and r["notes"][0]["user"] == "ana"
    c = client.patch(url, headers=s["bea"], json={"status": "Resolved"}); assert c.status_code == 409 and "ana" in c.json()["detail"]
    assert client.patch(url, headers=s["ana"], json={"status": "False Positive"}).json()["status"] == "False Positive"
    assert client.patch(url, headers=s["bea"], json={"status": "Open"}).status_code == 200               # terminal states can be reopened
    with SessionLocal() as db: acts = [e.action for e in db.query(AuditLog)]
    assert acts.count("alert.status") == 3 and "alert.note" in acts
    assert client.patch("/api/v1/alerts/9999", headers=s["ana"], json={"status": "Resolved"}).status_code == 404

def test_NOT01_email_for_high_and_critical_only_once_per_level(client, admin):      # FR-ALR-03, FR-ALR-06
    staff(client, admin); run(fails(12))                                              # Medium brute force: no email
    assert [o for o in outbox() if o[0] == "email" and "alert" in o[2]] == []
    run([E(1, "priv.sudo", user="mallory", message="COMMAND=/bin/bash")])           # High
    mails = [o for o in outbox() if "High alert" in o[2]]
    assert {o[1] for o in mails} == {"r@x.pk", "ana@x.pk", "bea@x.pk", "man@x.pk"} and "aud@x.pk" not in {o[1] for o in mails}
    run([E(5, "priv.sudo", user="mallory", message="COMMAND=/bin/sh")]); assert len([o for o in outbox() if "High alert" in o[2]]) == len(mails)   # no duplicates

def test_NOT02_user_threshold_and_critical_webhook(client, admin, monkeypatch):    # FR-ALR-04, FR-ALR-06
    s = staff(client, admin)
    assert client.patch("/api/v1/auth/me/notifications", headers=s["ana"], json={"notify_email": True, "min_severity": "Low"}).status_code == 422
    client.patch("/api/v1/auth/me/notifications", headers=s["ana"], json={"notify_email": True, "min_severity": "Critical"})
    client.patch("/api/v1/auth/me/notifications", headers=s["bea"], json={"notify_email": False, "min_severity": "High"})
    monkeypatch.setattr(notify, "settings", dataclasses.replace(notify.settings, webhook_url="http://127.0.0.1:9/hook"))
    run([E(1, "priv.sudo", user="mallory", message="COMMAND=/bin/bash")])
    r = {o[1] for o in outbox() if o[0] == "email"}; assert "ana@x.pk" not in r and "bea@x.pk" not in r and "man@x.pk" in r
    assert [o for o in outbox() if o[0] == "webhook"] == []                          # High: webhook is for Critical
    make_critical(); w = [o for o in outbox() if o[0] == "webhook"]; assert len(w) == 1 and "Critical" in w[0][2]
    assert "ana@x.pk" in {o[1] for o in outbox() if "Critical alert" in o[2]}

class FakeSMTP(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True); self.srv = socket.socket(); self.srv.bind(("127.0.0.1", 0)); self.srv.listen(5); self.msgs = []; self.start()
    @property
    def port(self): return self.srv.getsockname()[1]
    def run(self):
        while True:
            try: c, _ = self.srv.accept()
            except OSError: return
            f = c.makefile("rb"); c.sendall(b"220 fake\r\n"); data = []
            while (line := f.readline()):
                cmd = line[:4].upper()
                if cmd == b"DATA":
                    c.sendall(b"354 go\r\n")
                    while (l := f.readline()) != b".\r\n": data.append(l)
                    self.msgs.append(b"".join(data).decode()); c.sendall(b"250 queued\r\n")
                elif cmd == b"QUIT": c.sendall(b"221 bye\r\n"); break
                else: c.sendall(b"250 ok\r\n")
            c.close()

def test_NOT03_real_smtp_and_webhook_delivery_within_60s(client, admin, monkeypatch):   # AC-10 (functional path only)
    staff(client, admin); smtp = FakeSMTP(); got = []
    class Hh(http.server.BaseHTTPRequestHandler):
        def do_POST(self): got.append(json.loads(self.rfile.read(int(self.headers["Content-Length"])))); self.send_response(200); self.end_headers()
        def log_message(self, *a): pass
    web = http.server.HTTPServer(("127.0.0.1", 0), Hh); threading.Thread(target=web.serve_forever, daemon=True).start()
    monkeypatch.setattr(notify, "settings", dataclasses.replace(notify.settings, smtp_host="127.0.0.1", smtp_port=smtp.port, smtp_starttls=0,
                        webhook_url=f"http://127.0.0.1:{web.server_port}/h"))
    t0 = time.time(); make_critical()
    with SessionLocal() as db: sent = notify.deliver_pending(db)
    assert time.time() - t0 < 60 and sent >= 5
    assert all(o[3] == "sent" for o in outbox()) and len(smtp.msgs) >= 4 and any("Subject: [CyberShield] Critical alert" in m for m in smtp.msgs)
    assert got and got[0]["severity"] == "Critical" and "message" not in got[0]      # metadata only, no raw logs
    web.shutdown()

def test_NOT04_retry_backoff_then_failed_and_unconfigured(client, admin, monkeypatch):    # SRS 8.2 retry queue
    run([E(1, "priv.sudo", user="m", message="COMMAND=/bin/bash")])
    with SessionLocal() as db: notify.deliver_pending(db)
    assert {o[3] for o in outbox()} == {"unconfigured"}                              # honest status when SMTP is not set up
    with SessionLocal() as db:
        for n in db.query(Notification): n.status = "pending"
        db.commit()
    s = socket.socket(); s.bind(("127.0.0.1", 0)); dead = s.getsockname()[1]; s.close()
    monkeypatch.setattr(notify, "settings", dataclasses.replace(notify.settings, smtp_host="127.0.0.1", smtp_port=dead, smtp_starttls=0))
    now = utcnow()
    for i in range(5):
        with SessionLocal() as db: notify.deliver_pending(db, now=now + timedelta(hours=i + 1))
    o = outbox(); assert {x[3] for x in o} == {"failed"} and {x[4] for x in o} == {5}

def test_ESC01_unacknowledged_critical_escalates_once(client, admin):            # FR-ALR-07
    s = staff(client, admin); make_critical(); a = alerts()[0]; assert a[2] == "Critical"
    with SessionLocal() as db: assert notify.escalate(db) == 0                      # too early
    with SessionLocal() as db: db.get(Alert, a[0]).created_at = utcnow() - timedelta(minutes=16); db.commit()
    with SessionLocal() as db: assert notify.escalate(db) == 1 and notify.escalate(db) == 0
    assert [o for o in outbox() if "ESCALATED" in o[2]][0][1] == "man@x.pk"
    with SessionLocal() as db: assert "alert.escalated" in {e.action for e in db.query(AuditLog)}
    client.patch(f"/api/v1/alerts/{a[0]}", headers=s["ana"], json={"status": "Investigating"})     # acknowledged alerts do not escalate
    with SessionLocal() as db:
        x = db.get(Alert, a[0]); x.escalated = False; x.status = "Open"; db.commit(); assert notify.escalate(db) == 0

def test_WS01_live_push_and_ws_auth(client, admin):                                # FR-ALR-02, SR-03
    signal.signal(signal.SIGALRM, lambda *a: (_ for _ in ()).throw(TimeoutError("ws hang"))); signal.alarm(20)
    try:
        with client.websocket_connect("/api/v1/ws") as ws:
            ws.send_json({"token": "not-a-token"})
            with pytest.raises(Exception): ws.receive_json()
        with client.websocket_connect("/api/v1/ws") as ws:
            ws.send_json({"token": admin["h"]["Authorization"][7:]}); assert ws.receive_json() == {"type": "hello"}
            run(fails(12)); m = ws.receive_json()
            assert m["type"] == "alert" and m["alert"]["severity"] in ("Medium", "High") and m["alert"]["entity"] == "src_ip:203.0.113.5"
    finally: signal.alarm(0)

def test_POLL01_polling_fallback(client, admin):                                   # SRS 5.4 fallback
    run(fails(12)); t = (utcnow() - timedelta(seconds=1)).isoformat()
    assert len(client.get(f"/api/v1/alerts?updated_after={t}", headers=admin["h"]).json()) == 1
    assert client.get(f"/api/v1/alerts?updated_after={(utcnow() + timedelta(hours=1)).isoformat()}", headers=admin["h"]).json() == []
    assert client.get("/api/v1/alerts?updated_after=junk", headers=admin["h"]).status_code == 422

def test_RST01_password_reset_by_time_limited_link(client, admin, monkeypatch):    # FR-AUTH-07
    u = make_user(client, admin, "Auditor", "aud"); old = login(client, "aud").json()["token"]
    for email in ("aud@x.pk", "nobody@x.pk"):
        r = client.post("/api/v1/auth/password-reset/request", json={"email": email}); assert r.status_code == 202
    with SessionLocal() as db: assert db.query(Notification).filter(Notification.subject.contains("Password reset")).count() == 1
    mails = [o for o in outbox() if "Password reset" in o[2]]; assert [m[1] for m in mails] == ["aud@x.pk"]     # no enumeration
    with SessionLocal() as db: body = db.query(Notification).filter(Notification.subject.contains("Password reset")).one().body
    tok = body.split("token=")[1].split()[0]; NEW = "Another-Strong-Pass-77"
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": tok, "new_password": "weak"}).status_code == 422
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": tok, "new_password": NEW}).status_code == 200
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": tok, "new_password": NEW}).status_code == 400   # single use
    assert login(client, "aud", pw=NEW).status_code == 200 and login(client, "aud").status_code == 401
    assert client.get("/api/v1/auth/me", headers=H(old)).status_code == 401                                              # old sessions revoked
    client.post("/api/v1/auth/password-reset/request", json={"email": "aud@x.pk"})
    with SessionLocal() as db:
        body = db.query(Notification).filter(Notification.subject.contains("Password reset"), Notification.status == "pending").order_by(Notification.id.desc()).first().body
        r = db.query(PasswordReset).filter_by(used=False).one(); r.expires_at = utcnow() - timedelta(seconds=1); db.commit()
    tok2 = body.split("token=")[1].split()[0]                                                                           # a real token, but expired
    assert client.post("/api/v1/auth/password-reset/confirm", json={"token": tok2, "new_password": NEW}).status_code == 400
    with SessionLocal() as db: assert "password.reset_done" in {e.action for e in db.query(AuditLog)}

def test_LOCK01_admin_notified_on_lockout_and_body_redaction(client, admin):      # FR-AUTH-05
    u = make_user(client, admin, "Security Analyst", "ana")
    for _ in range(5): login(client, "ana", u["mfa_secret"], pw="bad-password-123")
    assert [o[1] for o in outbox() if "Account locked" in o[2]] == ["r@x.pk"]
    assert client.get("/api/v1/notifications", headers=admin["h"]).status_code == 200
    assert "body" not in client.get("/api/v1/notifications", headers=admin["h"]).json()[0]
