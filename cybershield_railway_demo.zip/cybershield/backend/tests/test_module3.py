import json
from datetime import datetime, timedelta
import pytest
from sqlalchemy import select
from app import detect, ingest
from app.db import SessionLocal
from app.models import Alert, Asset, Rule, AuditLog, IngestMetric, utcnow
from conftest import login, make_user

T0 = datetime(2026, 10, 19, 9, 0, 0)
def iso(sec): return (T0 + timedelta(seconds=sec)).strftime("%Y-%m-%dT%H:%M:%SZ")
def E(sec, et, **kw):
    d = {"timestamp": iso(sec), "hostname": "web01", "event_type": et, "severity": 3, "message": f"{et} at {sec}"}; d.update(kw); return d

def run(items, fmt="json"):
    with SessionLocal() as db:
        ingest.enqueue(db, items, fmt, None, "agent", "simulated"); db.commit()
        while ingest.process_queue(db): pass
        while detect.process_new(db): pass

def alerts():
    with SessionLocal() as db:
        return [(a.id, a.entity, a.severity, a.risk_score, a.occurrence_count, json.loads(a.explanation), a.rule_version) for a in db.scalars(select(Alert).order_by(Alert.id))]

def fails(n, ip="203.0.113.5", start=0, gap=10): return [E(start + i * gap, "auth.failure", src_ip=ip, user="root", message=f"Failed password {i}") for i in range(n)]
def scan(n, ip="198.51.100.7", start=0): return [E(start + i, "net.fw", hostname="fw01", src_ip=ip, dst_ip="10.0.0.5", message=f"SRC={ip} DST=10.0.0.5 DPT={1000+i}") for i in range(n)]

def test_DET01_default_rule_library_seeded(client):                                  # FR-DET-01
    with SessionLocal() as db: assert db.query(Rule).count() == 6

def test_DET02_brute_force_threshold(client):                                        # FR-DET-02: more than 10 in 5 min
    run(fails(10)); assert alerts() == []
    run(fails(1, start=100)); a = alerts(); assert len(a) == 1 and a[0][1] == "src_ip:203.0.113.5"
    run(fails(11, ip="203.0.113.6", start=0, gap=40)); assert len(alerts()) == 1     # 11 events over 400s: never >10 in 300s

def test_DET03_port_scan(client):                                                    # FR-DET-03
    run(scan(15)); assert alerts() == []
    run(scan(16, ip="198.51.100.8")); a = alerts(); assert len(a) == 1 and "distinct dst_port" in a[0][5]["rules"][0]["summary"]

def test_DET04_ioc_ip_domain_hash_and_expiry(client, admin):                         # FR-DET-04, FR-ADM-05 (CSV)
    h = "a" * 64
    csvt = f"type,value,source,confidence,expires_at\nip,203.0.113.99,feed,90,\ndomain,Evil.example.org,feed,80,\nhash,{h},feed,70,\nip,198.51.100.200,old,50,2020-01-01T00:00:00Z\nbogus,x,y\nip,999.9.9.9,y,1,"
    r = client.post("/api/v1/iocs/import", headers=admin["h"], json={"csv": csvt}).json(); assert r == {"imported": 4, "rejected": 2}
    run([E(1, "net.fw", src_ip="10.1.1.1", dst_ip="203.0.113.99", message="conn"),
         E(2, "proc.start", user="u2", message=f"started file hash {h}"),
         E(3, "dns.query", src_ip="10.1.1.3", message="query for evil.example.org"),
         E(4, "net.fw", src_ip="10.1.1.4", dst_ip="198.51.100.200", message="expired indicator"),
         E(5, "net.fw", src_ip="10.1.1.5", dst_ip="8.8.8.8", message="benign")])
    ents = {a[1] for a in alerts()}; assert ents == {"src_ip:10.1.1.1", "username:u2", "src_ip:10.1.1.3"}
    d = client.get(f"/api/v1/alerts/{alerts()[0][0]}", headers=admin["h"]).json(); assert d["enrichment"]["ioc_matches"] == ["203.0.113.99"]

def test_DET05_privilege_escalation(client):                                         # FR-DET-05
    run([E(1, "priv.sudo", user="mallory", message="sudo: mallory : COMMAND=/bin/bash"),
         E(2, "priv.sudo", user="alice", message="sudo: alice : COMMAND=/usr/bin/apt update")])
    assert [a[1] for a in alerts()] == ["username:mallory"]

def test_DET06_anomalous_login_is_explainable(client):                               # FR-DET-06, section 8.1
    base = [E(i * 3600 * 24 + 10 * 3600 + (i % 3) * 600, "auth.success", user="bob", src_ip="192.0.2.5") for i in range(25)]
    run(base); assert alerts() == []
    run([E(26 * 3600 * 24 + 3 * 3600, "auth.success", user="bob", src_ip="192.0.2.5")]); a = alerts()
    assert len(a) == 1 and a[0][1] == "username:bob" and "0 of 25 earlier logins" in a[0][5]["rules"][0]["summary"]
    run([E(5, "auth.success", user="newbie", src_ip="192.0.2.6")]); assert len(alerts()) == 1   # too little baseline: no alert

def test_DET07_correlation_across_sources_and_dedup(client):                         # FR-DET-07, FR-ALR-05, AC-08
    run(scan(20, start=0) + fails(14, ip="198.51.100.7", start=30, gap=5))           # firewall scan then endpoint brute force
    a = alerts(); assert len(a) == 1 and len(a[0][5]["rules"]) == 2 and a[0][4] > 1
    assert a[0][3] > 35 and a[0][2] in ("Medium", "High") and a[0][5]["score_components"]
    with SessionLocal() as db:
        raw = db.get(IngestMetric, "raw_findings").value; assert raw > len(a)           # raw hits reduced to one alert

def test_DET08_score_range_severity_and_asset_criticality(client):                   # FR-DET-08, FR-ALR-08
    with SessionLocal() as db: db.add(Asset(hostname="crown-jewel", criticality=5, owner="CFO")); db.commit()
    run([E(1, "priv.sudo", user="a1", hostname="crown-jewel", message="COMMAND=/bin/bash"), E(2, "priv.sudo", user="a2", hostname="web01", message="COMMAND=/bin/bash")])
    s = {a[1]: a[3] for a in alerts()}; assert s["username:a1"] > s["username:a2"]
    assert all(0 <= a[3] <= 100 and a[2] in ("Low", "Medium", "High", "Critical") for a in alerts())
    with SessionLocal() as db: assert detect.sev_of(24) == "Low" and detect.sev_of(75) == "Critical" and detect.risk_score([{"severity": "Critical"}] * 5, 5, True, 9999)[0] <= 100

def test_DET09_rule_crud_versions_test_toggle_rbac(client, admin):                   # FR-DET-09, SR-13, NFR-MNT-03
    an = make_user(client, admin, "Security Analyst", "ana"); H = {"Authorization": "Bearer " + login(client, "ana", an["mfa_secret"]).json()["token"]}
    man = make_user(client, admin, "Manager", "man"); HM = {"Authorization": "Bearer " + login(client, "man").json()["token"]}
    logic = {"type": "threshold", "match": {"event_type": "auth.failure"}, "group_by": "username", "more_than": 3, "window_seconds": 60}
    r = client.post("/api/v1/rules", headers=H, json={"name": "Custom 3 fails", "severity": "High", "logic": logic}); assert r.status_code == 201; rid = r.json()["id"]
    assert client.post("/api/v1/rules", headers=admin["h"], json={"name": "Nope rule", "severity": "Low", "logic": logic}).status_code == 403   # Admin read-only
    assert client.get("/api/v1/rules", headers=admin["h"]).status_code == 200 and client.get("/api/v1/rules", headers=HM).status_code == 403
    for bad in ({"type": "exec", "cmd": "rm"}, {**logic, "group_by": "password"}, {**logic, "match": {"message": {"regex": ".*"}}}, {**logic, "more_than": 0}):
        assert client.post("/api/v1/rules", headers=H, json={"name": "Bad rule", "severity": "Low", "logic": bad}).status_code == 422
    sample = [E(i, "auth.failure", user="zed") for i in range(5)]
    t = client.post("/api/v1/rules/test", headers=H, json={"logic": logic, "events": sample}).json(); assert len(t["findings"]) == 2   # events 4 and 5
    with SessionLocal() as db: assert db.query(Alert).count() == 0                   # tester stores nothing
    run([E(i, "auth.failure", user="zed") for i in range(5)]); assert [a[5]["rules"][0]["version"] for a in alerts()] == [1]
    v2 = client.put(f"/api/v1/rules/{rid}", headers=H, json={"name": "Custom 3 fails", "severity": "High", "logic": {**logic, "more_than": 100}}).json(); assert v2["version"] == 2
    assert [h["version"] for h in client.get(f"/api/v1/rules/{rid}", headers=H).json()["history"]] == [1, 2]
    client.patch(f"/api/v1/rules/{rid}", headers=H, json={"enabled": False})
    run([E(500 + i, "auth.failure", user="other") for i in range(6)]); assert len(alerts()) == 1
    with SessionLocal() as db: acts = [(e.action, e.old_value) for e in db.query(AuditLog) if e.action.startswith("rule.")]
    assert [a for a, _ in acts] == ["rule.create", "rule.update", "rule.disable"] and "more_than" in acts[1][1]

def test_DET10_suppression_expires_and_is_audited(client, admin):                    # FR-DET-10
    an = make_user(client, admin, "Security Analyst", "ana"); H = {"Authorization": "Bearer " + login(client, "ana", an["mfa_secret"]).json()["token"]}
    assert client.post("/api/v1/suppressions", headers=H, json={"reason": "all", "expires_in_days": 1}).status_code == 422       # no blanket suppress
    assert client.post("/api/v1/suppressions", headers=H, json={"src_ip": "203.0.113.5", "reason": "x", "expires_in_days": 365}).status_code == 422
    s = client.post("/api/v1/suppressions", headers=H, json={"src_ip": "203.0.113.5", "reason": "authorised pentest", "expires_in_days": 7}); assert s.status_code == 201
    run(fails(12)); assert alerts() == []
    with SessionLocal() as db: assert db.get(IngestMetric, "suppressed").value >= 1
    from app.models import Suppression
    with SessionLocal() as db: db.get(Suppression, s.json()["id"]).expires_at = utcnow() - timedelta(seconds=1); db.commit()
    run(fails(12, start=5000)); assert len(alerts()) == 1                            # expired suppression no longer hides it
    with SessionLocal() as db: assert "suppression.create" in {e.action for e in db.query(AuditLog)}

def test_DET11_alert_api_all_roles_read_and_references_rule_version(client, admin):  # sec 7.8 row 1, section 6.6
    run(fails(12)); au = make_user(client, admin, "Auditor", "aud"); HA = {"Authorization": "Bearer " + login(client, "aud").json()["token"]}
    lst = client.get("/api/v1/alerts", headers=HA).json(); assert len(lst) == 1 and lst[0]["rules"] == ["Brute-force login attempts"]
    d = client.get(f"/api/v1/alerts/{lst[0]['id']}", headers=HA).json(); assert d["events"] and d["trigger_latency_ms"] is not None and d["explanation"]["rules"][0]["version"] == 1
    assert client.get("/api/v1/alerts").status_code == 401
