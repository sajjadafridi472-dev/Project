"""Event-receipt -> alert-created latency under a live pipeline (NFR-PERF-02, AC-06). Run: python latency_test.py
Scope: single machine, SQLite, ~200 events/s offered load, HTTP in-process via TestClient. NOT the SRS reference deployment
and NOT the 5,000 events/s load, so it does not verify NFR-PERF-01/02 at spec load."""
import os, tempfile, time, statistics
os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/lat.db"; os.environ["INGEST_WORKER"] = "1"; os.environ["RATE_LIMIT_PER_MIN"] = "100000"
os.environ["INGEST_RATE_PER_MIN"] = "100000"
import pyotp
from fastapi.testclient import TestClient
from sqlalchemy import select
from app.main import app
from app.db import SessionLocal
from app.models import Alert, Event

ATTACKERS, PER, BATCH_ATTACKERS, GAP = 500, 11, 10, 0.5
with TestClient(app) as c:
    pw = "Correct-Horse-Battery-9"
    s = c.post("/api/v1/setup", json={"username": "root", "name": "R", "email": "r@x.pk", "password": pw}).json()
    tok = c.post("/api/v1/auth/login", json={"username": "root", "password": pw, "otp": pyotp.TOTP(s["mfa_secret"]).now()}).json()["token"]
    src = c.post("/api/v1/sources", headers={"Authorization": f"Bearer {tok}"}, json={"name": "lat-src", "source_type": "api"}).json()["token"]
    t0 = time.time(); sent = 0
    for b in range(ATTACKERS // BATCH_ATTACKERS):
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        items = [{"timestamp": ts, "hostname": "web01", "event_type": "auth.failure", "severity": 3, "user": "root",
                  "src_ip": f"198.51.{(b * BATCH_ATTACKERS + a) // 250}.{(b * BATCH_ATTACKERS + a) % 250 + 1}", "message": f"Failed password {k}"}
                 for k in range(PER) for a in range(BATCH_ATTACKERS)]
        assert c.post("/api/v1/events", headers={"X-Source-Token": src}, json=items).status_code == 202; sent += len(items); time.sleep(GAP)
    offered = sent / (time.time() - t0)
    deadline = time.time() + 120
    while time.time() < deadline:
        with SessionLocal() as db:
            n = db.query(Alert).count(); pend = db.query(Event).filter(Event.detected == False).count()  # noqa: E712
        if n >= ATTACKERS and pend == 0: break
        time.sleep(1)
    with SessionLocal() as db: lat = sorted(a.trigger_latency_ms for a in db.scalars(select(Alert)) if a.trigger_latency_ms is not None); n = len(lat)
pct = lambda p: lat[min(n - 1, int(p / 100 * n))] / 1000
rep = f"""# Alert latency measurement (NFR-PERF-02 / AC-06)

Scope: one machine, SQLite, live worker, events posted over HTTP. Offered load about {offered:.0f} events/s ({sent} events, {ATTACKERS} attackers).
This is NOT the SRS reference deployment and NOT the 5,000 events/s load, so it does not verify NFR-PERF-02 at specification load.
It measures receipt of the triggering event to alert creation; the WebSocket push adds a local in-process hop that was not timed separately.

| Metric | Value |
|---|---|
| Alerts created / expected | {n} / {ATTACKERS} |
| p50 | {pct(50):.2f} s |
| p95 | {pct(95):.2f} s (target <= 10 s) |
| p99 | {pct(99):.2f} s |
| max | {lat[-1]/1000:.2f} s |
| Result at this load | {'p95 within target' if n >= ATTACKERS and pct(95) <= 10 else 'TARGET NOT MET or alerts missing'} |
"""
open("../docs/latency_report.md", "w").write(rep); print(rep)
