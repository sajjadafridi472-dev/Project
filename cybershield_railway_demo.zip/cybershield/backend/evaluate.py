"""Labelled-scenario evaluation of the rule engine (SRS 9.3, AC-07/08/09). Run: python evaluate.py
HONESTY NOTE: scenarios are synthetic and written by the same people who wrote the rules, including known evasive
variants and hard benign cases. Results describe THIS scenario mix only; they do not predict real-world performance."""
import json, math, os, random, tempfile
from datetime import datetime, timedelta
os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/eval.db"; os.environ["INGEST_WORKER"] = "0"
from sqlalchemy import select
from app.main import init_db
from app import detect, ingest
from app.db import SessionLocal
from app.models import Alert, IngestMetric

rng = random.Random(42); T0 = datetime(2026, 10, 5); DAY = 86400; items, trials = [], []
def ts(s): return (T0 + timedelta(seconds=s)).strftime("%Y-%m-%dT%H:%M:%SZ")
def add(s, et, host="web01", **kw): items.append({"timestamp": ts(s), "hostname": host, "event_type": et, "severity": 3, "message": kw.pop("message", et), **kw})
def trial(cls, entity, expect): trials.append({"cls": cls, "entity": entity, "expect": expect})

# ---- benign week: 20 users x 3 logins/day, typos, normal web, normal sudo, isolated firewall drops ----
for u in range(20):
    for d in range(7):
        for k in range(3):
            add(d * DAY + rng.randint(8, 16) * 3600 + rng.randint(0, 3000), "auth.success", user=f"user{u}", src_ip=f"192.0.2.{10+u}", message="Accepted publickey")
        if rng.random() < 0.2:
            t = d * DAY + rng.randint(9, 16) * 3600
            for i in range(rng.randint(1, 3)): add(t + i * 20, "auth.failure", user=f"user{u}", src_ip=f"192.0.2.{10+u}", message="Failed password typo")
for i in range(400): add(rng.randint(0, 7 * DAY), "web.request", src_ip=f"192.0.2.{rng.randint(10, 60)}", message=f"GET /products?id={rng.randint(1,99)} HTTP/1.1 200 #{i}")
for i in range(50): add(rng.randint(0, 7 * DAY), "priv.sudo", user=f"user{i % 20}", message=f"sudo: COMMAND=/usr/bin/apt update #{i}")
for i in range(100): add(rng.randint(0, 7 * DAY), "net.fw", host="fw01", src_ip=f"45.{rng.randint(1,200)}.{rng.randint(1,200)}.{rng.randint(1,200)}", dst_ip="10.0.0.5", message=f"DPT={rng.choice([22,80,443,3389])}")
# hard benign cases (each can legitimately look like an attack)
for i in range(14): add(3 * DAY + 36000 + i * 12, "auth.failure", user="svc-backup", src_ip="192.0.2.99", message="Failed password stale service credential")  # misconfigured service
for i, a in enumerate(("opsA", "opsB", "opsC")): add(4 * DAY + 40000 + i * 900, "priv.sudo", user=a, message="sudo: COMMAND=/bin/bash maintenance")       # admins opening shells
for i, u in enumerate(("user3", "user4")): add(6 * DAY + 23 * 3600 + i * 60, "auth.success", user=u, src_ip=f"192.0.2.{13+i}", message="Accepted publickey night shift")
for p in range(40): add(5 * DAY + 30000 + p, "net.fw", host="fw01", src_ip="10.9.9.9", dst_ip="10.0.0.5", message=f"DPT={2000+p}")                      # authorised internal scanner
for i in range(2): add(5 * DAY + 50000 + i * 500, "web.request", src_ip=f"192.0.2.{20+i}", message="GET /docs?q=union select tutorial HTTP/1.1 200")        # SQL tutorial search

# ---- labelled attacks (20 trials per class; variants include ones the rule design cannot catch) ----
for i in range(20):                                         # brute force: 6-40 attempts over 30-900 s
    ip, n, dur, t0 = f"203.0.113.{i+1}", rng.randint(6, 40), rng.randint(30, 900), rng.randint(3 * DAY, 6 * DAY)
    for k in range(n): add(t0 + k * dur // n, "auth.failure", user="admin", src_ip=ip, message=f"Failed password {k}")
    trial("brute_force", f"src_ip:{ip}", "Brute-force login attempts")
for i in range(20):                                         # port scan: 8-80 ports over 5-120 s
    ip, n, dur, t0 = f"198.51.100.{i+1}", rng.randint(8, 80), rng.randint(5, 120), rng.randint(3 * DAY, 6 * DAY)
    for k in range(n): add(t0 + k * dur // n, "net.fw", host="fw01", src_ip=ip, dst_ip="10.0.0.5", message=f"SRC={ip} DPT={1000+k}")
    trial("port_scan", f"src_ip:{ip}", "Port scan / reconnaissance")
BAD_IPS = [f"203.0.113.{200+i}" for i in range(10)]; BAD_DOM = [f"c2-{i}.badhost.example" for i in range(5)]; BAD_H = [f"{i:02x}" * 32 for i in range(5)]
ioc_csv = "\n".join([f"ip,{x},feed,80," for x in BAD_IPS] + [f"domain,{x},feed,80," for x in BAD_DOM] + [f"hash,{x},feed,80," for x in BAD_H])
for i in range(20):                                         # IOC: 17 listed indicators, 3 unlisted (feed-coverage misses)
    h, t0 = f"10.1.0.{i+1}", rng.randint(0, 7 * DAY)
    if i < 10: add(t0, "net.fw", host="fw01", src_ip=h, dst_ip=BAD_IPS[i], message="outbound")
    elif i < 15: add(t0, "dns.query", src_ip=h, message=f"query {BAD_DOM[i-10]}")
    elif i < 17: add(t0, "proc.start", src_ip=h, message=f"exec sha {BAD_H[i-15]}")
    else: add(t0, "net.fw", host="fw01", src_ip=h, dst_ip=f"203.0.113.{240+i}", message="outbound to unlisted C2")
    trial("known_ioc", f"src_ip:{h}", "Known-malicious indicator")
CMDS = ["COMMAND=/bin/bash"] * 6 + ["COMMAND=/bin/sh -c id"] * 3 + ["NOPASSWD: ALL added"] * 3 + ["usermod -aG sudo eve"] * 2 + \
       ["COMMAND=/usr/bin/python3 -c 'import os;os.setuid(0)'"] * 3 + ["COMMAND=/usr/bin/vim -c :!sh"] * 3
for i, c in enumerate(CMDS):                                # priv-esc: 14 matchable, 6 evasive
    add(rng.randint(0, 7 * DAY), "priv.sudo", user=f"eve{i}", message=f"sudo: eve{i} : {c}"); trial("priv_esc", f"username:eve{i}", "Privilege escalation command")
PAY = ["' or '1'='1", "' OR 1=1 --", "UNION SELECT user,pass", "<script>alert(1)</script>", "../../etc/passwd", "1;sleep(5)", "information_schema.tables", "<img onerror=x>"]
WEB = [p for p in PAY] + [p.replace(" ", "%20").replace("'", "%27").replace("<", "%3C") for p in PAY[:6]] + \
      [p.replace("%", "%25") for p in ["%27%20or%201=1", "%3Cscript%3E", "..%2f..%2f"]] + ["UN/**/ION SEL/**/ECT 1", "uni%00on sel%00ect 1", "<scr<script>ipt>"]
for i, p in enumerate(WEB):                                 # web attacks: 8 plain, 6 single-encoded, 3 double-encoded, 3 obfuscated
    ip = f"100.64.0.{i+1}"; add(rng.randint(0, 7 * DAY), "web.request", src_ip=ip, message=f"GET /search?q={p} HTTP/1.1 200"); trial("web_attack", f"src_ip:{ip}", "Web attack signature (SQLi/XSS probe)")
for i in range(20):                                         # anomalous login: 16 at night, 4 inside normal hours
    u = f"emp{i}"
    for d in range(7):
        for k in range(4): add(d * DAY + rng.randint(9, 16) * 3600 + k * 600, "auth.success", user=u, src_ip=f"192.0.2.{100+i}", message="Accepted publickey")
    add(6 * DAY + (rng.randint(2, 4) if i < 16 else 11) * 3600 + 1800, "auth.success", user=u, src_ip=f"192.0.2.{100+i}", message="Accepted (attacker session)")
    trial("anomalous_login", f"username:{u}", "Anomalous login time")
multi = []
for i in range(20):                                         # two-source attack: firewall scan, then endpoint brute force
    ip, t0 = f"203.0.113.{100+i}", rng.randint(3 * DAY, 6 * DAY)
    for k in range(30): add(t0 + k, "net.fw", host="fw01", src_ip=ip, dst_ip="10.0.0.5", message=f"SRC={ip} DPT={1000+k}")
    for k in range(15): add(t0 + 60 + k * 6, "auth.failure", user="admin", src_ip=ip, message=f"Failed password {k}")
    multi.append(f"src_ip:{ip}")

init_db()
from app.routes_detect import import_iocs  # noqa: E402 (reuse the real CSV importer through the DB)
from app.models import IOC
with SessionLocal() as db:
    for line in ioc_csv.splitlines():
        t, v, *_ = line.split(","); db.add(IOC(type=t, value=v, source="feed", confidence=80))
    db.commit(); ingest.enqueue(db, items, "json", None, "api", "simulated"); db.commit()
    while ingest.process_queue(db): pass
    while detect.process_new(db): pass
    al = [(a.entity, [r["name"] for r in json.loads(a.explanation)["rules"]], a.severity) for a in db.scalars(select(Alert))]
    raw = db.get(IngestMetric, "raw_findings").value; lat = sorted(a.trigger_latency_ms or 0 for a in db.scalars(select(Alert)))

def wilson(k, n, z=1.96):
    if n == 0: return (0, 0)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return ((c - m) / d, (c + m) / d)
by = {}
for t in trials: by.setdefault(t["cls"], []).append(any(e == t["entity"] and t["expect"] in names for e, names, _ in al))
attack_ents = {t["entity"] for t in trials} | set(multi)
tp = [a for a in al if a[0] in attack_ents]; fp = [a for a in al if a[0] not in attack_ents]
single = sum(1 for e in multi if sum(1 for a in al if a[0] == e) == 1 and any(len(a[1]) >= 2 for a in al if a[0] == e))
rows = ["| Attack class | Trials | Detected | Recall | 95% CI (Wilson) |", "|---|---|---|---|---|"]
for c, r in by.items(): k, n = sum(r), len(r); lo, hi = wilson(k, n); rows.append(f"| {c} | {n} | {k} | {k/n:.0%} | {lo:.0%}-{hi:.0%} |")
K, N = sum(sum(r) for r in by.values()), sum(len(r) for r in by.values()); lo, hi = wilson(K, N); rows.append(f"| **All classes** | {N} | {K} | {K/N:.0%} | {lo:.0%}-{hi:.0%} |")
fpr = len(fp) / len(al); flo, fhi = wilson(len(fp), len(al))
rep = f"""# CyberShield detection evaluation (rule engine, synthetic labelled scenarios)

**Read this first.** All data is synthetic and generated by `evaluate.py` (seed 42). The scenarios were written by the same
team that wrote the rules and deliberately include evasive variants and hard benign cases. These numbers describe this
scenario mix only. They do not show that CyberShield detects real attacks, and they are not an independent validation.
Not covered by any rule: encrypted-traffic exfiltration, zero-days, low-and-slow attacks under the thresholds.

## Recall per attack class (NFR-ACC-01 target: at least 90% per class)
{chr(10).join(rows)}

Misses by design of the scenario mix: brute force slower than 10 failures per 5 min, scans under 16 ports per 60 s,
IOCs absent from the feed (3), privilege-escalation commands outside the rule's list (6), double-encoded or obfuscated web
payloads (6), and attacker logins inside the user's normal hours (4).

## False positives (NFR-ACC-02 target: at most 5% of alerts)
Benign week: 20 users, about {sum(1 for i in items if i['event_type']=='auth.success')} successful logins, 400 web requests, 50 sudo events, 100 isolated firewall drops,
plus 5 hard benign cases (misconfigured service account, 3 admins opening shells, 2 night-shift logins, an authorised internal scanner,
2 SQL-tutorial searches). Total alerts {len(al)}: {len(tp)} attributable to labelled attacks, **{len(fp)} false positives = {fpr:.1%}** (95% CI {flo:.1%}-{fhi:.1%}).
False-positive entities: {', '.join(sorted(a[0] for a in fp))}.
The 5% target is {'MET' if fpr <= 0.05 else 'NOT MET'} on this data. The scenario set is small and the hard benign cases were chosen to be hard, so this is not a field rate.

## Correlation (FR-DET-07, AC-08, OBJ-3)
Two-source attacks (firewall scan then endpoint brute force from one IP): {single} of {len(multi)} produced exactly one correlated alert with both rules.
Raw rule findings: {raw}; alerts raised: {len(al)}; reduction {1 - len(al)/raw:.0%} (OBJ-3 target: at least 30%).

## Latency
Detection time per alert in this batch run is not meaningful for NFR-PERF-02 (events were processed in bulk, median {lat[len(lat)//2]} ms, max {lat[-1]} ms). Latency needs a live-load test.
"""
open("../docs/detection_evaluation.md", "w").write(rep); print(rep)
