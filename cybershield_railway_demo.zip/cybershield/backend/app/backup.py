"""Encrypted configuration backup and restore (FR-ADM-03, UC-09, SR-07). AES-256-GCM, key from passphrase via scrypt.
Backups hold password hashes and MFA secrets when users are included, so they must be stored like secrets.
Restore MERGES by primary key: items missing from the backup are left alone. Events, alerts, incidents and the audit log are never touched."""
import base64, json, os
from datetime import datetime
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from sqlalchemy import select, DateTime
from .models import utcnow, Asset, IOC, LogSource, RetentionPolicy, Role, Rule, RuleVersion, Suppression, User

TABLES = [("assets", Asset), ("rules", Rule), ("rule_versions", RuleVersion), ("suppressions", Suppression), ("log_sources", LogSource), ("iocs", IOC), ("retention", RetentionPolicy)]
AAD = b"cybershield-config-backup-v1"

def _ser(o, skip=()):
    d = {}
    for c in o.__mapper__.column_attrs:
        if c.key in skip: continue
        v = getattr(o, c.key); d[c.key] = v.isoformat() if isinstance(v, datetime) else v
    return d

def _de(model, d):
    cols = {c.key: c for c in model.__mapper__.column_attrs}; out = {}
    for k, v in d.items():
        if k in cols and isinstance(v, str) and isinstance(cols[k].columns[0].type, DateTime): v = datetime.fromisoformat(v)
        if k in cols: out[k] = v
    return out

def snapshot(db, include_users) -> dict:
    snap = {"format": 1, "created_at": utcnow().isoformat(), "tables": {n: [_ser(o) for o in db.scalars(select(m))] for n, m in TABLES}}
    if include_users:
        names = {r.id: r.name for r in db.scalars(select(Role))}
        snap["tables"]["users"] = [{**_ser(u, skip=("role_id",)), "role": names[u.role_id]} for u in db.scalars(select(User))]
    return snap

def _key(pw, salt): return Scrypt(salt=salt, length=32, n=2 ** 15, r=8, p=1).derive(pw.encode())

def encrypt(pw, snap) -> bytes:
    salt, nonce = os.urandom(16), os.urandom(12); ct = AESGCM(_key(pw, salt)).encrypt(nonce, json.dumps(snap).encode(), AAD)
    return json.dumps({"v": 1, "alg": "AES-256-GCM", "kdf": "scrypt-n32768-r8-p1", "salt": base64.b64encode(salt).decode(), "nonce": base64.b64encode(nonce).decode(), "ct": base64.b64encode(ct).decode()}).encode()

def decrypt(pw, blob: bytes) -> dict:
    try:
        h = json.loads(blob)
        if h["v"] != 1: raise ValueError("unsupported backup version")
        return json.loads(AESGCM(_key(pw, base64.b64decode(h["salt"]))).decrypt(base64.b64decode(h["nonce"]), base64.b64decode(h["ct"]), AAD))
    except (InvalidTag, ValueError, KeyError, TypeError): raise ValueError("Wrong passphrase, or the backup file is damaged")

def restore(db, snap) -> dict:
    counts, idmap = {}, {}
    if "users" in snap["tables"]:  # users first: other tables reference them (Rule.created_by)
        roles = {r.name: r.id for r in db.scalars(select(Role))}
        for d in snap["tables"]["users"]:
            d = dict(d); old_id = d.pop("id"); role = d.pop("role"); d["role_id"] = roles[role]
            ex = db.scalar(select(User).where(User.username == d["username"]))
            if ex:
                for k, v in _de(User, d).items(): setattr(ex, k, v)  # update in place; never reuse a foreign id
                u = ex
            else: u = User(**_de(User, d)); db.add(u)
            db.flush(); idmap[old_id] = u.id; counts["users"] = counts.get("users", 0) + 1
        if not db.scalar(select(User.id).join(Role, Role.id == User.role_id).where(Role.name == "Administrator", User.status == "active")):
            raise ValueError("Restore would leave no active Administrator")
    for n, m in TABLES:
        for d in snap["tables"].get(n, []):
            d = dict(d)
            if n == "rules": d["created_by"] = idmap.get(d.get("created_by")) if idmap else (d.get("created_by") if d.get("created_by") and db.get(User, d["created_by"]) else None)
            if n == "suppressions": d["created_by"] = idmap.get(d.get("created_by")) if idmap else None
            if n == "rule_versions": d["changed_by"] = None
            db.merge(m(**_de(m, d))); counts[n] = counts.get(n, 0) + 1
        db.flush()
    return counts
