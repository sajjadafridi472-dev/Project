"""Response checklists by incident type, organised by NIST SP 800-61 phases (FR-INC-05)."""
PLAYBOOKS = {
    "brute_force": [("Analysis", "Confirm source IP(s) and targeted accounts from the linked alerts"), ("Analysis", "Check whether any attempt succeeded (auth.success after failures)"),
                    ("Containment", "Propose a block of the source IP for Manager approval"), ("Containment", "Force password reset / disable any account that was accessed"),
                    ("Recovery", "Confirm MFA is enforced on targeted accounts"), ("Post-incident", "Record findings and tune the brute-force rule or suppression if needed")],
    "phishing": [("Analysis", "Identify the reported message, sender and recipients"), ("Analysis", "Check whether anyone clicked or entered credentials"),
                 ("Containment", "Reset credentials and revoke sessions for affected users"), ("Containment", "Block sender and malicious URLs/domains; add IOCs"),
                 ("Eradication", "Remove the message from all mailboxes"), ("Post-incident", "Notify users and document lessons learned")],
    "ransomware": [("Containment", "Isolate affected hosts from the network immediately"), ("Analysis", "Identify patient zero, strain and encrypted scope"),
                   ("Containment", "Disable compromised accounts; protect backups from the network"), ("Eradication", "Remove persistence and malicious binaries"),
                   ("Recovery", "Restore from clean backups after verifying integrity"), ("Post-incident", "Report per policy and document lessons learned")],
    "malware": [("Analysis", "Identify affected hosts and the matching indicator(s)"), ("Containment", "Isolate affected hosts; block the indicator at the perimeter"),
                ("Eradication", "Remove the malware and any persistence"), ("Recovery", "Restore the host to a known-good state and monitor"),
                ("Post-incident", "Add related IOCs and document lessons learned")],
    "other": [("Analysis", "Review linked alerts and events and establish scope"), ("Containment", "Decide on and apply containment steps"),
              ("Eradication", "Remove the cause"), ("Recovery", "Restore normal service and monitor"), ("Post-incident", "Document findings and lessons learned")],
}
