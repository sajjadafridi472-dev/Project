"""In-process fan-out of alert updates to WebSocket clients. Thread-safe publish from the detection worker."""
import asyncio
from fastapi.encoders import jsonable_encoder

class Hub:
    def __init__(self): self.clients, self.loop = set(), None
    def subscribe(self):
        q = asyncio.Queue(maxsize=200); self.clients.add(q); return q
    def unsubscribe(self, q): self.clients.discard(q)
    @staticmethod
    def _put(q, m):
        if q.full(): q.get_nowait()  # slow client: drop oldest, never block detection
        q.put_nowait(m)
    def publish(self, msg):
        if self.loop is None or self.loop.is_closed(): return
        for q in list(self.clients): self.loop.call_soon_threadsafe(self._put, q, msg)
    def publish_alerts(self, alerts):
        for a in alerts: self.publish({"type": "alert", "alert": jsonable_encoder(a)})

hub = Hub()
