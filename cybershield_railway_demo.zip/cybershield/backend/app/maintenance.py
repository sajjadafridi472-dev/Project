"""Throttled housekeeping called from the worker loop: heartbeat, scheduled reports, daily retention."""
import time
from . import metrics, report, retention
from .models import IngestMetric
_last = {"beat": 0.0, "work": 0.0}

def heartbeat(db):
    metrics.set_value(db, "worker_heartbeat", int(time.time())); db.commit()

def tick(db):
    now = time.time()
    if now - _last["beat"] >= 5: _last["beat"] = now; heartbeat(db)
    if now - _last["work"] >= 60: _last["work"] = now; report.run_due(db); retention.run_if_due(db)
