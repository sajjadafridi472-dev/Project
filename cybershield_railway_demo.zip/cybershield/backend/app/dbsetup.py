"""Database-level guards that SQLAlchemy models cannot express. Used by init_db() and by the Alembic migration."""

def install_audit_guards(conn):
    """Make audit_log append-only inside the database itself (SR-12): UPDATE, DELETE and TRUNCATE are refused."""
    d = conn.dialect.name
    if d == "sqlite":
        conn.exec_driver_sql("CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END")
        conn.exec_driver_sql("CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT,'audit log is append-only'); END")
    elif d == "postgresql":
        conn.exec_driver_sql("CREATE OR REPLACE FUNCTION audit_log_immutable() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'audit log is append-only'; END; $$ LANGUAGE plpgsql")
        conn.exec_driver_sql("DROP TRIGGER IF EXISTS audit_no_change ON audit_log")
        conn.exec_driver_sql("CREATE TRIGGER audit_no_change BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION audit_log_immutable()")
        conn.exec_driver_sql("DROP TRIGGER IF EXISTS audit_no_truncate ON audit_log")
        conn.exec_driver_sql("CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION audit_log_immutable()")

def drop_audit_guard_for_tests(conn):  # used only by the tamper-evidence test
    if conn.dialect.name == "sqlite": conn.exec_driver_sql("DROP TRIGGER audit_no_update")
    else: conn.exec_driver_sql("DROP TRIGGER audit_no_change ON audit_log")
