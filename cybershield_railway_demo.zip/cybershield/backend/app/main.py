import asyncio, os, time, hmac
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from datetime import timedelta
from fastapi import FastAPI, Depends, HTTPException, Header, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from . import audit, rbac, ingest, detect, notify, retention, dbsetup, security as sec
from .hub import hub
from .config import settings
from .db import Base, engine, get_db, SessionLocal
from .models import Role, User, Session as UserSession, AuditLog, utcnow

EMAIL = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
UNAME = r"^[A-Za-z0-9_.-]+$"

def init_db():
    Base.metadata.create_all(engine)
    with engine.begin() as c: dbsetup.install_audit_guards(c)  # DB-level append-only guard (SR-12)
    with SessionLocal() as db:
        for r in rbac.ROLES:
            if not db.scalar(select(Role).where(Role.name == r)): db.add(Role(name=r))
        db.commit(); detect.seed_rules(db); retention.seed(db)

@asynccontextmanager
async def lifespan(_):
    hub.loop = asyncio.get_running_loop(); init_db(); stoppers = ingest.start_background()
    yield
    for stop in stoppers: stop()

app = FastAPI(title="CyberShield API", lifespan=lifespan)

_hits: dict = defaultdict(deque)
def rate_limit(ip, limit=None):  # SR-17
    limit = limit or settings.rate_limit
    now = time.time(); q = _hits[ip]
    while q and now - q[0] > 60: q.popleft()
    if len(q) >= limit: raise HTTPException(429, "Too many requests. Try again shortly.")
    q.append(now)

def ip_of(r: Request): return r.client.host if r.client else None

def resolve_session(db, token: str, touch: bool = True) -> User:
    s = db.scalar(select(UserSession).where(UserSession.token_hash == sec.token_hash(token), UserSession.revoked == False))  # noqa: E712
    now = utcnow()
    if (not s or s.expires_at < now or now - s.last_seen > timedelta(minutes=settings.idle_minutes)
            or s.user.status != "active"):
        if s: s.revoked = True; db.commit()
        raise HTTPException(401, "Session expired or invalid")
    if touch: s.last_seen = now; db.commit()
    return s.user

def current_user(authorization: str = Header(None), db=Depends(get_db)) -> User:
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(401, "Authentication required")
    return resolve_session(db, authorization[7:])

def require(function: str, level: str = "R"):
    def dep(user: User = Depends(current_user)) -> User:
        if not rbac.allowed(user.role.name, function, level): raise HTTPException(403, "Not permitted for your role")
        return user
    dep.rbac = (function, level)  # introspected by the route-authorization sweep test
    return dep

class UserIn(BaseModel):
    username: str = Field(min_length=3, max_length=50, pattern=UNAME)
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(pattern=EMAIL, max_length=254)
    password: str = Field(max_length=128)

class CreateUser(UserIn):
    role: str
    enable_mfa: bool = False

class PatchUser(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=100)
    email: str | None = Field(None, pattern=EMAIL, max_length=254)
    role: str | None = None
    status: str | None = Field(None, pattern="^(active|disabled)$")

class LoginIn(BaseModel):
    username: str = Field(max_length=50)
    password: str = Field(max_length=128)
    otp: str | None = Field(None, max_length=6)

def _new_user(db, body, role_name, mfa) -> tuple[User, dict]:
    if role_name not in rbac.ROLES: raise HTTPException(422, "Unknown role")
    if (e := sec.password_error(body.password)): raise HTTPException(422, e)
    if db.scalar(select(User).where((User.username == body.username) | (User.email == body.email))):
        raise HTTPException(409, "Username or email already exists")
    role = db.scalar(select(Role).where(Role.name == role_name))
    u = User(username=body.username, name=body.name, email=body.email, role_id=role.id,
             password_hash=sec.hash_password(body.password))
    extra = {}
    if mfa or role_name in rbac.MFA_REQUIRED:  # SR-02
        u.mfa_secret = sec.new_totp_secret(); u.mfa_enabled = True
        extra = {"mfa_secret": u.mfa_secret, "provisioning_uri": sec.totp_uri(u.mfa_secret, u.username)}
    db.add(u); db.flush(); db.refresh(u)
    return u, extra

def _view(u: User): return {"id": u.id, "username": u.username, "name": u.name, "email": u.email,
                            "role": u.role.name, "status": u.status, "mfa_enabled": u.mfa_enabled,
                            "last_login": u.last_login}

@app.get("/api/v1/setup/status")
def setup_status(db=Depends(get_db)):
    """Lets the UI show the first-run screen. Reveals only whether any account exists."""
    return {"needed": not db.scalar(select(func.count(User.id))), "token_required": bool(settings.setup_token)}

@app.post("/api/v1/setup", status_code=201)
def first_run_setup(body: UserIn, request: Request, x_setup_token: str | None = Header(None), db=Depends(get_db)):
    """First-run only: no default credentials exist (section 7.9)."""
    if settings.setup_token and not hmac.compare_digest(x_setup_token or "", settings.setup_token):
        raise HTTPException(403, "A valid setup token is required for initial administrator creation")
    if db.scalar(select(func.count(User.id))): raise HTTPException(409, "Setup already completed")
    u, extra = _new_user(db, body, "Administrator", True)
    audit.log(db, "setup.admin_created", user=u, obj=u.username, ip=ip_of(request)); db.commit()
    return {**_view(u), **extra}

@app.post("/api/v1/auth/login")
def login(body: LoginIn, request: Request, db=Depends(get_db)):
    ip = ip_of(request); rate_limit(ip)
    bad = HTTPException(401, "Invalid credentials")  # same message for all failures (no user enumeration)
    u = db.scalar(select(User).where(User.username == body.username))
    if not u or u.status != "active":
        audit.log(db, "login.failed", username=body.username, ip=ip, new="unknown or disabled"); db.commit(); raise bad
    now = utcnow()
    if u.locked_until and u.locked_until > now:
        audit.log(db, "login.blocked_locked", user=u, ip=ip); db.commit()
        raise HTTPException(423, "Account temporarily locked. Try again later.")

    def fail(reason):
        u.failed_attempts += 1
        audit.log(db, "login.failed", user=u, ip=ip, new=reason)
        if u.failed_attempts >= settings.max_failed:  # FR-AUTH-05
            u.locked_until = now + timedelta(minutes=settings.lock_minutes); u.failed_attempts = 0
            audit.log(db, "account.locked", user=u, ip=ip, new="administrators notified")
            notify.queue_lockout(db, u)  # FR-AUTH-05
        db.commit(); raise bad

    if not sec.verify_password(body.password, u.password_hash): fail("bad password")
    if u.mfa_enabled:
        if not body.otp: raise HTTPException(401, "MFA code required")
        if not sec.verify_totp(u.mfa_secret, body.otp): fail("bad MFA code")
    token = sec.new_token()
    db.add(UserSession(token_hash=sec.token_hash(token), user_id=u.id, last_seen=now,
                       expires_at=now + timedelta(hours=settings.session_hours)))
    u.failed_attempts = 0; u.locked_until = None; u.last_login = now
    audit.log(db, "login.success", user=u, ip=ip); db.commit()
    return {"token": token, "user": _view(u)}

@app.post("/api/v1/auth/logout")
def logout(request: Request, authorization: str = Header(None), user=Depends(current_user), db=Depends(get_db)):
    s = db.scalar(select(UserSession).where(UserSession.token_hash == sec.token_hash(authorization[7:])))
    s.revoked = True; audit.log(db, "logout", user=user, ip=ip_of(request)); db.commit()
    return {"ok": True}

@app.get("/api/v1/auth/me")
def me(user=Depends(current_user)): return _view(user)

@app.get("/api/v1/users")
def list_users(user=Depends(require("users")), db=Depends(get_db)):
    return [_view(u) for u in db.scalars(select(User).order_by(User.id))]

@app.post("/api/v1/users", status_code=201)
def create_user(body: CreateUser, request: Request, admin=Depends(require("users", "RW")), db=Depends(get_db)):
    u, extra = _new_user(db, body, body.role, body.enable_mfa)
    audit.log(db, "user.create", user=admin, obj=u.username, new=u.role.name, ip=ip_of(request)); db.commit()
    return {**_view(u), **extra}

def _get_user(db, uid):
    u = db.get(User, uid)
    if not u: raise HTTPException(404, "User not found")
    return u

@app.patch("/api/v1/users/{uid}")
def edit_user(uid: int, body: PatchUser, request: Request, admin=Depends(require("users", "RW")), db=Depends(get_db)):
    u = _get_user(db, uid); old = _view(u)
    if uid == admin.id and body.status == "disabled": raise HTTPException(400, "You cannot disable your own account")
    if uid == admin.id and body.role and body.role != u.role.name: raise HTTPException(400, "You cannot change your own role")
    if body.email and body.email != u.email and db.scalar(select(User).where(User.email == body.email)):
        raise HTTPException(409, "Username or email already exists")
    extra = {}
    if body.role:
        if body.role not in rbac.ROLES: raise HTTPException(422, "Unknown role")
        u.role_id = db.scalar(select(Role).where(Role.name == body.role)).id; db.flush(); db.refresh(u)
        if body.role in rbac.MFA_REQUIRED and not u.mfa_enabled:
            u.mfa_secret = sec.new_totp_secret(); u.mfa_enabled = True  # shown once, like on creation, or the user could never sign in
            extra = {"mfa_secret": u.mfa_secret, "provisioning_uri": sec.totp_uri(u.mfa_secret, u.username)}
    for f in ("name", "email", "status"):
        if getattr(body, f) is not None: setattr(u, f, getattr(body, f))
    if u.status == "disabled":
        for s in u.sessions: s.revoked = True
    audit.log(db, "user.edit", user=admin, obj=u.username, old=str(old), new=str(_view(u)), ip=ip_of(request))
    db.commit(); return {**_view(u), **extra}

@app.delete("/api/v1/users/{uid}")
def delete_user(uid: int, request: Request, admin=Depends(require("users", "RW")), db=Depends(get_db)):
    u = _get_user(db, uid)
    if uid == admin.id: raise HTTPException(400, "You cannot delete your own account")
    audit.log(db, "user.delete", user=admin, obj=u.username, old=str(_view(u)), ip=ip_of(request))
    db.delete(u); db.commit(); return {"ok": True}

@app.get("/api/v1/audit")
def audit_list(action: str | None = None, limit: int = 100, user=Depends(require("audit")), db=Depends(get_db)):
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(min(max(limit, 1), 500))
    if action: q = q.where(AuditLog.action == action)
    return [{"id": e.id, "timestamp": e.timestamp, "username": e.username, "action": e.action,
             "object": e.object, "ip": e.ip} for e in db.scalars(q)]

@app.get("/api/v1/audit/verify")
def audit_verify(user=Depends(require("audit")), db=Depends(get_db)): return {"intact": audit.verify_chain(db)}

from . import routes_ingest  # noqa: E402  (registers Module 2 routes; needs the deps defined above)
app.include_router(routes_ingest.router)
from . import routes_detect  # noqa: E402
app.include_router(routes_detect.router)
from . import routes_alerts, routes_notify, routes_incidents, routes_dashboard, routes_reports, routes_admin  # noqa: E402
app.include_router(routes_alerts.router)
app.include_router(routes_notify.router)
app.include_router(routes_incidents.router)
app.include_router(routes_dashboard.router)
app.include_router(routes_reports.router)
app.include_router(routes_admin.router)

CSP = "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'"
@app.middleware("http")
async def security_headers(request, call_next):  # SR-14 / OWASP hardening (HSTS belongs on the TLS reverse proxy, SR-06)
    r = await call_next(request)
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"})
    if not request.url.path.startswith(("/docs", "/redoc", "/openapi")): r.headers["Content-Security-Policy"] = CSP
    return r

from pathlib import Path  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402
_dist = Path(os.environ.get("CYBERSHIELD_UI_DIR") or Path(__file__).resolve().parents[2] / "frontend" / "dist")  # override used by the packaged program
if _dist.exists(): app.mount("/", StaticFiles(directory=_dist, html=True), name="ui")  # must stay last: API routes win
