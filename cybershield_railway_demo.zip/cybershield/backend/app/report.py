"""Security summary report: build once, render as JSON, CSV or PDF so totals always agree (FR-RPT-01..03, AC-14)."""
import io
from datetime import timedelta
from xml.sax.saxutils import escape  # nosec B406 - used only to escape text for ReportLab, never to parse XML
from sqlalchemy import select, func, and_
from .models import Alert, Event, Incident, IngestMetric, utcnow
from .routes_incidents import _metrics, _detected

SPANS = {"daily": timedelta(days=1), "weekly": timedelta(days=7), "monthly": timedelta(days=30)}
DEFS = ("MTTD = mean(first alert created - first linked event); MTTR = mean(resolved - first alert created); "
        "incidents marked false positive are excluded. Windows are (start, end].")

def _mean(vals):
    v = [x for x in vals if x is not None]; return round(sum(v) / len(v)) if v else None

def build(db, period, end=None):
    end = end or utcnow(); start = end - SPANS[period]; w = lambda c: and_(c > start, c <= end)
    ev = lambda *cols: select(*cols).where(w(Event.timestamp)); al = lambda *cols: select(*cols).where(w(Alert.created_at))
    events = {"total": db.scalar(ev(func.count()))}
    for o, n in db.execute(ev(Event.data_origin, func.count()).group_by(Event.data_origin)): events["origin." + o] = n
    for t, n in db.execute(ev(Event.event_type, func.count()).group_by(Event.event_type).order_by(func.count().desc(), Event.event_type).limit(10)): events["type." + t] = n
    alerts = {"total": db.scalar(al(func.count()))}
    for k, n in db.execute(al(Alert.severity, func.count()).group_by(Alert.severity)): alerts["severity." + k] = n
    for k, n in db.execute(al(Alert.status, func.count()).group_by(Alert.status)): alerts["status." + k] = n
    for k, n in db.execute(al(Alert.title, func.count()).group_by(Alert.title).order_by(func.count().desc(), Alert.title).limit(10)): alerts["rule." + k] = n
    src = {e[7:]: n for e, n in db.execute(al(Alert.entity, func.count()).where(Alert.entity.like("src_ip:%")).group_by(Alert.entity).order_by(func.count().desc(), Alert.entity).limit(5))}
    assets = {h: n for h, n in db.execute(al(Alert.hostname, func.count()).where(Alert.hostname.isnot(None)).group_by(Alert.hostname).order_by(func.count().desc(), Alert.hostname).limit(5))}
    created = db.scalars(select(Incident).where(w(Incident.created_at))).all(); real = [i for i in created if not i.false_positive]
    ms = [_metrics(i, _detected(db, i)) for i in real]
    incidents = {"created": len(created), "false_positives": len(created) - len(real), "resolved_in_period": db.scalar(select(func.count()).where(w(Incident.resolved_at))),
                 "open_at_end": db.scalar(select(func.count()).where(Incident.created_at <= end, Incident.status.notin_(("Resolved", "False Positive", "Closed")))),
                 "MTTD_s": _mean([m["time_to_detect_s"] for m in ms]), "mean_time_to_acknowledge_s": _mean([m["time_to_acknowledge_s"] for m in ms]),
                 "mean_time_to_contain_s": _mean([m["time_to_contain_s"] for m in ms]), "MTTR_s": _mean([m["time_to_resolve_s"] for m in ms])}
    ing = {r.key: r.value for r in db.scalars(select(IngestMetric)) if r.key in ("accepted", "quarantined", "duplicates", "suppressed", "rule_errors")}
    sim = events.get("origin.simulated", 0)
    notes = ["Detection is rule-based and statistical; there is no machine learning. Reports describe what the configured rules saw, not all activity."]
    if sim: notes.append(f"{sim} of the {events['total']} events in this period are SIMULATED and are not real monitoring data.")
    return {"type": "summary", "period": period, "start": start, "end": end, "generated_at": utcnow(), "definitions": DEFS,
            "sections": {"events": events, "alerts": alerts, "top_attack_sources": src, "top_attacked_assets": assets, "incidents": incidents, "ingestion_since_start": ing}, "notes": notes}

def _cell(v):  # CSV formula-injection guard
    v = "" if v is None else str(v); return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v

def to_csv(d) -> str:
    import csv
    out = io.StringIO(); w = csv.writer(out); w.writerow(["section", "item", "value"])
    for k in ("type", "period", "start", "end", "generated_at"): w.writerow(["report", k, _cell(d[k])])
    for sec, kv in d["sections"].items():
        for k, v in kv.items(): w.writerow([_cell(sec), _cell(k), _cell(v)])
    for n in d["notes"]: w.writerow(["note", "", _cell(n)])
    return out.getvalue()

def to_pdf(d) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    st = getSampleStyleSheet(); buf = io.BytesIO(); P = lambda t, s="Normal": Paragraph(escape(str(t)), st[s])
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=16 * mm, title=f"CyberShield {d['period']} security summary", author="CyberShield")
    story = [P(f"CyberShield {d['period']} security summary", "Title"), P(f"Period: {d['start']:%Y-%m-%d %H:%M} to {d['end']:%Y-%m-%d %H:%M} UTC. Generated {d['generated_at']:%Y-%m-%d %H:%M} UTC."), Spacer(1, 6)]
    for n in d["notes"]: story += [P(n), Spacer(1, 3)]
    for sec, kv in d["sections"].items():
        story += [Spacer(1, 8), P(sec.replace("_", " ").capitalize(), "Heading2")]
        rows = [[P(k), P("-" if v is None else v)] for k, v in kv.items()] or [[P("(no data)"), P("")]]
        t = Table(rows, colWidths=[110 * mm, 60 * mm]); t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")])); story.append(t)
    story += [Spacer(1, 8), P("Definitions", "Heading2"), P(d["definitions"])]
    def foot(c, _):
        c.saveState(); c.setFont("Helvetica", 8); c.drawString(18 * mm, 9 * mm, "CyberShield summary report. Confidential."); c.drawRightString(192 * mm, 9 * mm, f"Page {c.getPageNumber()}"); c.restoreState()
    doc.build(story, onFirstPage=foot, onLaterPages=foot); return buf.getvalue()

def run_due(db, now=None) -> int:
    """Send scheduled reports by e-mail through the outbox (FR-RPT-05)."""
    from . import audit, notify, rbac
    from .models import ReportSchedule, User
    now = now or utcnow(); n = 0
    for s in db.scalars(select(ReportSchedule)):
        if now < (s.last_run_at or s.created_at) + SPANS[s.period]: continue
        u = db.get(User, s.user_id)
        if not u or u.status != "active" or not rbac.allowed(u.role.name, "reports", "RW"): continue
        d = build(db, s.period, now); data, ct = (to_pdf(d), "application/pdf") if s.format == "pdf" else (to_csv(d).encode(), "text/csv")
        notify.queue_report(db, u, f"[CyberShield] {s.period} security summary", f"Your scheduled {s.period} summary report is attached.\nSimulated data, if any, is stated in the report notes.\n", (f"cybershield-{s.period}-{now:%Y-%m-%d}.{s.format}", ct, data))
        s.last_run_at = now; audit.log(db, "report.scheduled", username="system", obj=f"{s.period}/{s.format}", new=u.username); n += 1
    if n: db.commit()
    return n
