"""Optional GeoIP lookup (FR-DSH-04, Could). No database is bundled (licensing); supply GEOIP_CSV with lines cidr,country,lat,lon."""
import csv, ipaddress
_cache: dict = {}

def load(path):
    if path not in _cache:
        nets = []
        try:
            with open(path, newline="") as f:
                for row in csv.reader(f):
                    try: nets.append((ipaddress.ip_network(row[0].strip(), strict=False), row[1].strip(), float(row[2]), float(row[3])))
                    except (ValueError, IndexError): continue  # skip header / malformed lines
        except OSError: pass
        _cache[path] = nets
    return _cache[path]

def lookup(path, ip):
    try: a = ipaddress.ip_address(ip)
    except ValueError: return None
    for n, country, lat, lon in load(path):
        if a in n: return {"country": country, "lat": lat, "lon": lon}
    return None
