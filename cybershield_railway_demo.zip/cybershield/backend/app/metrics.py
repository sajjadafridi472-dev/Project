"""Atomic counters. INSERT ... ON CONFLICT is safe when several workers update the same key at once."""
from sqlalchemy.dialects import postgresql, sqlite
from .models import IngestMetric

def _insert(db): return (postgresql if db.get_bind().dialect.name == "postgresql" else sqlite).insert

def bump(db, key: str, n: int = 1):
    db.execute(_insert(db)(IngestMetric).values(key=key, value=n).on_conflict_do_update(index_elements=[IngestMetric.key], set_={"value": IngestMetric.value + n}))

def set_value(db, key: str, value: int):
    db.execute(_insert(db)(IngestMetric).values(key=key, value=value).on_conflict_do_update(index_elements=[IngestMetric.key], set_={"value": value}))
