"""Retention enforcement (FR-ADM-01, SRS 6.5). hot window -> compressed archive file -> deletion.
Archived records are NOT searchable. Incidents and the audit log are never deleted by the application."""
import gzip, json, os, uuid
from datetime import timedelta
from sqlalchemy import select, delete, update
from .config import settings
from . import metrics
from .models import Alert, AlertEvent, AlertIOC, AlertNote, Event, IOC, IncidentAlert, Notification, RetentionPolicy, IngestMetric, utcnow

DEFAULTS = {"events": (30, 365), "alerts": (365, 1095), "incidents": (1095, 2555), "audit": (365, 2555), "iocs": (1, 0)}
ENFORCED = {"events", "alerts", "iocs"}

def seed(db):
    for c, (h, a) in DEFAULTS.items():
        if not db.get(RetentionPolicy, c): db.add(RetentionPolicy(category=c, hot_days=h, archive_days=a))
    db.commit()

def _write(archive_dir, cat, rows, newest):
    os.makedirs(archive_dir, mode=0o700, exist_ok=True)
    path = os.path.join(archive_dir, f"{cat}_{int(newest.timestamp())}_{uuid.uuid4().hex[:8]}.jsonl.gz")
    with gzip.open(path + ".tmp", "wt", encoding="utf-8") as f:
        for r in rows: f.write(json.dumps(r, default=str) + "\n")
        f.flush(); os.fsync(f.buffer.fileobj.fileno()) if hasattr(f.buffer, "fileobj") else None
    os.replace(path + ".tmp", path); return path  # archive is durable before anything is deleted

def run(db, now=None, archive_dir=None, batch=50000) -> dict:
    now = now or utcnow(); ad = archive_dir or settings.archive_dir; pol = {p.category: p for p in db.scalars(select(RetentionPolicy))}; res = {}
    # alerts: only finished alerts that no incident uses
    cut = now - timedelta(days=pol["alerts"].hot_days)
    als = db.scalars(select(Alert).where(Alert.created_at < cut, Alert.status.in_(("Resolved", "False Positive", "Suppressed")), Alert.id.notin_(select(IncidentAlert.alert_id))).limit(batch)).all()
    if als:
        ids = [a.id for a in als]; links = {}
        for al_id, ev_id in db.execute(select(AlertEvent.alert_id, AlertEvent.event_id).where(AlertEvent.alert_id.in_(ids))): links.setdefault(al_id, []).append(ev_id)
        _write(ad, "alerts", [{**{c.key: getattr(a, c.key) for c in Alert.__mapper__.column_attrs}, "event_ids": links.get(a.id, [])} for a in als], max(a.created_at for a in als))
        for t in (AlertEvent, AlertIOC, AlertNote): db.execute(delete(t).where(t.alert_id.in_(ids)))
        db.execute(update(Notification).where(Notification.alert_id.in_(ids)).values(alert_id=None)); db.execute(delete(Alert).where(Alert.id.in_(ids)))
    res["alerts_archived"] = len(als); db.flush()
    # events (after alerts, so evidence freed by this run is archived in the same pass): keep any event an alert still references
    cut = now - timedelta(days=pol["events"].hot_days)
    evs = db.scalars(select(Event).where(Event.timestamp < cut, Event.id.notin_(select(AlertEvent.event_id))).order_by(Event.timestamp).limit(batch)).all()
    if evs:
        _write(ad, "events", [{c.key: getattr(e, c.key) for c in Event.__mapper__.column_attrs} for e in evs], max(e.timestamp for e in evs))
        db.execute(delete(Event).where(Event.id.in_([e.id for e in evs])))
    res["events_archived"] = len(evs)
    old = [i.id for i in db.scalars(select(IOC).where(IOC.expires_at.isnot(None), IOC.expires_at < now))]
    if old: db.execute(delete(AlertIOC).where(AlertIOC.ioc_id.in_(old))); db.execute(delete(IOC).where(IOC.id.in_(old)))
    res["iocs_expired"] = len(old); db.commit()
    purged = 0
    if os.path.isdir(ad):  # delete archive files once past hot + archive days
        for f in os.listdir(ad):
            cat, _, rest = f.partition("_")
            if cat in ("events", "alerts") and f.endswith(".jsonl.gz"):
                try: newest = int(rest.split("_")[0])
                except ValueError: continue
                if newest < (now - timedelta(days=pol[cat].hot_days + pol[cat].archive_days)).timestamp(): os.remove(os.path.join(ad, f)); purged += 1
    res["archive_files_deleted"] = purged; return res

def run_if_due(db, now=None):
    now = now or utcnow(); m = db.get(IngestMetric, "retention_last_run")
    if m and now.timestamp() - m.value < 86400: return None
    r = run(db, now)
    metrics.set_value(db, "retention_last_run", int(now.timestamp())); db.commit(); return r
