"""Collection layer: parse -> validate -> normalise -> persist (SRS 3.2, 6.3). Detection is Module 3."""
import hashlib, ipaddress, logging, json, re, threading, uuid
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from .config import settings
from . import metrics
from .db import SessionLocal
from .models import Asset, Event, IngestMetric, LogSource, QueueItem, Quarantine, utcnow

MAX_RAW = 16384
CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")
TYPE_RE = re.compile(r"^[a-z0-9_.]{1,60}$")
SEV_WORDS = {"info": 1, "low": 2, "medium": 5, "high": 7, "critical": 9}
MONTHS = {m: i for i, m in enumerate("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(), 1)}

def clean(s, limit=4096) -> str:  # treat log content as untrusted (SR-21)
    return CTRL.sub("", str(s).replace("\r", " ").replace("\n", " ").replace("\t", " "))[:limit]

def _ip(v):
    if v in (None, ""): return None
    try: return str(ipaddress.ip_address(str(v).strip()))
    except ValueError: raise ValueError(f"invalid IP address: {clean(v, 40)!r}")

def _ts(v, now=None) -> datetime:
    now = now or utcnow()
    try: d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError: raise ValueError("invalid timestamp")
    d = d.astimezone(timezone.utc).replace(tzinfo=None) if d.tzinfo else d
    if d.year < 2000 or d > now + timedelta(days=1): raise ValueError("timestamp out of range")
    return d

def parse_json(obj, now=None) -> dict:
    if not isinstance(obj, dict): raise ValueError("event must be a JSON object")
    for k in ("timestamp", "event_type", "message", "hostname"):
        if not obj.get(k): raise ValueError(f"missing required field: {k}")
    et = str(obj["event_type"])
    if not TYPE_RE.match(et): raise ValueError("invalid event_type")
    sev = obj.get("severity", 0)
    if isinstance(sev, str): sev = SEV_WORDS.get(sev.lower(), -1)
    if isinstance(sev, bool) or not isinstance(sev, int) or not 0 <= sev <= 10: raise ValueError("severity must be 0-10")
    return dict(timestamp=_ts(obj["timestamp"], now), hostname=clean(obj["hostname"], 100), event_type=et,
                severity=sev, src_ip=_ip(obj.get("src_ip")), dst_ip=_ip(obj.get("dst_ip")),
                username=clean(obj["user"], 100) if obj.get("user") else None, message=clean(obj["message"]))

_R5424 = re.compile(r"^<(\d{1,3})>(\d)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(-|\[.*?\])\s*(.*)$")
_R3164 = re.compile(r"^<(\d{1,3})>([A-Z][a-z]{2})\s+(\d{1,2})\s+(\d\d):(\d\d):(\d\d)\s+(\S+)\s+(.*)$")
_FAIL = re.compile(r"Failed password for (?:invalid user )?(\S+) from (\S+)")
_OK = re.compile(r"Accepted \S+ for (\S+) from (\S+)")
_FW = re.compile(r"SRC=(\S+) DST=(\S+)")

def _infer(msg):
    if m := _FAIL.search(msg): return "auth.failure", m[1], m[2], None
    if m := _OK.search(msg): return "auth.success", m[1], m[2], None
    if (m := _FW.search(msg)) and "DPT=" in msg: return "net.fw", None, m[1], m[2]
    if "sudo:" in msg and "COMMAND=" in msg: return "priv.sudo", None, None, None
    return "syslog.message", None, None, None

def parse_syslog(line: str, now=None) -> dict:
    now = now or utcnow(); line = line.strip()
    if m := _R5424.match(line):
        pri, _, ts, host, *_, msg = m.groups(); when = _ts(ts, now)
    elif m := _R3164.match(line):
        pri, mon, day, hh, mm, ss, host, msg = m.groups()
        if mon not in MONTHS: raise ValueError("invalid syslog month")
        try: when = datetime(now.year, MONTHS[mon], int(day), int(hh), int(mm), int(ss))
        except ValueError: raise ValueError("invalid syslog timestamp")
        if when > now + timedelta(days=1): when = when.replace(year=now.year - 1)
    else: raise ValueError("unrecognised syslog format")
    if int(pri) > 191: raise ValueError("invalid syslog priority")
    et, user, src, dst = _infer(msg)
    def ip_or_none(v):
        try: return _ip(v)
        except ValueError: return None
    return dict(timestamp=when, hostname=clean(host, 100), event_type=et, severity=round((7 - int(pri) % 8) * 10 / 7),
                src_ip=ip_or_none(src), dst_ip=ip_or_none(dst), username=clean(user, 100) if user else None,
                message=clean(msg))

def normalize(q: QueueItem) -> tuple[dict, str]:
    """Return (normalised fields, raw text). Raises ValueError for malformed input."""
    if len(q.payload) > MAX_RAW: raise ValueError("event exceeds maximum size")
    if q.fmt == "syslog": return parse_syslog(q.payload, q.received_at), q.payload
    try: obj = json.loads(q.payload)
    except ValueError: raise ValueError("not valid JSON")
    return parse_json(obj, q.received_at), json.dumps(obj, sort_keys=True)

def enqueue(db, items, fmt, source_id, source_type, origin):
    now = utcnow()
    for it in items:
        db.add(QueueItem(source_id=source_id, source_type=source_type, origin=origin, fmt=fmt, received_at=now,
                         payload=it if isinstance(it, str) else json.dumps(it)))

def process_queue(db, batch=500) -> int:
    """One atomic batch. Any unexpected error rolls the whole batch back, leaving items pending (nothing lost)."""
    rows = db.scalars(select(QueueItem).where(QueueItem.status == "pending").order_by(QueueItem.id).limit(batch).with_for_update(skip_locked=True)).all()  # PostgreSQL: parallel workers never claim the same rows
    if not rows: return 0
    counts = {"accepted": 0, "quarantined": 0, "duplicates": 0}; seen, last_seen = set(), {}
    cutoff = utcnow() - timedelta(seconds=settings.dedup_seconds)
    try:
        assets = {}
        for q in rows:
            try: f, raw = normalize(q)
            except ValueError as e:
                db.add(Quarantine(source_id=q.source_id, reason=str(e)[:200], payload=q.payload[:2000]))
                counts["quarantined"] += 1; q.status = "done"; continue
            h = hashlib.sha256(raw.encode()).hexdigest(); q.status = "done"
            if h in seen or db.scalar(select(Event.id).where(Event.hash == h, Event.received_at > cutoff).limit(1)):
                counts["duplicates"] += 1; continue  # counted, not stored twice (section 6.6)
            seen.add(h)
            if f["hostname"] not in assets:
                assets[f["hostname"]] = db.scalar(select(Asset.id).where(Asset.hostname == f["hostname"]))
            db.add(Event(id=str(uuid.uuid4()), asset_id=assets[f["hostname"]], source_id=q.source_id,
                         received_at=q.received_at, source_type=q.source_type, raw=raw, hash=h,
                         data_origin=q.origin, **f))
            counts["accepted"] += 1
            if q.source_id: last_seen[q.source_id] = q.received_at
        for sid, ts in last_seen.items():
            if (src := db.get(LogSource, sid)): src.last_seen = ts  # source may have been deleted while items were queued
        for k, n in counts.items():
            if n: metrics.bump(db, k, n)
        db.commit()
    except Exception:
        db.rollback(); raise
    return len(rows)

def start_background():
    """Start queue worker (and optional syslog listener). Returns list of stop callables."""
    stoppers = []
    if settings.ingest_worker:
        stop = threading.Event()
        def loop():
            while not stop.is_set():
                n = 0
                try:
                    from . import detect, notify, maintenance
                    from .hub import hub
                    with SessionLocal() as db:
                        n = process_queue(db) + detect.process_new(db, on_alerts=hub.publish_alerts)
                        notify.escalate(db); n += notify.deliver_pending(db); maintenance.tick(db)
                except Exception: logging.getLogger("cybershield").exception("worker pass failed; batch rolled back, will retry")
                if not n: stop.wait(0.5)
        threading.Thread(target=loop, daemon=True).start(); stoppers.append(stop.set)
    if settings.syslog_port and settings.syslog_source:
        from .syslog_listener import start
        stoppers.append(start(settings.syslog_port, settings.syslog_source, settings.syslog_host))
    return stoppers
