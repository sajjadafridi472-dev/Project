import csv, io, ipaddress, json, re
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from . import audit, detect, ingest
from .db import get_db
from .main import require, ip_of
from .models import Alert, AlertEvent, AlertNote, Asset, Event, IOC, Rule, RuleVersion, Suppression, utcnow

router = APIRouter(prefix="/api/v1")

def _alert(a, full=False, db=None):
    x = json.loads(a.explanation or "{}")
    d = {"id": a.id, "title": a.title, "severity": a.severity, "risk_score": a.risk_score, "status": a.status,
         "entity": a.entity, "hostname": a.hostname, "occurrence_count": a.occurrence_count, "mitre": a.mitre,
         "rules": [r["name"] for r in x.get("rules", [])], "created_at": a.created_at, "last_event_at": a.last_event_at}
    if full:
        d["notes"] = [{"user": n.username, "text": n.text, "created_at": n.created_at}
                      for n in db.scalars(select(AlertNote).where(AlertNote.alert_id == a.id).order_by(AlertNote.id))]
        d.update(owner_id=a.owner_id, acknowledged_at=a.acknowledged_at, escalated=a.escalated)
        asset = db.scalar(select(Asset).where(Asset.hostname == a.hostname))
        ids = list(db.scalars(select(AlertEvent.event_id).where(AlertEvent.alert_id == a.id).limit(100)))
        d.update(explanation=x, trigger_latency_ms=a.trigger_latency_ms,
                 enrichment={"asset_owner": asset.owner if asset else None, "asset_criticality": asset.criticality if asset else None,
                             "ioc_matches": x.get("iocs", [])},
                 events=[{"id": e.id, "timestamp": e.timestamp, "event_type": e.event_type, "source_type": e.source_type,
                          "src_ip": e.src_ip, "message": e.message, "data_origin": e.data_origin}
                         for e in db.scalars(select(Event).where(Event.id.in_(ids)).order_by(Event.timestamp))])
    return d

@router.get("/alerts")
def list_alerts(status: str | None = None, severity: str | None = None, updated_after: str | None = None, limit: int = 100,
                user=Depends(require("dashboard")), db=Depends(get_db)):
    q = select(Alert).order_by(Alert.risk_score.desc(), Alert.id.desc()).limit(min(max(limit, 1), 500))
    if status: q = q.where(Alert.status == status)
    if severity: q = q.where(Alert.severity == severity)
    if updated_after:  # polling fallback for the live feed (SRS 5.4)
        try: dt = datetime.fromisoformat(updated_after.replace("Z", "+00:00"))
        except ValueError: raise HTTPException(422, "updated_after must be ISO 8601")
        q = q.where(Alert.updated_at > (dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt))
    return [_alert(a) for a in db.scalars(q)]

@router.get("/alerts/{aid}")
def get_alert(aid: int, user=Depends(require("dashboard")), db=Depends(get_db)):
    a = db.get(Alert, aid)
    if not a: raise HTTPException(404, "Alert not found")
    return _alert(a, True, db)

def _rule(r, versions=False, db=None):
    d = {"id": r.id, "name": r.name, "severity": r.severity, "enabled": r.enabled, "version": r.version, "logic": json.loads(r.logic)}
    if versions: d["history"] = [{"version": v.version, "name": v.name, "severity": v.severity, "changed_at": v.changed_at, "logic": json.loads(v.logic)}
                                 for v in db.scalars(select(RuleVersion).where(RuleVersion.rule_id == r.id).order_by(RuleVersion.version))]
    return d

class RuleIn(BaseModel):
    name: str = Field(min_length=3, max_length=100, pattern=r"^[A-Za-z0-9 /_.()'-]+$")
    severity: str = Field(pattern="^(Low|Medium|High|Critical)$")
    logic: dict

def _checked(logic):
    try: return detect.validate_logic(logic)
    except ValueError as e: raise HTTPException(422, f"Invalid rule: {e}")

@router.get("/rules")
def list_rules(user=Depends(require("rules")), db=Depends(get_db)): return [_rule(r) for r in db.scalars(select(Rule).order_by(Rule.id))]

@router.get("/rules/{rid}")
def get_rule(rid: int, user=Depends(require("rules")), db=Depends(get_db)):
    r = db.get(Rule, rid)
    if not r: raise HTTPException(404, "Rule not found")
    return _rule(r, True, db)

@router.post("/rules", status_code=201)
def create_rule(b: RuleIn, request: Request, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    _checked(b.logic)
    if db.scalar(select(Rule).where(Rule.name == b.name)): raise HTTPException(409, "Rule name exists")
    r = Rule(name=b.name, severity=b.severity, logic=json.dumps(b.logic), created_by=user.id); db.add(r); db.flush()
    db.add(RuleVersion(rule_id=r.id, version=1, name=r.name, logic=r.logic, severity=r.severity, changed_by=user.id))
    audit.log(db, "rule.create", user=user, obj=r.name, new=r.logic, ip=ip_of(request)); db.commit(); return _rule(r)

@router.put("/rules/{rid}")
def update_rule(rid: int, b: RuleIn, request: Request, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    r = db.get(Rule, rid)
    if not r: raise HTTPException(404, "Rule not found")
    _checked(b.logic)
    if b.name != r.name and db.scalar(select(Rule).where(Rule.name == b.name)): raise HTTPException(409, "Rule name exists")
    old = json.dumps({"name": r.name, "severity": r.severity, "logic": json.loads(r.logic), "version": r.version})
    r.name, r.severity, r.logic, r.version = b.name, b.severity, json.dumps(b.logic), r.version + 1  # live on next batch: no downtime (NFR-MNT-03)
    db.add(RuleVersion(rule_id=r.id, version=r.version, name=r.name, logic=r.logic, severity=r.severity, changed_by=user.id))
    audit.log(db, "rule.update", user=user, obj=r.name, old=old, new=r.logic, ip=ip_of(request)); db.commit(); return _rule(r)  # SR-13

class Toggle(BaseModel): enabled: bool

@router.patch("/rules/{rid}")
def toggle_rule(rid: int, b: Toggle, request: Request, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    r = db.get(Rule, rid)
    if not r: raise HTTPException(404, "Rule not found")
    audit.log(db, "rule.enable" if b.enabled else "rule.disable", user=user, obj=r.name, old=str(r.enabled), new=str(b.enabled), ip=ip_of(request))
    r.enabled = b.enabled; db.commit(); return _rule(r)

class TestIn(BaseModel):
    logic: dict
    events: list[dict] = Field(max_length=500)

@router.post("/rules/test")
def test_rule(b: TestIn, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    """Run a rule against sample events in memory; nothing is stored (FR-DET-09)."""
    L = _checked(b.logic); evs = []
    for i, raw in enumerate(b.events):
        try: f = ingest.parse_json(raw)
        except ValueError as e: raise HTTPException(422, f"event {i}: {e}")
        f.update(id=f"sample-{i}", source_type="api", user=None); f["received_at"] = utcnow(); evs.append(f)
    evs.sort(key=lambda e: e["timestamp"]); store = detect.DBStore(db)
    out = []
    for e in evs:
        r = detect.eval_rule(L, e, detect.ListStore(evs, store.iocs))
        if r: out.append({"event": e["id"], "summary": r.summary})
    return {"events": len(evs), "findings": out}

class SupIn(BaseModel):
    rule_id: int | None = None
    src_ip: str | None = Field(None, max_length=45)
    username: str | None = Field(None, max_length=100)
    hostname: str | None = Field(None, max_length=100)
    reason: str = Field(min_length=3, max_length=300)
    expires_in_days: int = Field(ge=1, le=90)

@router.get("/suppressions")
def list_sup(user=Depends(require("rules")), db=Depends(get_db)):
    return [{"id": s.id, "rule_id": s.rule_id, "src_ip": s.src_ip, "username": s.username, "hostname": s.hostname,
             "reason": s.reason, "expires_at": s.expires_at, "active": s.expires_at > utcnow()} for s in db.scalars(select(Suppression))]

@router.post("/suppressions", status_code=201)
def add_sup(b: SupIn, request: Request, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    if not (b.src_ip or b.username or b.hostname): raise HTTPException(422, "Specify at least one of src_ip, username, hostname")
    if b.src_ip:
        try: ipaddress.ip_address(b.src_ip)
        except ValueError: raise HTTPException(422, "Invalid src_ip")
    s = Suppression(rule_id=b.rule_id, src_ip=b.src_ip, username=b.username, hostname=b.hostname, reason=b.reason,
                    expires_at=utcnow() + timedelta(days=b.expires_in_days), created_by=user.id)
    db.add(s); db.flush(); audit.log(db, "suppression.create", user=user, obj=str(s.id), new=b.model_dump_json(), ip=ip_of(request))
    db.commit(); return {"id": s.id, "expires_at": s.expires_at}

@router.delete("/suppressions/{sid}")
def del_sup(sid: int, request: Request, user=Depends(require("rules", "RW")), db=Depends(get_db)):
    s = db.get(Suppression, sid)
    if not s: raise HTTPException(404, "Suppression not found")
    audit.log(db, "suppression.delete", user=user, obj=str(sid), old=f"{s.src_ip}/{s.username}/{s.hostname}", ip=ip_of(request)); db.delete(s); db.commit()
    return {"ok": True}

class IocImport(BaseModel): csv: str = Field(max_length=2_000_000)

@router.post("/iocs/import")
def import_iocs(b: IocImport, request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    """CSV: type,value,source,confidence,expires_at(optional ISO). STIX/TAXII import is not implemented."""
    ok = bad = 0; pending = {}
    for row in csv.reader(io.StringIO(b.csv)):
        try:
            if not row or row[0].strip().lower() == "type": continue
            t, v = row[0].strip().lower(), row[1].strip().lower()
            if t == "ip": v = str(ipaddress.ip_address(v))
            elif t == "domain" and not re.fullmatch(r"(?:[a-z0-9-]{1,63}\.)+[a-z]{2,24}", v): raise ValueError
            elif t == "hash" and not re.fullmatch(r"[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{64}", v): raise ValueError
            elif t not in ("ip", "domain", "hash"): raise ValueError
            conf = int(row[3]) if len(row) > 3 and row[3].strip() else 50
            exp = datetime.fromisoformat(row[4].strip().replace("Z", "+00:00")) if len(row) > 4 and row[4].strip() else None
            if exp and exp.tzinfo: exp = exp.astimezone(timezone.utc).replace(tzinfo=None)
            if not 0 <= conf <= 100: raise ValueError
            i = pending.get((t, v)) or db.scalar(select(IOC).where(IOC.type == t, IOC.value == v)) or IOC(type=t, value=v)
            i.source, i.confidence, i.expires_at = (row[2].strip()[:100] if len(row) > 2 else None), conf, exp; db.add(i); pending[(t, v)] = i; ok += 1
        except (ValueError, IndexError): bad += 1
    audit.log(db, "ioc.import", user=user, new=f"{ok} imported, {bad} rejected", ip=ip_of(request)); db.commit()
    return {"imported": ok, "rejected": bad}

@router.get("/iocs")
def list_iocs(user=Depends(require("system")), db=Depends(get_db)):
    return [{"id": i.id, "type": i.type, "value": i.value, "source": i.source, "confidence": i.confidence, "expires_at": i.expires_at}
            for i in db.scalars(select(IOC).order_by(IOC.id).limit(1000))]
