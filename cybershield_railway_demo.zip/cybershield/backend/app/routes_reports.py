import json
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from . import audit, rbac, report
from .config import settings
from .db import get_db
from .main import require, ip_of
from .models import Alert, AuditLog, Event, Incident, IncidentAlert, IOC, LogSource, ReportSchedule, Role, Rule, User, utcnow
from .routes_incidents import _metrics, _detected

router = APIRouter(prefix="/api/v1")

@router.get("/reports/schedules")
def my_schedules(user=Depends(require("reports", "RW")), db=Depends(get_db)):
    return [{"id": s.id, "period": s.period, "format": s.format, "last_run_at": s.last_run_at} for s in db.scalars(select(ReportSchedule).where(ReportSchedule.user_id == user.id))]

class SchedIn(BaseModel):
    period: str = Field(pattern="^(daily|weekly|monthly)$")
    format: str = Field(pattern="^(pdf|csv)$")

@router.post("/reports/schedules", status_code=201)
def add_schedule(b: SchedIn, request: Request, user=Depends(require("reports", "RW")), db=Depends(get_db)):
    if db.scalar(select(ReportSchedule).where(ReportSchedule.user_id == user.id, ReportSchedule.period == b.period, ReportSchedule.format == b.format)): raise HTTPException(409, "You already have this schedule")
    s = ReportSchedule(user_id=user.id, period=b.period, format=b.format); db.add(s); db.flush()
    audit.log(db, "report.schedule_create", user=user, obj=str(s.id), new=f"{b.period}/{b.format}", ip=ip_of(request)); db.commit(); return {"id": s.id}

@router.delete("/reports/schedules/{sid}")
def del_schedule(sid: int, request: Request, user=Depends(require("reports", "RW")), db=Depends(get_db)):
    s = db.get(ReportSchedule, sid)
    if not s or s.user_id != user.id: raise HTTPException(404, "Schedule not found")  # only your own
    audit.log(db, "report.schedule_delete", user=user, obj=str(sid), ip=ip_of(request)); db.delete(s); db.commit(); return {"ok": True}

@router.get("/reports/{rtype}")
def get_report(rtype: str, period: str = "weekly", format: str = "json", end: str | None = None, request: Request = None, user=Depends(require("reports")), db=Depends(get_db)):
    """Preview (JSON) needs read access; PDF/CSV export needs write access (SRS 7.8: Manager and Auditor RW, Analyst and Admin R)."""
    if rtype != "summary": raise HTTPException(404, "Unknown report type. Available: summary")
    if period not in report.SPANS: raise HTTPException(422, "period must be daily, weekly or monthly")
    if format not in ("json", "csv", "pdf"): raise HTTPException(422, "format must be json, csv or pdf")
    if format != "json" and not rbac.allowed(user.role.name, "reports", "RW"): raise HTTPException(403, "Your role can view reports but not export them")
    e = None
    if end:
        try: e = datetime.fromisoformat(end.replace("Z", "+00:00")); e = e.astimezone(timezone.utc).replace(tzinfo=None) if e.tzinfo else e
        except ValueError: raise HTTPException(422, "end must be ISO 8601")
    d = report.build(db, period, e)
    if format == "json": return d
    audit.log(db, "report.export", user=user, obj=f"{rtype}/{period}", new=format, ip=ip_of(request)); db.commit()
    body, ct = (report.to_pdf(d), "application/pdf") if format == "pdf" else (report.to_csv(d).encode(), "text/csv")
    return Response(body, media_type=ct, headers={"Content-Disposition": f'attachment; filename="cybershield-{rtype}-{period}-{d["end"]:%Y-%m-%d}.{format}"', "X-Content-Type-Options": "nosniff"})

def _ev(**k): return k

@router.get("/compliance/{framework}")
def compliance(framework: str, user=Depends(require("reports")), db=Depends(get_db)):
    """FR-RPT-04 (Could): live evidence per control. Design-intent alignment only, not certification (SRS 7.10)."""
    if framework not in ("iso27001", "nist_csf"): raise HTTPException(404, "Framework must be iso27001 or nist_csf")
    now = utcnow(); d30 = now - timedelta(days=30); c = lambda q: db.scalar(q)
    users = c(select(func.count()).where(User.status == "active")); mfa = c(select(func.count()).where(User.status == "active", User.mfa_enabled == True))  # noqa: E712
    ev = {"access": _ev(roles=db.scalar(select(func.count(Role.id))), active_users=users, users_with_mfa=mfa, privileged_mfa_enforced=True, session_idle_minutes=settings.idle_minutes, lockout_after_failures=settings.max_failed),
          "audit": _ev(entries_last_30d=c(select(func.count()).where(AuditLog.timestamp > d30)), tamper_evident_chain=True, never_deleted_by_application=True),
          "monitoring": _ev(active_or_pending_sources=c(select(func.count()).where(LogSource.status != "disabled")), enabled_rules=c(select(func.count()).where(Rule.enabled == True)), events_last_30d=c(select(func.count()).where(Event.timestamp > d30)), alerts_last_30d=c(select(func.count()).where(Alert.created_at > d30))),  # noqa: E712
          "incidents": _ev(total=c(select(func.count(Incident.id))), closed_or_resolved=c(select(func.count()).where(Incident.status.in_(("Resolved", "Closed")))), playbooks_available=5),
          "crypto": _ev(hash_algorithm="Argon2id", config_backup_encryption="AES-256-GCM (scrypt)", tls="Enforced by the deployment reverse proxy; not verifiable by this application"),
          "backup": _ev(backups_created=c(select(func.count()).where(AuditLog.action == "backup.create")), last_backup=c(select(func.max(AuditLog.timestamp)).where(AuditLog.action == "backup.create")))}
    ok = lambda k, cond: "evidence available" if cond else "gap"
    if framework == "iso27001":
        ctl = [("A.5.15", "Access control", "access", ev["access"]["roles"] >= 4), ("A.8.5", "Secure authentication", "access", mfa > 0), ("A.8.15", "Logging", "audit", ev["audit"]["entries_last_30d"] > 0),
               ("A.8.16", "Monitoring activities", "monitoring", ev["monitoring"]["enabled_rules"] > 0 and ev["monitoring"]["active_or_pending_sources"] > 0), ("A.5.24-A.5.26", "Incident management", "incidents", ev["incidents"]["total"] > 0),
               ("A.8.24", "Use of cryptography", "crypto", True), ("A.8.13", "Information backup", "backup", ev["backup"]["backups_created"] > 0)]
    else:
        ctl = [("PR.AA", "Identity management, authentication and access control", "access", mfa > 0), ("DE.CM", "Continuous monitoring", "monitoring", ev["monitoring"]["active_or_pending_sources"] > 0),
               ("DE.AE", "Adverse event analysis", "monitoring", ev["monitoring"]["enabled_rules"] > 0), ("RS.MA", "Incident management", "incidents", ev["incidents"]["total"] > 0),
               ("PR.DS", "Data security (encryption, backup)", "backup", ev["backup"]["backups_created"] > 0), ("GV.OV", "Oversight: audit trail of decisions", "audit", ev["audit"]["entries_last_30d"] > 0)]
    return {"framework": framework, "generated_at": now, "disclaimer": "Mapping of design intent to live evidence. It is not certification or legal advice. A 'gap' means no evidence was found in this system.",
            "controls": [{"id": i, "title": t, "status": ok(k, cond), "evidence": ev[k]} for i, t, k, cond in ctl]}
