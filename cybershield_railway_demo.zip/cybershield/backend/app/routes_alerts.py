import asyncio, logging
from fastapi import APIRouter, Depends, HTTPException, Request, WebSocket
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from . import audit, rbac
from .db import SessionLocal, get_db
from .hub import hub
from .main import require, ip_of, resolve_session
from .models import Alert, AlertNote, User, utcnow
from .routes_detect import _alert

router = APIRouter(prefix="/api/v1"); log = logging.getLogger("cybershield")

class TriageIn(BaseModel):
    status: str | None = Field(None, pattern="^(Open|Investigating|Resolved|False Positive)$")
    note: str | None = Field(None, min_length=1, max_length=2000)

@router.patch("/alerts/{aid}")
def triage(aid: int, b: TriageIn, request: Request, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    """UC-04: analyst decides false positive / investigating / resolved, optionally with a note."""
    a = db.get(Alert, aid)
    if not a: raise HTTPException(404, "Alert not found")
    if not b.status and not b.note: raise HTTPException(422, "Provide a status or a note")
    if a.owner_id not in (None, user.id) and a.status == "Investigating":  # UC-04 exception: prevent duplicate work
        o = db.get(User, a.owner_id); raise HTTPException(409, f"Already being handled by {o.username if o else 'another analyst'}")
    now, old = utcnow(), a.status
    if b.status and b.status != old:
        a.status = b.status
        if b.status != "Open" and (a.owner_id is None or old == "Open"): a.owner_id = user.id  # whoever picks up an open alert owns it
        if a.acknowledged_at is None and b.status != "Open": a.acknowledged_at = now
        audit.log(db, "alert.status", user=user, obj=str(a.id), old=old, new=b.status, ip=ip_of(request))
    if b.note:
        db.add(AlertNote(alert_id=a.id, user_id=user.id, username=user.username, text=b.note))
        if a.acknowledged_at is None: a.acknowledged_at = now
        audit.log(db, "alert.note", user=user, obj=str(a.id), ip=ip_of(request))
    a.updated_at = now; db.commit()
    out = _alert(a, True, db); hub.publish({"type": "alert", "alert": jsonable_encoder(_alert(a))}); return out

@router.websocket("/ws")
async def live_alerts(ws: WebSocket):
    """Live alert feed (FR-ALR-02). Auth is the first message {"token": ...}; tokens never appear in URLs.
    Re-validated every 30 s WITHOUT refreshing the idle timer, so an unattended socket ends with the session."""
    await ws.accept()
    try:
        token = str((await asyncio.wait_for(ws.receive_json(), 5)).get("token", ""))
        with SessionLocal() as db:
            if not rbac.allowed(resolve_session(db, token, touch=False).role.name, "dashboard"): raise PermissionError
    except Exception:
        await ws.close(code=4401); return
    q = hub.subscribe()
    try:
        await ws.send_json({"type": "hello"})
        while True:
            try: await ws.send_json(await asyncio.wait_for(q.get(), 30))
            except asyncio.TimeoutError:
                with SessionLocal() as db: resolve_session(db, token, touch=False)
                await ws.send_json({"type": "ping"})
    except Exception: log.debug("live feed socket ended", exc_info=True)  # normal on client disconnect or expired session
    finally:
        hub.unsubscribe(q)
        try: await ws.close()
        except Exception: log.debug("socket already closed")
