"""Response executor (FR-INC-06, Could). No firewall connector exists in this build, so approved actions are recorded
but NOT executed. A real connector would replace execute() and must only ever be called after Manager approval."""
def execute(action: str, target: str) -> tuple[str, str]:
    return "not_executed", f"Approved, but no firewall connector is configured; '{action} {target}' was not carried out (dry run)."
