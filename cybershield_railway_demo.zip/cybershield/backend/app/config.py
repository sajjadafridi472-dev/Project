import os
from dataclasses import dataclass

def _i(name, default): return int(os.environ.get(name, default))

def normalize_db_url(url: str) -> str:
    """Cloud hosts hand out postgres:// or postgresql:// URLs; the application uses the psycopg 3 driver."""
    for old in ("postgres://", "postgresql://"):
        if url.startswith(old): return "postgresql+psycopg://" + url[len(old):]
    return url

@dataclass(frozen=True)
class Settings:
    database_url: str = normalize_db_url(os.environ.get("DATABASE_URL", "sqlite:///./cybershield.db"))
    session_hours: int = _i("SESSION_HOURS", 8)          # SR-04
    idle_minutes: int = _i("IDLE_MINUTES", 15)           # FR-AUTH-06
    lock_minutes: int = _i("LOCK_MINUTES", 15)           # FR-AUTH-05
    max_failed: int = _i("MAX_FAILED_LOGINS", 5)         # FR-AUTH-05
    ingest_worker: int = _i("INGEST_WORKER", 1)
    ingest_rate: int = _i("INGEST_RATE_PER_MIN", 600)   # per source (SR-17)
    dedup_seconds: int = _i("DEDUP_SECONDS", 60)        # section 6.6
    silent_minutes: int = _i("SILENT_MINUTES", 10)      # FR-COL-08
    syslog_port: int = _i("SYSLOG_PORT", 0)             # 0 = listener disabled
    syslog_host: str = os.environ.get("SYSLOG_HOST", "127.0.0.1")
    syslog_source: str = os.environ.get("SYSLOG_SOURCE", "")  # registered syslog source that owns this listener
    correlation_minutes: int = _i("CORRELATION_MINUTES", 30)  # FR-DET-07 / FR-ALR-05 window
    smtp_host: str = os.environ.get("SMTP_HOST", "")
    smtp_port: int = _i("SMTP_PORT", 587)
    smtp_user: str = os.environ.get("SMTP_USER", "")
    smtp_password: str = os.environ.get("SMTP_PASSWORD", "")  # SR-08: supply from a secret store, never commit
    smtp_from: str = os.environ.get("SMTP_FROM", "cybershield@localhost")
    smtp_starttls: int = _i("SMTP_STARTTLS", 1)
    webhook_url: str = os.environ.get("WEBHOOK_URL", "")       # Critical alerts (FR-ALR-04, webhook only; SMS not built)
    escalation_minutes: int = _i("ESCALATION_MINUTES", 15)     # FR-ALR-07
    public_url: str = os.environ.get("PUBLIC_URL", "http://localhost:5173")
    setup_token: str = os.environ.get("SETUP_TOKEN", "")  # optional one-time bootstrap gate for public deployments
    geoip_csv: str = os.environ.get("GEOIP_CSV", "")  # optional: cidr,country,lat,lon (none is bundled)
    archive_dir: str = os.environ.get("ARCHIVE_DIR", "./archive")  # compressed archive files (not searchable)
    dashboard_cache_seconds: int = _i("DASHBOARD_CACHE_SECONDS", 5)  # shared by all users; 0 disables
    rate_limit: int = _i("RATE_LIMIT_PER_MIN", 20)       # SR-17

settings = Settings()
