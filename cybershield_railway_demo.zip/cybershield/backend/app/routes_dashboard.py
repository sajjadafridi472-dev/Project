import ipaddress, json, re, threading, time
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from . import audit, geo
from .config import settings
from .db import get_db
from .main import require, ip_of
from .models import Alert, Asset, Event, Incident, LogSource, utcnow
from .routes_ingest import _view as source_view

router = APIRouter(prefix="/api/v1")
OPEN = ("Open", "Investigating")
_cache, _lock = {}, threading.Lock()

def cache_clear():
    with _lock: _cache.clear()

def cached(key, ttl, fn):
    """Short shared cache for the two aggregates that scan the whole events table. Every dashboard user shares one computation."""
    if ttl <= 0: return fn()
    now = time.monotonic()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < ttl: return hit[1]
    v = fn()
    with _lock: _cache[key] = (now, v)
    return v
SEVS = ("Critical", "High", "Medium", "Low")
LANDING = {"Security Analyst": "alerts", "Manager": "dashboard", "Auditor": "audit", "Administrator": "admin"}  # FR-DSH-06

@router.get("/dashboard/summary")
def summary(user=Depends(require("dashboard")), db=Depends(get_db)):
    now = utcnow(); is_open = Alert.status.in_(OPEN)
    sev = dict(db.execute(select(Alert.severity, func.count()).where(is_open).group_by(Alert.severity)).all())
    vol = cached("volume", settings.dashboard_cache_seconds, lambda: (dict(db.execute(select(Event.data_origin, func.count()).group_by(Event.data_origin)).all()),
                 db.scalar(select(func.count()).where(Event.timestamp > now - timedelta(hours=24)))))
    origin, events_24h = vol
    assets = db.execute(select(Alert.hostname, func.count(), func.max(Alert.risk_score)).where(is_open, Alert.hostname.isnot(None))
                        .group_by(Alert.hostname).order_by(func.count().desc(), func.max(Alert.risk_score).desc()).limit(5)).all()
    srcs = db.execute(select(Alert.entity, func.count(), func.max(Alert.risk_score)).where(is_open, Alert.entity.like("src_ip:%"))
                      .group_by(Alert.entity).order_by(func.max(Alert.risk_score).desc()).limit(5)).all()
    st = [source_view(s)["status"] for s in db.scalars(select(LogSource))]
    return {"landing": LANDING[user.role.name],
            "alerts_open_by_severity": {s: sev.get(s, 0) for s in SEVS},
            "unacknowledged_critical": db.scalar(select(func.count()).where(Alert.severity == "Critical", Alert.status == "Open", Alert.acknowledged_at.is_(None))),
            "events_total": sum(origin.values()), "events_24h": events_24h,
            "events_by_origin": {o: origin.get(o, 0) for o in ("live", "imported", "simulated")},
            "open_incidents": db.scalar(select(func.count()).where(Incident.status.notin_(("Resolved", "False Positive", "Closed")))),
            "top_assets": [{"hostname": h, "open_alerts": n, "max_risk": r} for h, n, r in assets],
            "top_sources": [{"ip": e[7:], "open_alerts": n, "max_risk": r} for e, n, r in srcs],
            "source_health": {k: st.count(k) for k in ("active", "pending", "silent", "disabled")}}

PERIODS = {"1h": (timedelta(hours=1), 12), "24h": (timedelta(hours=24), 24), "7d": (timedelta(days=7), 28), "30d": (timedelta(days=30), 30)}

@router.get("/dashboard/trends")
def trends(period: str = "24h", user=Depends(require("dashboard")), db=Depends(get_db)):
    """FR-DSH-02. Bucket i covers (start, start+step]; each bucket carries the exact range so the UI can drill down (FR-DSH-07)."""
    if period not in PERIODS: raise HTTPException(422, f"period must be one of {sorted(PERIODS)}")
    def compute():
        span, n = PERIODS[period]; step = span / n; end = utcnow(); out = []
        for i in range(n):
            a, b = end - span + step * i, end - span + step * (i + 1)
            out.append({"start": a, "end": b, "events": db.scalar(select(func.count()).where(Event.timestamp > a, Event.timestamp <= b)),
                        "alerts": db.scalar(select(func.count()).where(Alert.created_at > a, Alert.created_at <= b))})
        return {"period": period, "buckets": out}
    return cached(("trends", period), settings.dashboard_cache_seconds * 2, compute)

def risk_of(asset, open_alerts):
    """Explainable asset risk (FR-DSH-05): highest open alert score + 2 per additional open alert, capped at 100; 0 if none.
    Asset criticality is NOT added again here because each alert score already includes it (see detect.risk_score)."""
    if not open_alerts: return 0
    return min(100, max(a.risk_score for a in open_alerts) + 2 * (len(open_alerts) - 1))

def _asset(a, by_host):
    oa = by_host.get(a.hostname, [])
    return {"id": a.id, "hostname": a.hostname, "ip_address": a.ip_address, "os": a.os, "owner": a.owner, "criticality": a.criticality,
            "tags": a.tags, "open_alerts": len(oa), "risk_score": risk_of(a, oa)}

def _by_host(db):
    d = {}
    for al in db.scalars(select(Alert).where(Alert.status.in_(OPEN), Alert.hostname.isnot(None))): d.setdefault(al.hostname, []).append(al)
    return d

class AssetIn(BaseModel):
    hostname: str = Field(min_length=1, max_length=100, pattern=r"^[A-Za-z0-9._-]+$")
    ip_address: str | None = Field(None, max_length=45)
    os: str | None = Field(None, max_length=60)
    owner: str | None = Field(None, max_length=100)
    criticality: int = Field(3, ge=1, le=5)
    tags: str | None = Field(None, max_length=200)

def _check_ip(v):
    if v:
        try: ipaddress.ip_address(v)
        except ValueError: raise HTTPException(422, "Invalid ip_address")

@router.get("/assets")
def list_assets(user=Depends(require("dashboard")), db=Depends(get_db)):
    bh = _by_host(db); return sorted((_asset(a, bh) for a in db.scalars(select(Asset))), key=lambda x: (-x["risk_score"], x["hostname"]))

@router.post("/assets", status_code=201)
def add_asset(b: AssetIn, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    _check_ip(b.ip_address)
    if db.scalar(select(Asset).where(Asset.hostname == b.hostname)): raise HTTPException(409, "Hostname already in inventory")
    a = Asset(**b.model_dump()); db.add(a); db.flush(); audit.log(db, "asset.create", user=admin, obj=a.hostname, new=b.model_dump_json(), ip=ip_of(request))
    db.commit(); return _asset(a, {})

@router.put("/assets/{aid}")
def edit_asset(aid: int, b: AssetIn, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    a = db.get(Asset, aid)
    if not a: raise HTTPException(404, "Asset not found")
    _check_ip(b.ip_address)
    if b.hostname != a.hostname and db.scalar(select(Asset).where(Asset.hostname == b.hostname)): raise HTTPException(409, "Hostname already in inventory")
    old = json.dumps({k: getattr(a, k) for k in b.model_dump()})
    for k, v in b.model_dump().items(): setattr(a, k, v)
    audit.log(db, "asset.update", user=admin, obj=a.hostname, old=old, new=b.model_dump_json(), ip=ip_of(request)); db.commit(); return _asset(a, _by_host(db))

@router.delete("/assets/{aid}")
def del_asset(aid: int, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    a = db.get(Asset, aid)
    if not a: raise HTTPException(404, "Asset not found")
    audit.log(db, "asset.delete", user=admin, obj=a.hostname, ip=ip_of(request)); db.delete(a); db.commit(); return {"ok": True}

@router.get("/dashboard/geo")
def geo_view(user=Depends(require("dashboard")), db=Depends(get_db)):
    if not settings.geoip_csv or not geo.load(settings.geoip_csv): return {"available": False, "sources": [], "note": "No GeoIP table configured (set GEOIP_CSV)."}
    rows = db.execute(select(Alert.entity, func.count()).where(Alert.status.in_(OPEN), Alert.entity.like("src_ip:%")).group_by(Alert.entity)).all()
    out = {}
    for e, n in rows:
        g = geo.lookup(settings.geoip_csv, e[7:])
        if g: d = out.setdefault(g["country"], {"country": g["country"], "lat": g["lat"], "lon": g["lon"], "open_alerts": 0}); d["open_alerts"] += n
    return {"available": True, "sources": sorted(out.values(), key=lambda x: -x["open_alerts"])}
