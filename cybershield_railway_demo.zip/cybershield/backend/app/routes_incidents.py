import base64, binascii, hashlib, ipaddress, re
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from . import audit, respond
from .db import get_db
from .hub import hub
from .main import require, ip_of
from .models import (Alert, AlertEvent, Event, Incident, IncidentAlert, IncidentAttachment, IncidentEntry, PlaybookItem,
                     ResponseAction, Role, User, utcnow)
from .playbooks import PLAYBOOKS

router = APIRouter(prefix="/api/v1")
STATES = ("New", "Investigating", "Contained", "Resolved", "False Positive", "Closed")
FLOW = {"New": {"Investigating", "False Positive"}, "Investigating": {"Contained", "Resolved", "False Positive"},
        "Contained": {"Investigating", "Resolved"}, "Resolved": {"Closed", "Investigating"},
        "False Positive": {"Closed", "Investigating"}, "Closed": set()}  # Closed is final: records stay intact
RANK = {"Low": 0, "Medium": 1, "High": 2, "Critical": 3}
TYPES = "^(brute_force|phishing|ransomware|malware|other)$"
ALLOWED_FILES = {"text/plain", "text/csv", "application/json", "application/pdf", "image/png", "image/jpeg"}
MAX_FILE = 1_000_000

def _secs(a, b): return None if not a or not b else max(0, int((b - a).total_seconds()))

def _metrics(i: Incident, detected_at):
    """Definitions: detected = earliest linked alert creation; TTD = detected - first event; TTA/TTC/TTR measured from detected (FR-INC-07)."""
    return {"time_to_detect_s": _secs(i.first_event_at, detected_at), "time_to_acknowledge_s": _secs(detected_at, i.acknowledged_at),
            "time_to_contain_s": _secs(detected_at, i.contained_at), "time_to_resolve_s": _secs(detected_at, i.resolved_at)}

def _detected(db, i): return db.scalar(select(func.min(Alert.created_at)).join(IncidentAlert, IncidentAlert.alert_id == Alert.id).where(IncidentAlert.incident_id == i.id))

def _log(db, i, user, kind, text="", old=None, new=None):
    db.add(IncidentEntry(incident_id=i.id, user_id=user.id, username=user.username, kind=kind, text=text[:4000], old_value=old, new_value=new))

def _owner(db, i): return db.get(User, i.owner_id).username if i.owner_id and db.get(User, i.owner_id) else None

def _row(db, i):
    return {"id": i.id, "title": i.title, "status": i.status, "severity": i.severity, "incident_type": i.incident_type, "owner": _owner(db, i),
            "created_at": i.created_at, "false_positive": i.false_positive, **_metrics(i, _detected(db, i))}

def _publish(db, i): hub.publish({"type": "incident", "incident": jsonable_encoder(_row(db, i))})

def _link(db, i, alerts):
    for a in alerts: db.add(IncidentAlert(incident_id=i.id, alert_id=a.id))
    db.flush(); ids = list(db.scalars(select(IncidentAlert.alert_id).where(IncidentAlert.incident_id == i.id)))
    i.first_event_at = db.scalar(select(func.min(Event.timestamp)).join(AlertEvent, AlertEvent.event_id == Event.id).where(AlertEvent.alert_id.in_(ids)))
    i.severity = max((a.severity for a in db.scalars(select(Alert).where(Alert.id.in_(ids)))), key=RANK.get)

class IncidentIn(BaseModel):
    alert_ids: list[int] = Field(min_length=1, max_length=50)
    title: str | None = Field(None, min_length=3, max_length=200)
    incident_type: str | None = Field(None, pattern=TYPES)

def _guess_type(alerts):
    names = " ".join(a.title for a in alerts).lower()
    return "brute_force" if "brute" in names else "malware" if "malicious indicator" in names else "other"

def _get(db, iid):
    i = db.get(Incident, iid)
    if not i: raise HTTPException(404, "Incident not found")
    return i

@router.post("/incidents", status_code=201)
def create_incident(b: IncidentIn, request: Request, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    """FR-INC-01: one call converts one or more alerts into a case (UC-04 step 4)."""
    ids = list(dict.fromkeys(b.alert_ids)); alerts = db.scalars(select(Alert).where(Alert.id.in_(ids))).all()
    if len(alerts) != len(ids): raise HTTPException(404, "One or more alerts not found")
    alerts = sorted(alerts, key=lambda a: ids.index(a.id))
    for a in alerts:
        if a.status == "False Positive": raise HTTPException(409, f"Alert {a.id} is marked False Positive")
        used = db.scalar(select(IncidentAlert.incident_id).where(IncidentAlert.alert_id == a.id))
        if used: raise HTTPException(409, f"Alert {a.id} already belongs to incident {used}")
    typ = b.incident_type or _guess_type(alerts)
    i = Incident(title=b.title or alerts[0].title, status="New", owner_id=user.id, incident_type=typ); db.add(i); db.flush()
    _link(db, i, alerts)
    for pos, (phase, text) in enumerate(PLAYBOOKS[typ], 1): db.add(PlaybookItem(incident_id=i.id, position=pos, phase=phase, text=text))
    now = utcnow()
    for a in alerts:
        a.updated_at = now
        if a.status == "Open": a.status = "Investigating"
        if a.owner_id is None: a.owner_id = user.id
        if a.acknowledged_at is None: a.acknowledged_at = now
    _log(db, i, user, "created", f"Created from alert(s) {ids}"); audit.log(db, "incident.create", user=user, obj=str(i.id), new=f"alerts {ids}", ip=ip_of(request))
    db.commit(); _publish(db, i); return _row(db, i)

@router.get("/incidents/metrics")
def incident_metrics(days: int = 30, user=Depends(require("triage")), db=Depends(get_db)):
    since = utcnow() - timedelta(days=min(max(days, 1), 3650)); rows = db.scalars(select(Incident).where(Incident.created_at >= since)).all()
    ms = [(i, _metrics(i, _detected(db, i))) for i in rows]; mean = lambda k, sel: (round(sum(m[k] for i, m in sel if m[k] is not None) / n) if (n := sum(1 for i, m in sel if m[k] is not None)) else None)
    real = [x for x in ms if not x[0].false_positive]
    return {"period_days": days, "incidents": len(rows), "by_status": {s: sum(1 for i in rows if i.status == s) for s in STATES},
            "MTTD_s": mean("time_to_detect_s", real), "mean_time_to_acknowledge_s": mean("time_to_acknowledge_s", real),
            "mean_time_to_contain_s": mean("time_to_contain_s", real), "MTTR_s": mean("time_to_resolve_s", real),
            "definition": "MTTD = mean(first alert created - first linked event); MTTR = mean(resolved - first alert created); false positives excluded"}

@router.get("/incidents")
def list_incidents(status: str | None = None, owner: str | None = None, limit: int = 200, user=Depends(require("triage")), db=Depends(get_db)):
    q = select(Incident).order_by(Incident.id.desc()).limit(min(max(limit, 1), 500))
    if status: q = q.where(Incident.status == status)
    if owner: q = q.join(User, User.id == Incident.owner_id).where(User.username == owner)
    return [_row(db, i) for i in db.scalars(q)]

@router.get("/incidents/{iid}")
def get_incident(iid: int, user=Depends(require("triage")), db=Depends(get_db)):
    i = _get(db, iid); d = _row(db, i)
    d.update(description=i.description, first_event_at=i.first_event_at, acknowledged_at=i.acknowledged_at, contained_at=i.contained_at,
             resolved_at=i.resolved_at, closed_at=i.closed_at,
             alerts=[{"id": a.id, "title": a.title, "severity": a.severity, "status": a.status} for a in db.scalars(select(Alert).join(IncidentAlert, IncidentAlert.alert_id == Alert.id).where(IncidentAlert.incident_id == iid))],
             timeline=[{"kind": e.kind, "user": e.username, "text": e.text, "old": e.old_value, "new": e.new_value, "at": e.created_at}
                       for e in db.scalars(select(IncidentEntry).where(IncidentEntry.incident_id == iid).order_by(IncidentEntry.id))],
             playbook=[{"id": p.id, "phase": p.phase, "text": p.text, "done": p.done, "done_by": p.done_by, "done_at": p.done_at}
                       for p in db.scalars(select(PlaybookItem).where(PlaybookItem.incident_id == iid).order_by(PlaybookItem.position))],
             attachments=[{"id": a.id, "filename": a.filename, "content_type": a.content_type, "size": a.size, "sha256": a.sha256}
                          for a in db.scalars(select(IncidentAttachment).where(IncidentAttachment.incident_id == iid))],
             responses=[{"id": r.id, "action": r.action, "target": r.target, "status": r.status, "proposed_by": r.proposed_by, "decided_by": r.decided_by, "result": r.result}
                        for r in db.scalars(select(ResponseAction).where(ResponseAction.incident_id == iid))])
    return d

class IncidentPatch(BaseModel):
    status: str | None = Field(None, pattern="^(New|Investigating|Contained|Resolved|False Positive|Closed)$")
    owner: str | None = Field(None, max_length=50)
    title: str | None = Field(None, min_length=3, max_length=200)
    description: str | None = Field(None, max_length=4000)

@router.patch("/incidents/{iid}")
def update_incident(iid: int, b: IncidentPatch, request: Request, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid); now = utcnow(); ip = ip_of(request)
    if b.owner:  # FR-INC-03: only active analysts can own cases
        o = db.scalar(select(User).join(Role, Role.id == User.role_id).where(User.username == b.owner, User.status == "active", Role.name == "Security Analyst"))
        if not o: raise HTTPException(422, "Owner must be an active Security Analyst")
        if o.id != i.owner_id:
            _log(db, i, user, "assign", old=_owner(db, i), new=o.username); audit.log(db, "incident.assign", user=user, obj=str(i.id), old=_owner(db, i), new=o.username, ip=ip); i.owner_id = o.id
    if b.title and b.title != i.title: _log(db, i, user, "note", f"Title changed from '{i.title}'"); i.title = b.title
    if b.description is not None: i.description = b.description
    if b.status and b.status != i.status:
        old = i.status
        if b.status not in FLOW[old]: raise HTTPException(409, f"Cannot move from {old} to {b.status}. Allowed: {sorted(FLOW[old]) or 'none (final state)'}")
        i.status = b.status
        if i.acknowledged_at is None: i.acknowledged_at = now
        if i.owner_id is None: i.owner_id = user.id
        if b.status == "Contained": i.contained_at = now
        elif b.status == "Resolved": i.resolved_at = now
        elif b.status == "False Positive": i.false_positive = True; i.resolved_at = None
        elif b.status == "Closed": i.closed_at = now
        elif b.status == "Investigating":  # reopen / containment failed: clear outcome stamps, history stays in the timeline
            i.resolved_at = None; i.contained_at = None; i.false_positive = False
        if b.status in ("Resolved", "False Positive"):
            for a in db.scalars(select(Alert).join(IncidentAlert, IncidentAlert.alert_id == Alert.id).where(IncidentAlert.incident_id == i.id)):
                a.status, a.updated_at = b.status, now
        _log(db, i, user, "state", old=old, new=b.status); audit.log(db, "incident.status", user=user, obj=str(i.id), old=old, new=b.status, ip=ip)
    db.commit(); _publish(db, i); return _row(db, i)

class AlertsAdd(BaseModel): alert_ids: list[int] = Field(min_length=1, max_length=50)

@router.post("/incidents/{iid}/alerts")
def add_alerts(iid: int, b: AlertsAdd, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid)
    if i.status == "Closed": raise HTTPException(409, "Incident is closed")
    alerts = db.scalars(select(Alert).where(Alert.id.in_(set(b.alert_ids)))).all()
    if len(alerts) != len(set(b.alert_ids)): raise HTTPException(404, "One or more alerts not found")
    for a in alerts:
        used = db.scalar(select(IncidentAlert.incident_id).where(IncidentAlert.alert_id == a.id))
        if used: raise HTTPException(409, f"Alert {a.id} already belongs to incident {used}")
    _link(db, i, alerts); _log(db, i, user, "alerts", f"Added alert(s) {sorted(set(b.alert_ids))}"); db.commit(); return _row(db, i)

class Note(BaseModel): text: str = Field(min_length=1, max_length=4000)
class Evidence(BaseModel):
    url: str = Field(max_length=500, pattern=r"^https?://[^\s<>\"']+$")
    label: str = Field("", max_length=200)

@router.post("/incidents/{iid}/notes", status_code=201)
def add_note(iid: int, b: Note, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid); _log(db, i, user, "note", b.text); db.commit(); return {"ok": True}

@router.post("/incidents/{iid}/evidence", status_code=201)
def add_evidence(iid: int, b: Evidence, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid); _log(db, i, user, "evidence", f"{b.label} {b.url}".strip()); db.commit(); return {"ok": True}  # link only; never fetched by the server

class AttachIn(BaseModel):
    filename: str = Field(max_length=100)
    content_type: str = Field(max_length=60)
    data_base64: str = Field(max_length=int(MAX_FILE * 1.4))

@router.post("/incidents/{iid}/attachments", status_code=201)
def add_attachment(iid: int, b: AttachIn, request: Request, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid)
    if not re.fullmatch(r"[A-Za-z0-9._ -]{1,100}", b.filename) or ".." in b.filename: raise HTTPException(422, "Invalid filename")
    if b.content_type not in ALLOWED_FILES: raise HTTPException(422, f"Content type not allowed. Allowed: {sorted(ALLOWED_FILES)}")
    try: raw = base64.b64decode(b.data_base64, validate=True)
    except (binascii.Error, ValueError): raise HTTPException(422, "data_base64 is not valid base64")
    if not raw or len(raw) > MAX_FILE: raise HTTPException(422, "File must be 1 byte to 1 MB")
    a = IncidentAttachment(incident_id=i.id, filename=b.filename, content_type=b.content_type, size=len(raw), sha256=hashlib.sha256(raw).hexdigest(), data=raw, uploaded_by=user.username)
    db.add(a); db.flush(); _log(db, i, user, "attachment", f"{b.filename} sha256={a.sha256[:16]}"); audit.log(db, "incident.attachment", user=user, obj=str(i.id), new=b.filename, ip=ip_of(request))
    db.commit(); return {"id": a.id, "sha256": a.sha256, "size": a.size}

@router.get("/incidents/{iid}/attachments/{aid}")
def download(iid: int, aid: int, user=Depends(require("triage")), db=Depends(get_db)):
    a = db.get(IncidentAttachment, aid)
    if not a or a.incident_id != iid: raise HTTPException(404, "Attachment not found")
    return Response(a.data, media_type=a.content_type, headers={"Content-Disposition": f'attachment; filename="{a.filename}"', "X-Content-Type-Options": "nosniff"})

class Tick(BaseModel): done: bool

@router.patch("/incidents/{iid}/playbook/{pid}")
def tick(iid: int, pid: int, b: Tick, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    p = db.get(PlaybookItem, pid)
    if not p or p.incident_id != iid: raise HTTPException(404, "Playbook item not found")
    p.done, p.done_by, p.done_at = b.done, user.username if b.done else None, utcnow() if b.done else None
    _log(db, _get(db, iid), user, "playbook", p.text, new="done" if b.done else "undone"); db.commit(); return {"ok": True}

class Propose(BaseModel):
    action: str = Field(pattern="^block_ip$")
    target: str = Field(max_length=45)

@router.post("/incidents/{iid}/responses", status_code=201)
def propose(iid: int, b: Propose, user=Depends(require("triage", "RW")), db=Depends(get_db)):
    i = _get(db, iid)
    try: ip = ipaddress.ip_address(b.target)
    except ValueError: raise HTTPException(422, "target must be an IP address")
    if ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified: raise HTTPException(422, "That address cannot be blocked")
    r = ResponseAction(incident_id=i.id, action=b.action, target=str(ip), proposed_by=user.username); db.add(r); db.flush()
    _log(db, i, user, "response", f"Proposed {b.action} {r.target} (awaiting Manager approval)"); db.commit(); return {"id": r.id, "status": r.status}

class Decide(BaseModel): decision: str = Field(pattern="^(approve|reject)$")

@router.patch("/responses/{rid}")
def decide(rid: int, b: Decide, request: Request, user=Depends(require("approve_response", "A")), db=Depends(get_db)):
    r = db.get(ResponseAction, rid)
    if not r: raise HTTPException(404, "Response action not found")
    if r.status != "proposed": raise HTTPException(409, f"Already decided ({r.status})")
    r.decided_by, r.decided_at = user.username, utcnow()
    if b.decision == "reject": r.status, r.result = "rejected", "Rejected by approver"
    else:
        try: r.status, r.result = respond.execute(r.action, r.target)
        except Exception as e: r.status, r.result = "failed", f"{type(e).__name__}: {e}"[:300]
    i = db.get(Incident, r.incident_id); _log(db, i, user, "response", f"{b.decision}d {r.action} {r.target}: {r.result}", new=r.status)
    audit.log(db, f"response.{b.decision}", user=user, obj=str(r.id), new=f"{r.action} {r.target} -> {r.status}", ip=ip_of(request)); db.commit()
    return {"id": r.id, "status": r.status, "result": r.result}
