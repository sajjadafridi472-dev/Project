import secrets
from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from . import audit, notify, security as sec
from .db import get_db
from .main import current_user, require, rate_limit, ip_of
from .models import Notification, PasswordReset, User, utcnow

router = APIRouter(prefix="/api/v1")

class Prefs(BaseModel):
    notify_email: bool
    min_severity: str = Field(pattern="^(High|Critical)$")  # SRS: e-mail is for High and Critical only

@router.patch("/auth/me/notifications")
def set_prefs(b: Prefs, request: Request, user=Depends(current_user), db=Depends(get_db)):
    user.notify_email, user.notify_min_severity = b.notify_email, b.min_severity  # FR-ALR-06
    audit.log(db, "user.notify_prefs", user=user, new=b.model_dump_json(), ip=ip_of(request)); db.commit()
    return {"notify_email": user.notify_email, "min_severity": user.notify_min_severity}

@router.get("/notifications")
def outbox(limit: int = 100, user=Depends(require("system")), db=Depends(get_db)):
    return [{"id": n.id, "alert_id": n.alert_id, "channel": n.channel, "recipient": n.recipient, "subject": n.subject, "status": n.status,
             "attempts": n.attempts, "last_error": n.last_error, "created_at": n.created_at, "sent_at": n.sent_at}
            for n in db.scalars(select(Notification).order_by(Notification.id.desc()).limit(min(max(limit, 1), 500)))]

class ResetReq(BaseModel): email: str = Field(max_length=254)
class ResetConfirm(BaseModel):
    token: str = Field(max_length=100)
    new_password: str = Field(max_length=128)

@router.post("/auth/password-reset/request", status_code=202)
def reset_request(b: ResetReq, request: Request, db=Depends(get_db)):
    rate_limit("reset" + str(ip_of(request)))
    u = db.scalar(select(User).where(User.email == b.email, User.status == "active"))
    if u:
        token = secrets.token_urlsafe(32)
        db.add(PasswordReset(user_id=u.id, token_hash=sec.token_hash(token), expires_at=utcnow() + timedelta(minutes=30)))
        notify.queue_reset(db, u, token); audit.log(db, "password.reset_requested", user=u, ip=ip_of(request)); db.commit()
    return {"message": "If that account exists, a reset link has been sent."}  # identical response: no account enumeration

@router.post("/auth/password-reset/confirm")
def reset_confirm(b: ResetConfirm, request: Request, db=Depends(get_db)):
    rate_limit("reset" + str(ip_of(request)))
    r = db.scalar(select(PasswordReset).where(PasswordReset.token_hash == sec.token_hash(b.token)))
    if not r or r.used or r.expires_at < utcnow(): raise HTTPException(400, "Reset link is invalid or expired")
    if (e := sec.password_error(b.new_password)): raise HTTPException(422, e)
    u = db.get(User, r.user_id)
    if not u or u.status != "active": raise HTTPException(400, "Reset link is invalid or expired")
    u.password_hash = sec.hash_password(b.new_password); r.used = True
    u.failed_attempts, u.locked_until = 0, None
    for s in u.sessions: s.revoked = True  # sign out everywhere
    audit.log(db, "password.reset_done", user=u, ip=ip_of(request)); db.commit(); return {"ok": True}
