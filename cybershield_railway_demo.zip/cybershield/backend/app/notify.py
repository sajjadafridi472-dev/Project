"""Notification outbox, delivery with retry, escalation (SRS 3.4). Channels: email (SMTP), webhook. SMS is NOT implemented."""
import json, smtplib, ssl, urllib.parse, urllib.request
from datetime import timedelta
from email.message import EmailMessage
from sqlalchemy import select
from . import audit
from .config import settings
from .models import Alert, Notification, Role, User, utcnow

RANK = {"Low": 0, "Medium": 1, "High": 2, "Critical": 3}
MAX_ATTEMPTS = 5

def _add(db, channel, recipient, subject, body, alert_id=None, attach=None):
    n = Notification(alert_id=alert_id, channel=channel, recipient=recipient[:254], subject=subject.replace("\n", " ")[:200], body=body)
    if attach: n.attach_name, n.attach_type, n.attach_data = attach
    db.add(n)

def _users(db, roles):
    return db.scalars(select(User).join(Role, User.role_id == Role.id).where(User.status == "active", User.notify_email == True, Role.name.in_(roles))).all()  # noqa: E712

def _summary(a):
    return (f"{a.severity} alert #{a.id}: {a.title}\nRisk score: {a.risk_score}/100\nEntity: {a.entity}\n"
            f"Occurrences: {a.occurrence_count}\nOpen: {settings.public_url}/#/alerts/{a.id}\n")  # metadata only, no raw log content

def on_alert(db, a: Alert):
    """Queue High/Critical notifications once per severity level reached (FR-ALR-03/04). Runs inside the detection transaction."""
    if RANK[a.severity] < 2 or RANK[a.severity] <= RANK.get(a.notified_severity or "Low", 0): return
    a.notified_severity = a.severity; subj = f"[CyberShield] {a.severity} alert: {a.title}"
    for u in _users(db, ("Administrator", "Security Analyst", "Manager")):
        if RANK[u.notify_min_severity] <= RANK[a.severity]: _add(db, "email", u.email, subj, _summary(a), a.id)
    if a.severity == "Critical" and settings.webhook_url:
        _add(db, "webhook", settings.webhook_url, subj, json.dumps({"alert_id": a.id, "title": a.title, "severity": a.severity,
             "risk_score": a.risk_score, "entity": a.entity}), a.id)

def queue_report(db, user, subject, body, attach): _add(db, "email", user.email, subject, body, attach=attach)  # scheduled reports (FR-RPT-05)

def queue_lockout(db, user):
    for u in _users(db, ("Administrator",)): _add(db, "email", u.email, f"[CyberShield] Account locked: {user.username}",
        f"Account '{user.username}' was locked for {settings.lock_minutes} minutes after {settings.max_failed} failed logins.")

def queue_reset(db, user, token):
    _add(db, "email", user.email, "[CyberShield] Password reset",
         f"A password reset was requested for your account.\nReset link (valid 30 minutes, single use): {settings.public_url}/#/reset?token={token}\n"
         "If you did not request this, ignore this message.")

def escalate(db, now=None) -> int:
    """Unacknowledged Critical alert -> next role (Manager) after the timeout (FR-ALR-07)."""
    now = now or utcnow(); n = 0
    for a in db.scalars(select(Alert).where(Alert.severity == "Critical", Alert.status == "Open", Alert.acknowledged_at.is_(None),
            Alert.escalated == False, Alert.created_at <= now - timedelta(minutes=settings.escalation_minutes))):  # noqa: E712
        a.escalated = True; n += 1
        for u in _users(db, ("Manager",)): _add(db, "email", u.email, f"[CyberShield] ESCALATED unacknowledged Critical alert #{a.id}", _summary(a), a.id)
        audit.log(db, "alert.escalated", username="system", obj=str(a.id), new=f"unacknowledged for {settings.escalation_minutes} min -> Manager")
    if n: db.commit()
    return n

def send_email(n):
    m = EmailMessage(); m["From"], m["To"], m["Subject"] = settings.smtp_from, n.recipient, n.subject; m.set_content(n.body)
    if n.attach_data:
        mt, st = (n.attach_type or "application/octet-stream").split("/", 1); m.add_attachment(n.attach_data, maintype=mt, subtype=st, filename=n.attach_name)
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=10) as s:
        if settings.smtp_starttls: s.starttls(context=ssl.create_default_context())  # SRS 5.2: SMTP with STARTTLS
        if settings.smtp_user: s.login(settings.smtp_user, settings.smtp_password)
        s.send_message(m)

def send_webhook(n):
    if urllib.parse.urlparse(n.recipient).scheme not in ("http", "https"): raise ValueError("webhook URL must be http or https")  # no file:/ or custom schemes
    req = urllib.request.Request(n.recipient, data=n.body.encode(), headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=10) as r:  # nosec B310 - scheme validated above; URL is admin-configured
        if r.status >= 300: raise RuntimeError(f"webhook returned {r.status}")

def deliver_pending(db, limit=50, now=None) -> int:
    now = now or utcnow(); rows = db.scalars(select(Notification).where(Notification.status == "pending",
            Notification.next_attempt_at <= now).order_by(Notification.id).limit(limit)).all()
    for n in rows:
        try:
            if n.channel == "email" and not settings.smtp_host: n.status, n.last_error = "unconfigured", "SMTP not configured"; continue
            send_email(n) if n.channel == "email" else send_webhook(n)
            n.status, n.sent_at, n.last_error = "sent", utcnow(), None
            if n.subject.startswith("[CyberShield] Password reset"): n.body = "[redacted after delivery]"
            n.attach_data = None  # do not keep delivered report contents in the outbox
        except Exception as e:  # retry with backoff; on-screen alerts remain primary (SRS 8.2)
            n.attempts += 1; n.last_error = f"{type(e).__name__}: {e}"[:200]
            if n.attempts >= MAX_ATTEMPTS: n.status = "failed"
            else: n.next_attempt_at = now + timedelta(seconds=30 * n.attempts)
    db.commit(); return len(rows)
