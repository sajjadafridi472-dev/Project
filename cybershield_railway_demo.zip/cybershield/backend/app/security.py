import hashlib, re, secrets
import pyotp
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError

_ph = PasswordHasher()  # Argon2id (SR-01)
# Small built-in list. SUGGESTION: load a larger breached-password list before deployment.
COMMON = {"password1234", "123456789012", "qwertyuiop12", "administrator1", "letmein123456",
          "welcome12345", "iloveyou1234", "password12345", "changeme1234", "admin1234567"}

def password_error(pw: str) -> str | None:
    if len(pw) < 12: return "Password must be at least 12 characters."
    if pw.lower() in COMMON or len(set(pw)) < 5: return "Password is too common or too simple."
    return None

def hash_password(pw: str) -> str: return _ph.hash(pw)

def verify_password(pw: str, h: str) -> bool:
    try: return _ph.verify(h, pw)
    except (VerifyMismatchError, InvalidHashError): return False

def new_totp_secret() -> str: return pyotp.random_base32()
def totp_uri(secret: str, username: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name="CyberShield")
def verify_totp(secret: str, code: str) -> bool:
    return bool(re.fullmatch(r"\d{6}", code or "")) and pyotp.TOTP(secret).verify(code, valid_window=1)

def new_token() -> str: return secrets.token_urlsafe(32)
def token_hash(t: str) -> str: return hashlib.sha256(t.encode()).hexdigest()
