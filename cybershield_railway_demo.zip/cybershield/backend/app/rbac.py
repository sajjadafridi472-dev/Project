"""Role-permission matrix, SRS section 7.8. R=read, RW=read/write, A=approve."""
ROLES = ["Administrator", "Security Analyst", "Auditor", "Manager"]
MFA_REQUIRED = {"Administrator", "Security Analyst"}  # SR-02
_LV = {"R": 1, "RW": 2}
MATRIX = {  # function: {role: level}
    "dashboard": dict.fromkeys(ROLES, "R"),
    "triage":    {"Security Analyst": "RW", "Manager": "R", "Auditor": "R"},
    "rules":     {"Security Analyst": "RW", "Administrator": "R", "Auditor": "R"},
    "search":    dict.fromkeys(ROLES, "R"),
    "reports":   {"Security Analyst": "R", "Administrator": "R", "Manager": "RW", "Auditor": "RW"},
    "users":     {"Administrator": "RW", "Auditor": "R"},
    "sources":   {"Administrator": "RW", "Auditor": "R"},
    "system":    {"Administrator": "RW", "Auditor": "R"},
    "audit":     {"Administrator": "R", "Manager": "R", "Auditor": "R"},
    "approve_response": {"Manager": "A"},
}
def allowed(role: str, function: str, level: str = "R") -> bool:
    have = MATRIX.get(function, {}).get(role)
    if not have: return False
    if have == "A": return level == "A"
    return level != "A" and _LV[have] >= _LV[level]
