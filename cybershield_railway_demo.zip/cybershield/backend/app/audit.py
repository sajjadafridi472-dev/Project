import hashlib
from sqlalchemy import select, text
from .models import AuditLog, utcnow
GENESIS = "0" * 64

def _digest(prev, ts, user, action, obj, old, new, ip):
    return hashlib.sha256("|".join(str(x) for x in (prev, ts.isoformat(), user, action, obj, old, new, ip)).encode()).hexdigest()

def log(db, action, user=None, username=None, obj=None, old=None, new=None, ip=None):
    """Append one hash-chained audit entry (caller commits). On PostgreSQL a transaction-scoped advisory lock serialises writers
    so two concurrent transactions can never chain from the same previous hash."""
    if db.get_bind().dialect.name == "postgresql": db.execute(text("SELECT pg_advisory_xact_lock(727001)"))
    last = db.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(1)).scalar_one_or_none()
    prev = last.entry_hash if last else GENESIS
    uname = username or (user.username if user else None)
    ts = utcnow()
    db.add(AuditLog(timestamp=ts, user_id=user.id if user else None, username=uname, action=action,
                    object=obj, old_value=old, new_value=new, ip=ip, prev_hash=prev,
                    entry_hash=_digest(prev, ts, uname, action, obj, old, new, ip)))
    db.flush()

def verify_chain(db) -> bool:
    prev = GENESIS
    for e in db.execute(select(AuditLog).order_by(AuditLog.id)).scalars():
        if e.prev_hash != prev or e.entry_hash != _digest(prev, e.timestamp, e.username, e.action,
                                                          e.object, e.old_value, e.new_value, e.ip):
            return False
        prev = e.entry_hash
    return True
