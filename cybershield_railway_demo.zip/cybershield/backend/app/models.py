"""Full CyberShield schema (SRS section 6). Later modules reuse these tables."""
from datetime import datetime, timezone
from sqlalchemy import (String, Integer, Text, DateTime, ForeignKey, Boolean, Index,
                        CheckConstraint, UniqueConstraint, LargeBinary, event)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)

class Role(Base):
    __tablename__ = "roles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40), unique=True)
    permissions: Mapped[str] = mapped_column(Text, default="")

class User(Base):
    __tablename__ = "users"
    __table_args__ = (CheckConstraint("status IN ('active','disabled')"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(String(254), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"))
    mfa_secret: Mapped[str | None] = mapped_column(String(64))
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(10), default="active")
    failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime)
    last_login: Mapped[datetime | None] = mapped_column(DateTime)
    notify_email: Mapped[bool] = mapped_column(Boolean, default=True)
    notify_min_severity: Mapped[str] = mapped_column(String(10), default="High")  # High | Critical (FR-ALR-06)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    role: Mapped[Role] = relationship()
    sessions: Mapped[list["Session"]] = relationship(cascade="all, delete-orphan", back_populates="user")

class Session(Base):
    __tablename__ = "sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)  # only the hash is stored
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)
    user: Mapped[User] = relationship(back_populates="sessions")

class Asset(Base):
    __tablename__ = "assets"
    __table_args__ = (CheckConstraint("criticality BETWEEN 1 AND 5"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    hostname: Mapped[str] = mapped_column(String(100), unique=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), index=True)
    os: Mapped[str | None] = mapped_column(String(60))
    owner: Mapped[str | None] = mapped_column(String(100))
    criticality: Mapped[int] = mapped_column(Integer, default=3)
    tags: Mapped[str | None] = mapped_column(String(200))

class LogSource(Base):
    __tablename__ = "log_sources"
    __table_args__ = (CheckConstraint("source_type IN ('agent','syslog','api','ids')"),
                      CheckConstraint("status IN ('active','disabled','silent')"))
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    source_type: Mapped[str] = mapped_column(String(10))
    token_hash: Mapped[str | None] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(10), default="active")
    last_seen: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"))

class Event(Base):
    __tablename__ = "events"
    __table_args__ = (CheckConstraint("severity BETWEEN 0 AND 10"),
                      CheckConstraint("data_origin IN ('simulated','imported','live')"),
                      Index("ix_events_ts_type", "timestamp", "event_type"))
    id: Mapped[str] = mapped_column(String(36), primary_key=True)  # UUID4
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"))
    source_id: Mapped[int | None] = mapped_column(ForeignKey("log_sources.id", ondelete="SET NULL"))
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    source_type: Mapped[str] = mapped_column(String(10))
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    hostname: Mapped[str | None] = mapped_column(String(100), index=True)
    severity: Mapped[int] = mapped_column(Integer, default=0)
    src_ip: Mapped[str | None] = mapped_column(String(45), index=True)
    dst_ip: Mapped[str | None] = mapped_column(String(45))
    username: Mapped[str | None] = mapped_column(String(100))
    message: Mapped[str] = mapped_column(Text)
    raw: Mapped[str] = mapped_column(Text)
    hash: Mapped[str] = mapped_column(String(64), index=True)  # SHA-256 (SR-11)
    data_origin: Mapped[str] = mapped_column(String(10))  # simulated | imported | live
    detected: Mapped[bool] = mapped_column(Boolean, default=False, index=True)  # evaluated by detection engine

class Rule(Base):
    __tablename__ = "rules"
    __table_args__ = (CheckConstraint("severity IN ('Low','Medium','High','Critical')"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    logic: Mapped[str] = mapped_column(Text)  # JSON
    severity: Mapped[str] = mapped_column(String(10))
    version: Mapped[int] = mapped_column(Integer, default=1)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))

class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (CheckConstraint("severity IN ('Low','Medium','High','Critical')"),
                      CheckConstraint("risk_score BETWEEN 0 AND 100"),
                      CheckConstraint("status IN ('Open','Investigating','Resolved','False Positive','Suppressed')"),
                      Index("ix_alerts_status_sev", "status", "severity"))
    id: Mapped[int] = mapped_column(primary_key=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id"))
    rule_version: Mapped[int] = mapped_column(Integer)  # exact version (section 6.6)
    severity: Mapped[str] = mapped_column(String(10))
    risk_score: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(15), default="Open")
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    occurrence_count: Mapped[int] = mapped_column(Integer, default=1)
    title: Mapped[str] = mapped_column(String(200), default="")
    entity: Mapped[str] = mapped_column(String(120), index=True, default="")  # correlation key, e.g. src_ip:1.2.3.4
    hostname: Mapped[str | None] = mapped_column(String(100))
    mitre: Mapped[str | None] = mapped_column(String(60))
    explanation: Mapped[str] = mapped_column(Text, default="{}")  # JSON: rules, summaries, score components
    last_event_at: Mapped[datetime | None] = mapped_column(DateTime)
    trigger_latency_ms: Mapped[int | None] = mapped_column(Integer)  # event receipt -> alert (NFR-PERF-02)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    escalated: Mapped[bool] = mapped_column(Boolean, default=False)
    notified_severity: Mapped[str | None] = mapped_column(String(10))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)

class AlertEvent(Base):  # many-to-many (resolves SRS ER ambiguity #3)
    __tablename__ = "alert_events"
    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id", ondelete="CASCADE"), primary_key=True)
    event_id: Mapped[str] = mapped_column(ForeignKey("events.id"), primary_key=True)

class Incident(Base):
    __tablename__ = "incidents"
    __table_args__ = (CheckConstraint(
        "status IN ('New','Investigating','Contained','Resolved','False Positive','Closed')"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(15), default="New")
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    detected_at: Mapped[datetime | None] = mapped_column(DateTime)
    acknowledged_at: Mapped[datetime | None] = mapped_column(DateTime)
    contained_at: Mapped[datetime | None] = mapped_column(DateTime)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    incident_type: Mapped[str] = mapped_column(String(20), default="other")
    severity: Mapped[str] = mapped_column(String(10), default="Medium")
    description: Mapped[str] = mapped_column(Text, default="")
    first_event_at: Mapped[datetime | None] = mapped_column(DateTime)  # earliest linked event (for time-to-detect)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime)
    false_positive: Mapped[bool] = mapped_column(Boolean, default=False)

class IncidentAlert(Base):
    __tablename__ = "incident_alerts"
    incident_id: Mapped[int] = mapped_column(ForeignKey("incidents.id", ondelete="CASCADE"), primary_key=True)
    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id"), primary_key=True)

class IOC(Base):
    __tablename__ = "iocs"
    __table_args__ = (UniqueConstraint("type", "value"),
                      CheckConstraint("type IN ('ip','domain','hash')"))
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(10))
    value: Mapped[str] = mapped_column(String(255), index=True)
    source: Mapped[str | None] = mapped_column(String(100))
    confidence: Mapped[int] = mapped_column(Integer, default=50)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime)

class AlertIOC(Base):
    __tablename__ = "alert_iocs"
    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id", ondelete="CASCADE"), primary_key=True)
    ioc_id: Mapped[int] = mapped_column(ForeignKey("iocs.id"), primary_key=True)

class AuditLog(Base):
    """Append-only, hash-chained (SR-12). user_id is a soft reference so entries survive user deletion."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True)
    user_id: Mapped[int | None] = mapped_column(Integer)
    username: Mapped[str | None] = mapped_column(String(100))
    action: Mapped[str] = mapped_column(String(60), index=True)
    object: Mapped[str | None] = mapped_column(String(200))
    old_value: Mapped[str | None] = mapped_column(Text)
    new_value: Mapped[str | None] = mapped_column(Text)
    ip: Mapped[str | None] = mapped_column(String(45))
    prev_hash: Mapped[str] = mapped_column(String(64))
    entry_hash: Mapped[str] = mapped_column(String(64))

@event.listens_for(AuditLog, "before_update")
@event.listens_for(AuditLog, "before_delete")
def _audit_immutable(*_):
    raise PermissionError("audit log is append-only")

class QueueItem(Base):
    """Persistent ingest queue: accepted = committed here first (FR-COL-06, at-least-once)."""
    __tablename__ = "ingest_queue"
    __table_args__ = (Index("ix_queue_status_id", "status", "id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int | None] = mapped_column(ForeignKey("log_sources.id", ondelete="SET NULL"))
    source_type: Mapped[str] = mapped_column(String(10))
    origin: Mapped[str] = mapped_column(String(10))
    fmt: Mapped[str] = mapped_column(String(10))  # json | syslog
    payload: Mapped[str] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    status: Mapped[str] = mapped_column(String(10), default="pending")

class Quarantine(Base):
    """Malformed events are kept, never silently dropped (FR-COL-05, section 6.6)."""
    __tablename__ = "quarantine"
    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int | None] = mapped_column(Integer)
    reason: Mapped[str] = mapped_column(String(200))
    payload: Mapped[str] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class IngestMetric(Base):
    __tablename__ = "ingest_metrics"
    key: Mapped[str] = mapped_column(String(40), primary_key=True)
    value: Mapped[int] = mapped_column(Integer, default=0)

class RuleVersion(Base):
    __tablename__ = "rule_versions"
    __table_args__ = (UniqueConstraint("rule_id", "version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    rule_id: Mapped[int] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"))
    version: Mapped[int] = mapped_column(Integer)
    name: Mapped[str] = mapped_column(String(100))
    logic: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(String(10))
    changed_by: Mapped[int | None] = mapped_column(Integer)
    changed_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class Suppression(Base):
    """Whitelist of known-benign patterns; always expires (FR-DET-10)."""
    __tablename__ = "suppressions"
    id: Mapped[int] = mapped_column(primary_key=True)
    rule_id: Mapped[int | None] = mapped_column(ForeignKey("rules.id", ondelete="CASCADE"))
    src_ip: Mapped[str | None] = mapped_column(String(45))
    username: Mapped[str | None] = mapped_column(String(100))
    hostname: Mapped[str | None] = mapped_column(String(100))
    reason: Mapped[str] = mapped_column(String(300))
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    created_by: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class AlertNote(Base):
    __tablename__ = "alert_notes"
    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int | None] = mapped_column(Integer)
    username: Mapped[str | None] = mapped_column(String(100))
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class Notification(Base):
    """Outbox: written in the same transaction as the alert, delivered later with retry (SRS 8.2 mitigation)."""
    __tablename__ = "notifications"
    __table_args__ = (CheckConstraint("channel IN ('email','webhook')"),
                      CheckConstraint("status IN ('pending','sent','failed','unconfigured')"),
                      Index("ix_notif_status_next", "status", "next_attempt_at"))
    id: Mapped[int] = mapped_column(primary_key=True)
    alert_id: Mapped[int | None] = mapped_column(ForeignKey("alerts.id", ondelete="SET NULL"))
    channel: Mapped[str] = mapped_column(String(10))
    recipient: Mapped[str] = mapped_column(String(254))
    subject: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(12), default="pending")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    next_attempt_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    attach_name: Mapped[str | None] = mapped_column(String(100))
    attach_type: Mapped[str | None] = mapped_column(String(60))
    attach_data: Mapped[bytes | None] = mapped_column(LargeBinary)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)

class PasswordReset(Base):
    __tablename__ = "password_resets"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    used: Mapped[bool] = mapped_column(Boolean, default=False)

class IncidentEntry(Base):
    """Timeline: every state change, assignment, note, evidence link, with user and timestamp (FR-INC-03/04)."""
    __tablename__ = "incident_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    incident_id: Mapped[int] = mapped_column(ForeignKey("incidents.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int | None] = mapped_column(Integer)
    username: Mapped[str | None] = mapped_column(String(100))
    kind: Mapped[str] = mapped_column(String(12))  # created|state|assign|note|evidence|attachment|playbook|response|alerts
    text: Mapped[str] = mapped_column(Text, default="")
    old_value: Mapped[str | None] = mapped_column(String(100))
    new_value: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class IncidentAttachment(Base):
    __tablename__ = "incident_attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    incident_id: Mapped[int] = mapped_column(ForeignKey("incidents.id", ondelete="CASCADE"), index=True)
    filename: Mapped[str] = mapped_column(String(100))
    content_type: Mapped[str] = mapped_column(String(60))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))  # evidence integrity
    data: Mapped[bytes] = mapped_column(LargeBinary)
    uploaded_by: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class PlaybookItem(Base):
    __tablename__ = "playbook_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    incident_id: Mapped[int] = mapped_column(ForeignKey("incidents.id", ondelete="CASCADE"), index=True)
    position: Mapped[int] = mapped_column(Integer)
    phase: Mapped[str] = mapped_column(String(30))
    text: Mapped[str] = mapped_column(String(300))
    done: Mapped[bool] = mapped_column(Boolean, default=False)
    done_by: Mapped[str | None] = mapped_column(String(100))
    done_at: Mapped[datetime | None] = mapped_column(DateTime)

class ResponseAction(Base):
    """Analyst proposes, Manager approves (SRS 7.8 'Approve automated response'); nothing runs unapproved (FR-INC-06)."""
    __tablename__ = "response_actions"
    __table_args__ = (CheckConstraint("status IN ('proposed','rejected','executed','failed','not_executed')"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    incident_id: Mapped[int] = mapped_column(ForeignKey("incidents.id", ondelete="CASCADE"), index=True)
    action: Mapped[str] = mapped_column(String(20))
    target: Mapped[str] = mapped_column(String(45))
    status: Mapped[str] = mapped_column(String(12), default="proposed")
    proposed_by: Mapped[str | None] = mapped_column(String(100))
    decided_by: Mapped[str | None] = mapped_column(String(100))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime)
    result: Mapped[str | None] = mapped_column(String(300))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

class RetentionPolicy(Base):
    """SRS Table 6.2. Only events, alerts and iocs are purged by the application; incidents and audit never are."""
    __tablename__ = "retention_policy"
    __table_args__ = (CheckConstraint("hot_days BETWEEN 1 AND 3650"), CheckConstraint("archive_days BETWEEN 0 AND 3650"))
    category: Mapped[str] = mapped_column(String(20), primary_key=True)
    hot_days: Mapped[int] = mapped_column(Integer)
    archive_days: Mapped[int] = mapped_column(Integer)

class ReportSchedule(Base):
    __tablename__ = "report_schedules"
    __table_args__ = (UniqueConstraint("user_id", "period", "format"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    period: Mapped[str] = mapped_column(String(10))
    format: Mapped[str] = mapped_column(String(4))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime)
