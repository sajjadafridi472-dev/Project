import csv, io, secrets
from datetime import datetime, timedelta, timezone
from typing import Any
from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select, func
from . import audit, ingest, security as sec
from .config import settings
from .db import get_db
from .main import require, rate_limit, ip_of
from .models import Event, IngestMetric, LogSource, QueueItem, Quarantine, utcnow

router = APIRouter(prefix="/api/v1")
TYPES = "^(agent|syslog|api|ids)$"

class SourceIn(BaseModel):
    name: str = Field(min_length=2, max_length=100, pattern=r"^[A-Za-z0-9 _.-]+$")
    source_type: str = Field(pattern=TYPES)

class SourcePatch(BaseModel):
    status: str = Field(pattern="^(active|disabled)$")

def _view(s: LogSource):
    st, now = s.status, utcnow()
    if st == "active":
        if s.last_seen is None: st = "silent" if now - s.created_at > timedelta(minutes=settings.silent_minutes) else "pending"
        elif now - s.last_seen > timedelta(minutes=settings.silent_minutes): st = "silent"  # FR-COL-08
    return {"id": s.id, "name": s.name, "source_type": s.source_type, "status": st, "last_seen": s.last_seen,
            "unauthenticated": s.source_type == "syslog"}

@router.post("/sources", status_code=201)
def register_source(b: SourceIn, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    if db.scalar(select(LogSource).where(LogSource.name == b.name)): raise HTTPException(409, "Source name exists")
    token = secrets.token_urlsafe(32)  # unique per source, revocable (SR-05); only the hash is stored
    s = LogSource(name=b.name, source_type=b.source_type, token_hash=sec.token_hash(token))
    db.add(s); db.flush(); audit.log(db, "source.create", user=admin, obj=b.name, new=b.source_type, ip=ip_of(request))
    db.commit(); return {**_view(s), "token": token}

@router.get("/sources")
def list_sources(user=Depends(require("sources")), db=Depends(get_db)):
    return [_view(s) for s in db.scalars(select(LogSource).order_by(LogSource.id))]

@router.patch("/sources/{sid}")
def toggle_source(sid: int, b: SourcePatch, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    s = db.get(LogSource, sid)
    if not s: raise HTTPException(404, "Source not found")
    old, s.status = s.status, b.status  # takes effect immediately, no restart (FR-COL-07)
    audit.log(db, "source.status", user=admin, obj=s.name, old=old, new=b.status, ip=ip_of(request)); db.commit()
    return _view(s)

@router.delete("/sources/{sid}")
def delete_source(sid: int, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    s = db.get(LogSource, sid)
    if not s: raise HTTPException(404, "Source not found")
    audit.log(db, "source.delete", user=admin, obj=s.name, ip=ip_of(request)); db.delete(s); db.commit()
    return {"ok": True}

def source_auth(x_source_token: str = Header(None), db=Depends(get_db)) -> LogSource:
    s = x_source_token and db.scalar(select(LogSource).where(LogSource.token_hash == sec.token_hash(x_source_token)))
    if not s or s.status == "disabled": raise HTTPException(401, "Invalid or disabled source token")
    rate_limit(f"src{s.id}", settings.ingest_rate)
    return s

@router.post("/events", status_code=202)
def submit_events(items: list[Any] = Body(...), src: LogSource = Depends(source_auth), db=Depends(get_db)):
    if not 1 <= len(items) <= 1000: raise HTTPException(400, "Batch must contain 1-1000 events")
    ingest.enqueue(db, items, "json", src.id, src.source_type, "live"); db.commit()
    return {"accepted": len(items)}

class ImportIn(BaseModel):
    format: str = Field(pattern="^(syslog|jsonl)$")
    content: str = Field(max_length=5_000_000)

@router.post("/ingest/import", status_code=202)
def import_file(b: ImportIn, request: Request, admin=Depends(require("sources", "RW")), db=Depends(get_db)):
    lines = [l for l in b.content.splitlines() if l.strip()][:50000]
    ingest.enqueue(db, lines, "syslog" if b.format == "syslog" else "json", None,
                   "syslog" if b.format == "syslog" else "api", "imported")
    audit.log(db, "ingest.import", user=admin, new=f"{b.format}: {len(lines)} lines", ip=ip_of(request)); db.commit()
    return {"queued": len(lines)}

class SimIn(BaseModel):
    scenario: str = Field(pattern="^(benign|brute_force|port_scan)$")
    count: int = Field(20, ge=1, le=500)

@router.post("/simulate", status_code=202)
def simulate(b: SimIn, request: Request, admin=Depends(require("system", "RW")), db=Depends(get_db)):
    """Built-in generator. Everything it makes is tagged data_origin='simulated' and is NOT real monitoring."""
    now = utcnow(); ts = lambda i: (now - timedelta(seconds=b.count - i)).strftime("%Y-%m-%dT%H:%M:%SZ")
    if b.scenario == "benign":
        ev = [{"timestamp": ts(i), "hostname": "web01", "event_type": "auth.success", "severity": 1, "user": f"user{i % 7}",
               "src_ip": f"192.0.2.{10 + i % 20}", "message": f"Accepted publickey for user{i % 7} #{i}"} for i in range(b.count)]
        ingest.enqueue(db, ev, "json", None, "agent", "simulated")
    elif b.scenario == "brute_force":
        ev = [{"timestamp": ts(i), "hostname": "web01", "event_type": "auth.failure", "severity": 4, "user": "admin",
               "src_ip": "203.0.113.50", "message": f"Failed password for admin from 203.0.113.50 attempt {i}"} for i in range(b.count)]
        ingest.enqueue(db, ev, "json", None, "agent", "simulated")
    else:
        t = f"{now:%b} {now.day:2d} {now:%H:%M:%S}"  # RFC 3164 timestamp
        ln = [f"<4>{t} fw01 kernel: IN=eth0 SRC=198.51.100.7 DST=10.0.0.5 PROTO=TCP SPT=40000 DPT={1000 + i}" for i in range(b.count)]
        ingest.enqueue(db, ln, "syslog", None, "ids", "simulated")
    audit.log(db, "simulate", user=admin, new=f"{b.scenario} x{b.count}", ip=ip_of(request)); db.commit()
    return {"queued": b.count, "data_origin": "simulated"}

def _cell(v):  # CSV formula-injection guard for spreadsheet users
    v = "" if v is None else str(v)
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v

def _iso(v, name):
    try: d = datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError: raise HTTPException(422, f"{name} must be ISO 8601")
    return d.astimezone(timezone.utc).replace(tzinfo=None) if d.tzinfo else d

@router.get("/events")
def search_events(q: str | None = None, event_type: str | None = None, source_type: str | None = None, source: str | None = None,
                  data_origin: str | None = None, hostname: str | None = None, src_ip: str | None = None, user: str | None = None,
                  severity_min: int | None = None, start: str | None = None, end: str | None = None, format: str = "json",
                  limit: int = 100, who=Depends(require("search")), db=Depends(get_db)):
    """FR-DSH-03 filters (time, source, asset, user, severity, free text), all parameterised (SR-15). format=csv exports (FR-RPT-02)."""
    st = select(Event).order_by(Event.timestamp.desc()).limit(min(max(limit, 1), 5000 if format == "csv" else 500))
    if q: st = st.where(Event.message.icontains(q, autoescape=True))  # case-insensitive on every database
    for col, v in ((Event.event_type, event_type), (Event.source_type, source_type), (Event.data_origin, data_origin),
                   (Event.hostname, hostname), (Event.src_ip, src_ip), (Event.username, user)):
        if v: st = st.where(col == v)
    if source: st = st.join(LogSource, LogSource.id == Event.source_id).where(LogSource.name == source)
    if severity_min is not None: st = st.where(Event.severity >= severity_min)
    if start: st = st.where(Event.timestamp >= _iso(start, "start"))
    if end: st = st.where(Event.timestamp <= _iso(end, "end"))
    rows = [{"id": e.id, "timestamp": e.timestamp, "hostname": e.hostname, "source_type": e.source_type,
             "event_type": e.event_type, "severity": e.severity, "src_ip": e.src_ip, "dst_ip": e.dst_ip,
             "user": e.username, "message": e.message, "hash": e.hash, "data_origin": e.data_origin} for e in db.scalars(st)]
    if format != "csv": return rows
    out = io.StringIO(); w = csv.writer(out); w.writerow(list(rows[0]) if rows else ["id"])
    for r in rows: w.writerow([_cell(v) for v in r.values()])
    return Response(out.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="events.csv"', "X-Content-Type-Options": "nosniff"})

@router.get("/ingest/health")
def ingest_health(user=Depends(require("sources")), db=Depends(get_db)):
    m = {r.key: r.value for r in db.scalars(select(IngestMetric))}
    return {"accepted": m.get("accepted", 0), "quarantined": m.get("quarantined", 0), "duplicates": m.get("duplicates", 0),
            "queue_depth": db.scalar(select(func.count(QueueItem.id)).where(QueueItem.status == "pending")),
            "recent_quarantine": [{"reason": r.reason, "received_at": r.received_at}
                                  for r in db.scalars(select(Quarantine).order_by(Quarantine.id.desc()).limit(20))]}
