import base64, json, os, shutil, time
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select, func, text
from . import audit, backup, retention
from .config import settings
from .db import get_db, SessionLocal
from .main import require, ip_of
from .models import Alert, Event, IOC, IngestMetric, LogSource, Notification, QueueItem, RetentionPolicy, utcnow
import re

router = APIRouter(prefix="/api/v1")

class Pol(BaseModel):
    hot_days: int = Field(ge=1, le=3650)
    archive_days: int = Field(ge=0, le=3650)

@router.get("/admin/retention")
def get_retention(user=Depends(require("system")), db=Depends(get_db)):
    return [{"category": p.category, "hot_days": p.hot_days, "archive_days": p.archive_days, "enforced_by_application": p.category in retention.ENFORCED,
             "note": {"incidents": "Deleted only on policy review, never automatically.", "audit": "Never deleted by the application.", "iocs": "Removed when the indicator expires."}.get(p.category, "Archived to a compressed file after the hot period, deleted after the archive period.")}
            for p in db.scalars(select(RetentionPolicy).order_by(RetentionPolicy.category))]

@router.put("/admin/retention/{cat}")
def set_retention(cat: str, b: Pol, request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    p = db.get(RetentionPolicy, cat)
    if not p: raise HTTPException(404, "Unknown category")
    old = f"hot={p.hot_days} archive={p.archive_days}"; p.hot_days, p.archive_days = b.hot_days, b.archive_days  # SR-13: who, what, when, previous value
    audit.log(db, "retention.update", user=user, obj=cat, old=old, new=f"hot={b.hot_days} archive={b.archive_days}", ip=ip_of(request)); db.commit(); return {"category": cat, **b.model_dump()}

@router.post("/admin/retention/run")
def run_retention(request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    r = retention.run(db); audit.log(db, "retention.run", user=user, new=json.dumps(r), ip=ip_of(request)); db.commit(); return r

class BackupIn(BaseModel):
    passphrase: str = Field(min_length=12, max_length=200)
    include_users: bool = False

@router.post("/admin/backup")
def make_backup(b: BackupIn, request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    snap = backup.snapshot(db, b.include_users); blob = backup.encrypt(b.passphrase, snap)
    audit.log(db, "backup.create", user=user, new=json.dumps({t: len(v) for t, v in snap["tables"].items()}), ip=ip_of(request)); db.commit()
    return Response(blob, media_type="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="cybershield-config-{utcnow():%Y%m%d-%H%M}.csbak"', "X-Content-Type-Options": "nosniff"})

class RestoreIn(BaseModel):
    passphrase: str = Field(min_length=12, max_length=200)
    backup_base64: str = Field(max_length=30_000_000)
    include_users: bool = False

@router.post("/admin/restore")
def restore_backup(b: RestoreIn, request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    try: snap = backup.decrypt(b.passphrase, base64.b64decode(b.backup_base64, validate=True))
    except (ValueError, TypeError): raise HTTPException(400, "Wrong passphrase, or the backup file is damaged")
    if not b.include_users: snap["tables"].pop("users", None)
    try: counts = backup.restore(db, snap)
    except ValueError as e: db.rollback(); raise HTTPException(409, str(e))
    except Exception: db.rollback(); raise HTTPException(409, "The backup conflicts with current data (for example a different item already uses the same name)")
    audit.log(db, "backup.restore", user=user, new=json.dumps(counts), ip=ip_of(request)); db.commit(); return {"restored": counts}

def components(db):
    out = []; now = time.time()
    t = time.perf_counter(); db.execute(text("SELECT 1")); out.append({"name": "database", "status": "ok", "detail": f"{(time.perf_counter() - t) * 1000:.1f} ms round trip"})
    pend = db.scalar(select(func.count()).where(QueueItem.status == "pending")); oldest = db.scalar(select(func.min(QueueItem.received_at)).where(QueueItem.status == "pending"))
    age = (utcnow() - oldest).total_seconds() if oldest else 0
    out.append({"name": "queue", "status": "degraded" if pend > 5000 or age > 60 else "ok", "detail": f"{pend} waiting, oldest {int(age)} s"})
    back = db.scalar(select(func.count()).where(Event.detected == False))  # noqa: E712
    out.append({"name": "detection engine", "status": "degraded" if back > 10000 else "ok", "detail": f"{back} events awaiting evaluation, {db.get(IngestMetric, 'rule_errors').value if db.get(IngestMetric, 'rule_errors') else 0} rule errors"})
    hb = db.get(IngestMetric, "worker_heartbeat")
    if not settings.ingest_worker: out.append({"name": "background worker", "status": "disabled", "detail": "INGEST_WORKER=0: queue and detection only run when triggered manually"})
    else: lag = now - hb.value if hb else None; out.append({"name": "background worker", "status": "ok" if lag is not None and lag < 30 else "down", "detail": "no heartbeat yet" if lag is None else f"last heartbeat {int(lag)} s ago"})
    n = {s: db.scalar(select(func.count()).where(Notification.status == s)) for s in ("pending", "failed", "unconfigured")}
    out.append({"name": "notification service", "status": "degraded" if n["failed"] or not settings.smtp_host else "ok", "detail": f"{n['pending']} pending, {n['failed']} failed, {n['unconfigured']} not sent because SMTP/webhook is not configured" + ("" if settings.smtp_host else " (SMTP not configured)")})
    srcs = db.scalars(select(LogSource)).all(); from .routes_ingest import _view; st = [_view(s)["status"] for s in srcs]
    out.append({"name": "collectors", "status": "degraded" if "silent" in st else "ok", "detail": f"{st.count('active')} active, {st.count('pending')} pending, {st.count('silent')} silent, {st.count('disabled')} disabled; syslog listener {'on' if settings.syslog_port else 'off'}"})
    try: free = shutil.disk_usage(os.path.dirname(os.path.abspath(settings.archive_dir)) or ".").free; out.append({"name": "disk", "status": "degraded" if free < 1_000_000_000 else "ok", "detail": f"{free / 1e9:.1f} GB free where archives are stored"})
    except OSError: pass
    return out

def _overall(c): return "down" if any(x["status"] == "down" for x in c) else "degraded" if any(x["status"] == "degraded" for x in c) else "ok"

@router.get("/admin/health")
def admin_health(user=Depends(require("system")), db=Depends(get_db)):
    c = components(db); return {"status": _overall(c), "components": c, "checked_at": utcnow()}

@router.get("/health")
def public_health(response: Response):
    """No authentication and no detail (SRS 5.5): for an external uptime probe."""
    with SessionLocal() as db:
        try: s = _overall(components(db))
        except Exception: s = "down"
    response.status_code = 503 if s == "down" else 200; return {"status": s}

class Stix(BaseModel): bundle: dict

_P = {"ip": re.compile(r"^\[(?:ipv4-addr|ipv6-addr):value\s*=\s*'([^']{1,45})'\]$"), "domain": re.compile(r"^\[domain-name:value\s*=\s*'([^']{1,253})'\]$"),
      "hash": re.compile(r"^\[file:hashes\.(?:'SHA-256'|'SHA-1'|'MD5'|SHA256|SHA1|MD5)\s*=\s*'([A-Fa-f0-9]{32,64})'\]$")}

@router.post("/iocs/import-stix")
def import_stix(b: Stix, request: Request, user=Depends(require("system", "RW")), db=Depends(get_db)):
    """STIX 2.1 bundle upload (FR-ADM-05). Only indicators with ONE simple equality pattern are imported; TAXII polling is not implemented."""
    import ipaddress
    objs = b.bundle.get("objects", []) if isinstance(b.bundle.get("objects"), list) else []
    if len(objs) > 5000: raise HTTPException(413, "At most 5000 objects per bundle")
    ok = bad = 0; pending = {}
    for o in objs:
        try:
            if not isinstance(o, dict) or o.get("type") != "indicator": bad += 1; continue
            kind = val = None
            for k, rx in _P.items():
                m = rx.match(str(o.get("pattern", "")).strip())
                if m: kind, val = k, m[1].lower(); break
            if not kind: bad += 1; continue
            if kind == "ip": val = str(ipaddress.ip_address(val))
            exp = o.get("valid_until"); exp = datetime.fromisoformat(exp.replace("Z", "+00:00")) if exp else None
            if exp and exp.tzinfo: exp = exp.astimezone(timezone.utc).replace(tzinfo=None)
            conf = int(o.get("confidence", 50))
            if not 0 <= conf <= 100: raise ValueError
            i = pending.get((kind, val)) or db.scalar(select(IOC).where(IOC.type == kind, IOC.value == val)) or IOC(type=kind, value=val)
            i.source, i.confidence, i.expires_at = "stix:" + str(o.get("created_by_ref", "bundle"))[:90], conf, exp; db.add(i); pending[(kind, val)] = i; ok += 1
        except (ValueError, TypeError, AttributeError): bad += 1
    audit.log(db, "ioc.import_stix", user=user, new=f"{ok} imported, {bad} rejected", ip=ip_of(request)); db.commit(); return {"imported": ok, "rejected": bad}

@router.get("/admin/integrity/events")
def verify_event_hashes(limit: int = 100000, user=Depends(require("system")), db=Depends(get_db)):
    """SR-11: recompute SHA-256 of each stored raw event and compare with the hash taken on receipt. Covers the raw text only."""
    import hashlib
    bad, n = [], 0
    for eid, raw, h in db.execute(select(Event.id, Event.raw, Event.hash).order_by(Event.timestamp.desc()).limit(min(max(limit, 1), 1000000))):
        n += 1
        if hashlib.sha256(raw.encode()).hexdigest() != h: bad.append(eid)
    return {"checked": n, "modified": len(bad), "modified_event_ids": bad[:50], "intact": not bad}
