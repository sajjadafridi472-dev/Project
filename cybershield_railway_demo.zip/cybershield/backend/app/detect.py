"""Rule-based + statistical detection, correlation and scoring (SRS 3.3). No ML. Rules are data (JSON), never code."""
import json, math, re
from dataclasses import dataclass, field
from datetime import timedelta
from urllib.parse import unquote_plus
from sqlalchemy import select
from .config import settings
from . import notify, metrics
from .models import (Alert, AlertEvent, AlertIOC, Asset, Event, IOC, IngestMetric, Rule, RuleVersion, Suppression, utcnow)

FIELDS = {"event_type", "hostname", "src_ip", "dst_ip", "username", "source_type", "message", "severity"}
GROUP = {"src_ip", "dst_ip", "username", "hostname"}
SEVS = ("Low", "Medium", "High", "Critical")
DPT = re.compile(r"DPT=(\d{1,5})")
HASH_RE = re.compile(r"\b(?:[a-f0-9]{64}|[a-f0-9]{40}|[a-f0-9]{32})\b")
HOST_RE = re.compile(r"\b(?:[a-z0-9-]{1,63}\.)+[a-z]{2,24}\b")

def validate_logic(L) -> dict:
    """Strict schema check; raises ValueError. User-supplied rules cannot contain code or regex (SR-21)."""
    if not isinstance(L, dict) or L.get("type") not in ("threshold", "distinct", "ioc", "match", "anomaly"):
        raise ValueError("type must be one of threshold, distinct, ioc, match, anomaly")
    m = L.get("match", {})
    if not isinstance(m, dict) or len(m) > 8: raise ValueError("match must be an object with at most 8 fields")
    for f, c in m.items():
        if f not in FIELDS: raise ValueError(f"unknown match field: {f}")
        if isinstance(c, dict):
            if set(c) - {"in", "contains_any"} or len(c) != 1: raise ValueError("condition must use exactly one of: in, contains_any")
            lst = next(iter(c.values()))
            if not isinstance(lst, list) or not 1 <= len(lst) <= 50 or any(not isinstance(x, str) or len(x) > 200 for x in lst):
                raise ValueError("condition lists need 1-50 strings of at most 200 characters")
        elif not isinstance(c, (str, int)) or isinstance(c, bool) or len(str(c)) > 200: raise ValueError("invalid match value")
    t = L["type"]
    if t == "match" and not m: raise ValueError("match rules need at least one condition")
    if t in ("threshold", "distinct"):
        if L.get("group_by") not in GROUP: raise ValueError(f"group_by must be one of {sorted(GROUP)}")
        if not isinstance(L.get("more_than"), int) or not 1 <= L["more_than"] <= 100000: raise ValueError("more_than must be an integer 1-100000")
        if not isinstance(L.get("window_seconds"), int) or not 10 <= L["window_seconds"] <= 86400: raise ValueError("window_seconds must be 10-86400")
    if t == "distinct" and L.get("distinct") not in ("dst_port", "dst_ip"): raise ValueError("distinct must be dst_port or dst_ip")
    if t == "anomaly":
        if L.get("kind") != "login_hour": raise ValueError("only kind=login_hour is supported")
        if not isinstance(L.get("min_baseline", 20), int) or not 5 <= L.get("min_baseline", 20) <= 1000: raise ValueError("min_baseline must be 5-1000")
        if not isinstance(L.get("max_share", 0.03), (int, float)) or not 0 < L.get("max_share", 0.03) <= 0.5: raise ValueError("max_share must be in (0, 0.5]")
    if "entity" in L and L["entity"] not in GROUP: raise ValueError("entity must be a group field")
    for k in ("mitre", "description"):
        if k in L and (not isinstance(L[k], str) or len(L[k]) > 300): raise ValueError(f"{k} must be a short string")
    return L

DEFAULT_RULES = [
    ("Brute-force login attempts", "Medium", {"type": "threshold", "match": {"event_type": "auth.failure"}, "group_by": "src_ip",
      "more_than": 10, "window_seconds": 300, "mitre": "T1110", "description": "More than 10 failed logins from one source in 5 minutes (FR-DET-02)"}),
    ("Port scan / reconnaissance", "Medium", {"type": "distinct", "match": {"event_type": "net.fw"}, "group_by": "src_ip",
      "distinct": "dst_port", "more_than": 15, "window_seconds": 60, "mitre": "T1046", "description": "One source probing more than 15 distinct ports in 60 seconds (FR-DET-03)"}),
    ("Known-malicious indicator", "High", {"type": "ioc", "mitre": "T1071", "description": "IP, domain or hash matches a threat-intelligence indicator (FR-DET-04)"}),
    ("Privilege escalation command", "High", {"type": "match", "match": {"event_type": {"in": ["priv.sudo", "priv.escalation"]},
      "message": {"contains_any": ["command=/bin/bash", "command=/bin/sh", "command=/usr/bin/su", "nopasswd", "usermod -ag sudo", "chmod u+s"]}},
      "mitre": "T1548", "description": "Shell, sudoers or setuid changes through sudo (FR-DET-05)"}),
    ("Web attack signature (SQLi/XSS probe)", "High", {"type": "match", "match": {"event_type": "web.request", "message": {"contains_any":
      ["' or '1'='1", "' or 1=1", "union select", "<script", "../../", "sleep(", "information_schema", "onerror="]}},
      "mitre": "T1190", "description": "Common injection and traversal strings in web requests, URL-decoded once (FR-DET-01)"}),
    ("Anomalous login time", "Medium", {"type": "anomaly", "kind": "login_hour", "min_baseline": 20, "max_share": 0.03, "entity": "username",
      "mitre": "T1078", "description": "Login far outside this user's usual hours; needs a 20-login baseline (FR-DET-06)"}),
]

def seed_rules(db):
    for name, sev, logic in DEFAULT_RULES:
        if not db.scalar(select(Rule).where(Rule.name == name)):
            r = Rule(name=name, severity=sev, logic=json.dumps(logic)); db.add(r); db.flush()
            db.add(RuleVersion(rule_id=r.id, version=1, name=name, logic=r.logic, severity=sev))
    db.commit()

def _cond_ok(c, v):
    if isinstance(c, dict):
        if "in" in c: return v in c["in"]
        s = str(v or "").lower(); return any(x.lower() in s for x in c["contains_any"])
    return str(v) == str(c)

def matches(cond, ev) -> bool:
    for f, c in cond.items():
        v = ev.get(f)
        if f == "message": v = unquote_plus(v or "")  # decode once so %27 or 1=1 is seen
        if not _cond_ok(c, v): return False
    return True

def _port(e):
    m = DPT.search(e.get("message") or ""); return m[1] if m else None

def ev_dict(e: Event) -> dict:
    return {"id": e.id, "timestamp": e.timestamp, "hostname": e.hostname, "src_ip": e.src_ip, "dst_ip": e.dst_ip,
            "username": e.username, "event_type": e.event_type, "message": e.message, "severity": e.severity,
            "source_type": e.source_type, "received_at": e.received_at}

class DBStore:
    def __init__(self, db): self.db, self._ioc = db, {}
    def window(self, match, gf, gv, start, end):
        q = select(Event).where(getattr(Event, gf) == gv, Event.timestamp > start, Event.timestamp <= end)
        for f, c in match.items():
            if f == "message" or (isinstance(c, dict) and "in" not in c): continue  # contains_any is checked in Python below
            vals = c["in"] if isinstance(c, dict) else [c]
            if f == "severity": vals = [int(v) for v in vals if str(v).lstrip("-").isdigit()]  # integer column
            else: vals = [str(v) for v in vals]  # text columns: never compare text with an integer parameter
            if not vals: return []
            q = q.where(getattr(Event, f).in_(vals))
        return [d for d in (ev_dict(e) for e in self.db.scalars(q.order_by(Event.timestamp).limit(5000))) if matches(match, d)]
    def login_hours(self, user, before):
        return [t.hour for t in self.db.scalars(select(Event.timestamp).where(Event.username == user, Event.event_type == "auth.success",
                Event.timestamp < before).limit(2000))]
    def iocs(self, values):
        new = [v for v in values if v not in self._ioc]
        if new:
            now = utcnow(); self._ioc.update({v: None for v in new})
            for i in self.db.scalars(select(IOC).where(IOC.value.in_(new))):
                if i.expires_at is None or i.expires_at > now: self._ioc[i.value] = (i.id, i.type, i.value, i.confidence)
        return {v: self._ioc[v] for v in values if self._ioc.get(v)}

class ListStore:
    """In-memory store used by the rule tester (FR-DET-09): same evaluators, no database writes."""
    def __init__(self, events, ioc_lookup): self.ev, self.lookup = events, ioc_lookup
    def window(self, match, gf, gv, start, end):
        return [e for e in self.ev if e.get(gf) == gv and start < e["timestamp"] <= end and matches(match, e)]
    def login_hours(self, user, before):
        return [e["timestamp"].hour for e in self.ev if e.get("username") == user and e["event_type"] == "auth.success" and e["timestamp"] < before]
    def iocs(self, values): return self.lookup(values)

@dataclass
class Finding:
    summary: str
    event_ids: list
    iocs: list = field(default_factory=list)

def eval_rule(L, ev, store):
    t, m = L["type"], L.get("match", {})
    if t in ("threshold", "distinct", "match") and not matches(m, ev): return None
    if t == "match": return Finding(f"Signature matched in {ev['event_type']} event", [ev["id"]])
    if t in ("threshold", "distinct"):
        g = ev.get(L["group_by"])
        if not g: return None
        w = store.window(m, L["group_by"], g, ev["timestamp"] - timedelta(seconds=L["window_seconds"]), ev["timestamp"])
        ids = [e["id"] for e in w[-100:]]
        if t == "threshold" and len(w) > L["more_than"]:
            return Finding(f"{len(w)} matching events for {L['group_by']}={g} within {L['window_seconds']}s (rule: more than {L['more_than']})", ids)
        if t == "distinct":
            vals = {(_port(e) if L["distinct"] == "dst_port" else e.get("dst_ip")) for e in w} - {None}
            if len(vals) > L["more_than"]:
                return Finding(f"{g} probed {len(vals)} distinct {L['distinct']} values within {L['window_seconds']}s (rule: more than {L['more_than']})", ids)
        return None
    if t == "ioc":
        msg = unquote_plus(ev.get("message") or "").lower()
        cands = {x for x in (ev.get("src_ip"), ev.get("dst_ip")) if x} | set(HASH_RE.findall(msg)) | set(HOST_RE.findall(msg))
        hit = store.iocs(cands)
        if hit: return Finding("Indicator match: " + ", ".join(sorted(hit)), [ev["id"]], list(hit.values()))
        return None
    if t == "anomaly" and ev["event_type"] == "auth.success" and ev.get("username"):
        hrs = store.login_hours(ev["username"], ev["timestamp"]); n, h = len(hrs), ev["timestamp"].hour
        if n < L.get("min_baseline", 20): return None
        near = sum(1 for x in hrs if min((x - h) % 24, (h - x) % 24) <= 1)
        if near / n < L.get("max_share", 0.03):
            return Finding(f"{ev['username']} logged in around {h:02d}:00 UTC; only {near} of {n} earlier logins were within 1 hour of that time", [ev["id"]])
    return None

def entity_of(L, ev):
    for f in (L.get("entity"), "src_ip", "username", "hostname"):
        if f and ev.get(f): return f"{f}:{ev[f]}"
    return None

BASE = {"Low": 15, "Medium": 35, "High": 60, "Critical": 80}
def sev_of(score): return "Low" if score < 25 else "Medium" if score < 50 else "High" if score < 75 else "Critical"

def risk_score(rules, crit, has_ioc, occ):
    comps = [("highest rule severity", max(BASE[r["severity"]] for r in rules))]
    if crit: comps.append((f"asset criticality {crit}/5", round(2.5 * (crit - 3))))
    if has_ioc: comps.append(("threat-intelligence match", 10))
    if len(rules) > 1: comps.append((f"{len(rules)} different detections correlated", min(20, 10 * (len(rules) - 1))))
    if occ >= 2: comps.append((f"{occ} occurrences", min(10, int(math.log2(occ)))))
    return max(0, min(100, sum(c[1] for c in comps))), comps

def bump(db, key, n=1): metrics.bump(db, key, n)

def _suppressed(sups, rule_id, ev, now):
    for s in sups:
        if s.expires_at <= now or (s.rule_id and s.rule_id != rule_id): continue
        if all(getattr(s, f) is None or getattr(s, f) == ev.get(f) for f in ("src_ip", "username", "hostname")): return True
    return False

def upsert_alert(db, rule, L, f, ev, row):
    key = entity_of(L, ev)
    if not key: return None
    w = timedelta(minutes=settings.correlation_minutes); ts = ev["timestamp"]
    a = db.scalar(select(Alert).where(Alert.entity == key, Alert.status.in_(("Open", "Investigating")),
          Alert.last_event_at >= ts - w, Alert.last_event_at <= ts + w).order_by(Alert.id.desc()))
    info = {"id": rule.id, "name": rule.name, "version": rule.version, "severity": rule.severity, "mitre": L.get("mitre"), "summary": f.summary}
    asset = db.scalar(select(Asset).where(Asset.hostname == ev.get("hostname")))
    if a:  # correlation / de-duplication into one alert (FR-DET-07, FR-ALR-05)
        x = json.loads(a.explanation); rs = x["rules"]
        for i, r in enumerate(rs):
            if r["id"] == rule.id: rs[i] = info; break
        else: rs.append(info)
        have = set(db.scalars(select(AlertEvent.event_id).where(AlertEvent.alert_id == a.id)))
        a.occurrence_count += 1; a.last_event_at = max(a.last_event_at, ts)
    else:
        a = Alert(rule_id=rule.id, rule_version=rule.version, severity="Low", risk_score=0, status="Open", entity=key,
                  hostname=ev.get("hostname"), occurrence_count=1, last_event_at=ts,
                  trigger_latency_ms=int((utcnow() - row.received_at).total_seconds() * 1000))
        db.add(a); db.flush(); x = {"entity": key, "rules": [info], "iocs": []}; have = set()
    for i in f.iocs:
        if i[2] not in x["iocs"]: x["iocs"].append(i[2]); db.merge(AlertIOC(alert_id=a.id, ioc_id=i[0]))
    for eid in f.event_ids:
        if eid not in have: db.add(AlertEvent(alert_id=a.id, event_id=eid))
    sc, comps = risk_score(x["rules"], asset.criticality if asset else None, bool(x["iocs"]), a.occurrence_count)
    a.risk_score, a.severity = sc, sev_of(sc); x["score_components"] = comps
    names = [r["name"] for r in x["rules"]]
    a.title = (names[0] if len(names) == 1 else "Correlated: " + " + ".join(names))[:200]
    a.mitre = ",".join(sorted({r["mitre"] for r in x["rules"] if r.get("mitre")}))[:60]; a.explanation = json.dumps(x); a.updated_at = utcnow(); db.flush()
    notify.on_alert(db, a); return a

def process_new(db, batch=500, on_alerts=None) -> int:
    rows = db.scalars(select(Event).where(Event.detected == False).order_by(Event.timestamp, Event.received_at).limit(batch).with_for_update(skip_locked=True)).all()  # noqa: E712
    if not rows: return 0
    rules = [(r, json.loads(r.logic)) for r in db.scalars(select(Rule).where(Rule.enabled == True))]  # noqa: E712
    touched = {}
    sups, store, now, raw = db.scalars(select(Suppression)).all(), DBStore(db), utcnow(), 0
    for row in rows:
        ev = ev_dict(row)
        for r, L in rules:
            try: f = eval_rule(L, ev, store)
            except Exception: bump(db, "rule_errors"); continue  # a faulty rule must never stop detection
            if not f: continue
            raw += 1
            if _suppressed(sups, r.id, ev, now): bump(db, "suppressed"); continue
            a = upsert_alert(db, r, L, f, ev, row)
            if a: touched[a.id] = a
        row.detected = True
    bump(db, "raw_findings", raw); db.commit()
    if on_alerts and touched:  # live push (FR-ALR-02)
        on_alerts([{"id": a.id, "title": a.title, "severity": a.severity, "risk_score": a.risk_score, "status": a.status,
                    "entity": a.entity, "occurrence_count": a.occurrence_count, "updated_at": a.updated_at} for a in touched.values()])
    return len(rows)
