"""Syslog receiver (UDP + TCP, RFC 3164/5424). Not implemented: TLS (RFC 5425). UDP/TCP are
unauthenticated and unencrypted; the UI must flag this (SRS 5.4). Binds to loopback unless configured."""
import socket, socketserver, threading
from sqlalchemy import select
from .db import SessionLocal
from .models import LogSource
from . import ingest

def _accept(name, lines):
    with SessionLocal() as db:
        s = db.scalar(select(LogSource).where(LogSource.name == name, LogSource.source_type == "syslog"))
        if not s or s.status == "disabled": return
        ingest.enqueue(db, lines, "syslog", s.id, "syslog", "live"); db.commit()

def start(port, source_name, host="127.0.0.1"):
    udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); udp.bind((host, port)); udp.settimeout(0.3)
    stop = threading.Event()
    def udp_loop():
        while not stop.is_set():
            try: data, _ = udp.recvfrom(8192)
            except socket.timeout: continue
            except OSError: return
            _accept(source_name, [data.decode("utf-8", "replace")])
    class H(socketserver.StreamRequestHandler):
        def handle(self):
            for _ in range(1000):  # cap lines per connection
                line = self.rfile.readline(8192)
                if not line: break
                _accept(source_name, [line.decode("utf-8", "replace")])
    tcp = socketserver.ThreadingTCPServer((host, port), H); tcp.daemon_threads = True
    threading.Thread(target=udp_loop, daemon=True).start()
    threading.Thread(target=tcp.serve_forever, daemon=True).start()
    def shutdown(): stop.set(); udp.close(); tcp.shutdown(); tcp.server_close()
    return shutdown
